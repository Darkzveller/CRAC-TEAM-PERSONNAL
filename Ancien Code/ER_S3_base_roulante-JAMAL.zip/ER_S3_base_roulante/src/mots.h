#include <Arduino.h>

int M1INA = 26;
int M1INB = 25;
int M2INB = 16;
int M2INA = 15;

int M1PWM = 17;
int M2PWM = 18;

int canal0 = 0;
int canal1 = 1;

int frequence = 20000;
int resolution = 10;

void init_mots();
void d_moves(float speed);
void g_moves(float speed);
void stop(void);

void init_mots(){
    // Initialisation TOR pour Moteur 1 et Moteur 2
  pinMode(M1INA, OUTPUT);
  pinMode(M1INB, OUTPUT);
  pinMode(M1PWM, OUTPUT);

  pinMode(M2INA, OUTPUT);
  pinMode(M2INB, OUTPUT);
  pinMode(M2PWM, OUTPUT);

  // configuration des canaux PWM pour M1 et M2
  ledcSetup(canal1, frequence, resolution);
  ledcAttachPin(M1PWM, canal0);
  ledcAttachPin(M2PWM, canal1);
}

void d_moves(float speed){

  if(speed>=0){
  digitalWrite(M1INB, HIGH);
  digitalWrite(M1INA, LOW);
  analogWrite(M1PWM, speed);
  }
  else{
  digitalWrite(M1INA, HIGH);
  digitalWrite(M1INB, LOW);
  analogWrite(M1PWM, -speed);
  }
}

void g_moves(float speed){

  if(speed<0){
  digitalWrite(M2INA, LOW);
  digitalWrite(M2INB, HIGH);
  analogWrite(M2PWM, -speed);
  }
  else{
  digitalWrite(M2INB, LOW);
  digitalWrite(M2INA, HIGH);
  analogWrite(M2PWM, speed);
  }
}

void stop(void)
{
   digitalWrite(M1INA, LOW);
  digitalWrite(M1INB, LOW);
  analogWrite(M1PWM, 0);

  digitalWrite(M2INB, LOW);
  digitalWrite(M2INA, LOW);
  analogWrite(M2PWM, 0);
}



