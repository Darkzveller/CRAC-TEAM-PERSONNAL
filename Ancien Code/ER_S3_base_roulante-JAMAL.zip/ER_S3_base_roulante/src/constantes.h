#define R 2 // rayon roues encodeuse en cm
#define L 23 // entraxe roues encodeuse en cm
#define PI 3.14159265
#define COEFF_D (2*PI*R)/4100  // conversion pas ->cm
#define COEFF_ROT R*360/(4200*21.0)//conversion pas->degre
#define CONV_RD (PI / 180 )* COEFF_ROT // conversion pas->radian