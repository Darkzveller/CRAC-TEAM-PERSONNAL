#include "encodeur.h"
#include "constantes.h"
#include "BluetoothSerial.h"

BluetoothSerial SerialBT;

// Angle du robot 
float teta, prev_teta, teta_init,teta_moy;//en pas
float teta_moy_rad,teta_rad;// en radian
float teta_deg, teta_moy_deg;// en degre

//Coordonées du robot
float x_cm, y_cm; // en cm
float dist,prev_dist; //distantce du robot par rapport à l'origine
float x, y; // en pas


void init_odo(double x0, double y0, float teta0); // initialisee les variables x,y,teta et dist
void calcul_xy_lineaire(void);
void print_odo(void);


void init_odo(double x0, double y0, float teta0)
{
  x = x0;
  y = y0;
  teta = teta0;
  teta_init = teta0;
  prev_teta = teta0;
  dist = 0;
  prev_dist = 0;
}

void calcul_xy_lineaire(void)
{
  float delta_d;
  float dx, dy;

  saisie_encod();

  dist = (gauche + droite) / 2.0;
  teta = teta_init + (droite - gauche);
  teta_rad = teta* CONV_RD;
  teta_deg =teta*COEFF_ROT;
  delta_d = dist - prev_dist;
  teta_moy = (teta + prev_teta) / 2;
  teta_moy_rad = teta_moy * CONV_RD;
  teta_moy_deg=teta_moy*COEFF_ROT;
  
  dx = delta_d * cos(teta_moy_rad);
  dy = delta_d * sin(teta_moy_rad);

  x = x + dx;
  y = y + dy;

  x_cm = x*COEFF_D;
  y_cm = y*COEFF_D;

  prev_dist = dist;
  prev_teta = teta;
}

void print_odo(void)
{
  Serial.printf("\ngauche : ");
  Serial.print(gauche);
  Serial.printf(" droite : ");
  Serial.print(droite);
  Serial.printf(" x= ");
  Serial.print(x_cm);
  Serial.printf(" y= ");
  Serial.print(y_cm);
  Serial.printf(" teta_deg = ");
  Serial.print(teta_deg);
  // Serial.printf(" teta_moy_deg = ");
  // Serial.print(teta_moy_deg);
}
