#include <Arduino.h>
#include "odometrie.h"
#include "mots.h"
// vit pour les tests à 50
void toutdroit(int vit);// fait avancer le robot tout droit à une vitesse donnée
void avance_dist(float distance);// permet de faire avancer le robot d'une certaine distance
void turn_aoundL(int vit);//fait tourner le robot vers la gauche à une vitesse donnée
void deplacement(float x_cm_cons,float y_cm_cons);// fait se déplacer le robot à un point de coordonée 
void deplacement2(float x_cm_cons,float y_cm_cons);// fait se déplacer le robot à un point de coordonée 
void tourne(float teta_cons);// permet de faire tourner le robot d'un certain angle

int TD = 0;
int TAL = 0;
int TR = 0;
int D2 = 0;

float tension;

void avance_dist(float distance)
{
  int pulse = distance / COEFF_D;
  static float erreur, position, difference;
  static float commande;

  calcul_xy_lineaire();

  switch (TD)
  {
  case 0:
    position = x_cm;
    difference = droite - gauche;
    tension = 50;
    TD = 1;
    break;

  case 1:
    if (x_cm > position + distance / 3.0) TD = 2;
    erreur = difference - (droite - gauche);
    commande = erreur * 0.1;
    if (commande > tension/3) commande = tension/3;
    else if (commande < -tension/4) commande = -tension/3;
    d_moves(tension+commande);
    g_moves(tension-commande);
    tension = tension + 0.1;
    if (tension > 100) tension = 100;
    break;

  case 2:
    if (x_cm > position + 2 * distance / 3.0) TD = 3;
    erreur = difference - (droite - gauche);
    commande = erreur * 0.1;
    if (commande > tension/3) commande = tension/3;
    else if (commande < -tension/3) commande = -tension/3;
    d_moves(tension+commande );
    g_moves(tension-commande);
 
    break;

  case 3:
    if (x_cm > position + distance) TD = 4;
    erreur = difference - (droite - gauche);
    commande = erreur * 0.1;
    if (commande > tension/3) commande = tension/3;
    else if (commande < -tension/3) commande = -tension/3;
    d_moves(tension +commande);
    g_moves(tension -commande);
    tension = tension - 2;
    if (tension < 20) tension = 20;
    break;

  case 4:
    stop();
    break;
  }
}

void tourne(float teta_cons){
  static float erreur, position, difference;
  static float commande;

  calcul_xy_lineaire();

  switch (TR)
  {
  case 0:
    position = teta_deg;
    difference = droite + gauche;
    tension = 50;
    TR=1;
    break;
  
  case 1 : 
    if(teta_cons>position)TR = 10;
    else if(teta_cons<position)TR = 20;
    break;

  case 10:
    if (teta_deg > position + teta_cons / 3.0) TR = 11;
    erreur = difference - (droite + gauche);
    commande = erreur * 0.1;
    if (commande > tension/3) commande = tension/3;
    else if (commande < -tension/4) commande = -tension/3;
    d_moves(tension + commande);
    g_moves(-tension- commande);
    tension = tension + 0.2;
    if (tension > 150) tension = 150;
    break;

  case 11:
    if (teta_deg > position + 2 * teta_cons / 3.0) TR = 12;
    erreur = difference - (droite + gauche);
    commande = erreur * 0.1;
    if (commande > tension/3) commande = tension/3;
    else if (commande < -tension/3) commande = -tension/3;
    d_moves(tension + commande );
    g_moves(-tension -commande);
 
    break;

  case 12 :
    if (teta_deg > position + teta_cons) TR = 3;
    erreur = difference - (droite + gauche);
    commande = erreur * 0.1;
    if (commande > tension/3) commande = tension/3;
    else if (commande < -tension/3) commande = -tension/3;
    d_moves(tension+ commande);
    g_moves(-tension- commande);
    tension = tension - 1;
    if (tension < 50) tension = 50;
    break;

  case 20:
    if (teta_deg < position + teta_cons / 3.0) TR = 21;
    erreur = difference - (droite + gauche);
    commande = erreur * 0.1;
    if (commande > tension/3) commande = tension/3;
    else if (commande < -tension/4) commande = -tension/3;
    d_moves(-(tension+commande));
    g_moves(tension-commande);
    tension = tension + 0.1;
    if (tension > 50) tension = 50;
    break;

  case 21:
    if (teta_deg < position + 2 * teta_cons / 3.0) TR = 22;
    erreur = difference - (droite + gauche);
    commande = erreur * 0.1;
    if (commande > tension/3) commande = tension/3;
    else if (commande < -tension/3) commande = -tension/3;
    d_moves(-(tension+commande ));
    g_moves(tension-commande);
 
    break;

  case 22 :
    if (teta_deg < position + teta_cons) TR = 3;
    erreur = difference - (droite + gauche);
    commande = erreur * 0.1;
    if (commande > tension/3) commande = tension/3;
    else if (commande < -tension/3) commande = -tension/3;
    d_moves(-(tension +commande));
    g_moves(tension -commande);
    tension = tension - 2;
    if (tension < 20) tension = 20;
    break;

  case 3:
    stop();
    break;
  }
}

void toutdroit(int vit)
{
  d_moves(vit);

  g_moves(vit);
}

void turn_aoundL(int vit)
{
  d_moves(vit);
  g_moves(vit);
}

void deplacement(float x_cm_cons,float y_cm_cons){
  static float delta_d,delta_d_pre;
  static float delta_teta_rad,delta_teta_pre;
  static float v_motg,v_motd;
  // A trouver experimentalement somme max
  static float somme_v=0, somme_vmax=500;
  static float somme_w=0, somme_wmax=500;
  static float v, w, Te = 0.001; //Te a voir experimentalement
  // A trouver experimentalement
  static float kp_v=20, kd_v=0.05,ki_v=0.1; 
  static float kp_w=20, kd_w=0.05,ki_w=0.1; 

  calcul_xy_lineaire();

  delta_d = sqrt(pow(x_cm_cons-x_cm,2)+pow(y_cm_cons-y_cm,2));
  delta_teta_rad = atan2(y_cm-y_cm_cons,x_cm-x_cm_cons)-teta_rad;
  //asservissment vitesse linéaire
  somme_v += delta_d*Te;

  if (somme_v > somme_vmax) somme_v = somme_vmax;
  if (somme_v < -somme_vmax) somme_v = -somme_vmax;

  v = kp_v*delta_d + (kd_v*(delta_d-delta_d_pre))/Te + ki_v*somme_v;

  //asservissment vitesse angulaire
  somme_w += delta_teta_rad*Te;

  if (somme_w > somme_wmax) somme_w = somme_wmax;
  if (somme_w < -somme_wmax) somme_w = -somme_wmax;

  w = kp_w*delta_teta_rad + (kd_w*(delta_teta_rad-delta_teta_pre))/Te + ki_w*somme_w;
  
  delta_d_pre = delta_d;
  delta_teta_pre = delta_teta_rad;

  v_motd = v+w;
  v_motg =v-w;

  if(v_motd>150) v_motd=150;
  if(v_motd<-150) v_motd=-150;
  if(v_motg>150) v_motg=150;
  if(v_motg<-150) v_motg=-150;

  d_moves(v_motd);
  g_moves(v_motg);
  
}

void deplacement2(float x_cm_cons,float y_cm_cons){
  float dx,dy;
  float dteta_deg,dteta;
  float distance;

  dx =x_cm_cons-x_cm;
  dy = y_cm_cons-y_cm;

  dteta = atan2(dy,dx);
  dteta_deg = dteta* 180.0/PI;

  distance = sqrt(pow(dx,2)+pow(dy,2));

  switch(D2){
    case 0 :
      tourne(dteta_deg);
      if(TR==3) D2 = 10;
      break;

    case 10 :
      stop();
      delay(1000);
      D2 = 1;
      break;

    case 1 :
      avance_dist(dx);
      if(TD==4)D2 = 2;
      break;
    
    case 2 : 
      stop();
  }

}