#include <Arduino.h>
#include <WiFi.h>
#include <ArduinoOTA.h>
#include "constantes.h" 
#include "deplacement.h"

const char *SSID = "ESPWIFI";
const char *MDP = "Crac_Crac";

void setup() {
  // liaison serie
  Serial.begin(115200);
  Serial.print("Let's go !");
  //liaison BT
  //Serial.begin("CRACJ");
  //liaison WiFi
  WiFi.mode(WIFI_AP);
  WiFi.softAP(SSID,MDP,1,0,1);
  ArduinoOTA.begin();
  // relie encodeurs aux broches
  init_encod();
  // initialisee les variables x,y,teta et dist
  init_odo(0, 0, 0);
  // initialisation des moteurs
  init_mots();
}

int state = 0;

void loop() {
  calcul_xy_lineaire();
  //ArduinoOTA.handle();
  switch (state)
  {
  case 0:
    stop();
    TD = 0;
    TR = 0;
    D2 =0;
    calcul_xy_lineaire();
    if (Serial.available()) {
        char caractere = Serial.read();
        if (caractere == 'g') {
          state = 1;
        }
      }
    break;
  case 1:

    deplacement2(50,50);
    if (Serial.available()) {
        char caractere = Serial.read();
        if (caractere == 'r') {
          state = 0;
        }
      }
    break;
  }
  print_odo();
  // Serial.printf("\nstate = %d",state);
  // Serial.printf("TR = %d",TR);
  // Serial.printf("D2 = %d",D2);
  // Serial.printf("TD = %d",TD);
  // Serial.printf(" tension = ");
  // Serial.print(tension);
  // Serial.printf(" x= ");
  // Serial.print(x_cm);
  // Serial.printf(" y= ");
  // Serial.print(y_cm);
}
