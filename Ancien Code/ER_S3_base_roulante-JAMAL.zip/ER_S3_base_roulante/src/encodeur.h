#include "ESP32Encoder.h"
#include <Arduino.h>

ESP32Encoder encoderD;
ESP32Encoder encoderG;

void saisie_encod(void);
void print_encod(void); // affiche les pas des encodeurs
void init_encod(void);  // initialise les encodeurs 

int gauche, droite;

void init_encod(void)
{
  encoderD.attachFullQuad(23, 22);
  encoderD.setCount(0);
  encoderG.attachFullQuad(36, 39);
  encoderG.setCount(0);
}

void saisie_encod()
{
  gauche = encoderG.getCount();
  droite = encoderD.getCount();
}

void print_encod(void)
{
  Serial.printf("\ngauche : ");
  Serial.print(gauche);
  Serial.printf(" droite : ");
  Serial.print(droite);
}
