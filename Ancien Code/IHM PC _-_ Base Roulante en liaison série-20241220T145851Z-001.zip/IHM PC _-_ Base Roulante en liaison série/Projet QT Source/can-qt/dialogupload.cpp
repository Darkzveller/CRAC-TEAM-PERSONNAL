#include "dialogupload.h"
#include "ui_dialogupload.h"
#include "remoteFileSystem.h"

DialogUpload::DialogUpload(TreeModel *model, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogUpload)
{
    ui->setupUi(this);
    connect(ui->altButton, SIGNAL(clicked()), this, SLOT(altClicked()));
    connect(ui->eraseButton, SIGNAL(clicked()), this, SLOT(eraseClicked()));
    connect(ui->buttonBox, SIGNAL(accepted()), this, SLOT(accept()));
    connect(ui->buttonBox, SIGNAL(rejected()), this, SLOT(reject()));
    ui->lineEdit->setDisabled(true);
    m_model = model;
}

DialogUpload::~DialogUpload()
{
    delete ui;
}

void DialogUpload::set(const QString &source, const QString &dest, const QString &alt, bool showSrc)
{
    m_dest = dest;
    m_alt = alt;
    ui->comboBox->clear();
    add(m_model->root());
    ui->comboBox->setCurrentText(QString::fromStdString(Fichier::dirOfFile(dest.toStdString())));
    showSource(showSrc);
    ui->sourceFile->setText(source);
    ui->lineEdit->setDisabled(true);
    ui->comboBox->setDisabled(true);
    ui->destFile->setText(dest);
    if (alt.isNull()) {
        ui->eraseButton->setText(tr("Destination par défaut"));
        ui->eraseButton->setChecked(true);
        ui->lineEdit->setText(QString::fromStdString(Fichier::nameOfFile(dest.toStdString())));
        m_erase = false;
    } else {
        ui->lineEdit->setText(QString::fromStdString(Fichier::nameOfFile(alt.toStdString())));
        ui->comboBox->setCurrentText(QString::fromStdString(Fichier::dirOfFile(alt.toStdString())));
        ui->eraseButton->setText(tr("Ecrase le fichier existant"));
        ui->eraseButton->setChecked(true);
        m_erase = true;
    }
    ui->altButton->setChecked(false);
    ui->altFrame->setFrameShape(QFrame::StyledPanel);
    ui->destFrame->setFrameShape(QFrame::WinPanel);
    resize(width(), 0);
}

bool DialogUpload::get(QString &dest)
{
    if (m_erase) {
        if (ui->eraseButton->isChecked()) {
            dest = m_dest;
            return true;
        } else {
            QString path = ui->comboBox->currentText();
            if (path == "/") path = "";
            dest = path + "/" + ui->lineEdit->text();
            return false;
        }
    }
    if (ui->altButton->isChecked()) {
        QString path = ui->comboBox->currentText();
        if (path == "/") path = "";
        dest = path + "/" + ui->lineEdit->text();
        return dest == m_alt;
    }
    dest = m_dest;
    return false;
}

void DialogUpload::showSource(bool ok)
{
    ui->srcFrame->setVisible(ok);
}

void DialogUpload::add(Dossier *d)
{
    string item = d->getFullName();
    if (item.size() == 0) item = "/";
    ui->comboBox->addItem(QString::fromStdString(item));
    int i=0;
    Dossier *child;
    while ((child = d->getDir(i)) != nullptr) {
        add(child);
        i++;
    }
}

void DialogUpload::eraseClicked()
{
    ui->lineEdit->setDisabled(true);
    ui->comboBox->setDisabled(true);
    ui->altFrame->setFrameShape(QFrame::StyledPanel);
    ui->destFrame->setFrameShape(QFrame::WinPanel);
}

void DialogUpload::altClicked()
{
    ui->lineEdit->setEnabled(true);
    ui->comboBox->setEnabled(true);
    ui->destFrame->setFrameShape(QFrame::StyledPanel);
    ui->altFrame->setFrameShape(QFrame::WinPanel);
}
