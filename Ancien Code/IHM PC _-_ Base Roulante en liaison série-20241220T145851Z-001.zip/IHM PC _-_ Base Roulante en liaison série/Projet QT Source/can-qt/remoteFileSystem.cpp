#include "remoteFileSystem.h"
#include <QIcon>
#include <QMimeData>
#include <QUrl>
#include <QFile>
#include <QFileInfo>

#include <QDebug>

TreeModel::TreeModel(CanBusManager *manager, QObject *parent) : QAbstractItemModel(parent), m_manager(manager)
{
    m_rootItem = new Dossier();
    m_currentItem = m_rootItem;
}

TreeModel::~TreeModel()
{
    delete m_rootItem;
}

QModelIndex TreeModel::index(int row, int column, const QModelIndex &parent) const
{
    if (!hasIndex(row, column, parent))
        return QModelIndex();

    Dossier *parentItem;

    if (!parent.isValid())
        parentItem = m_rootItem;
    else
        parentItem = static_cast<Dossier*>(parent.internalPointer());

    Fichier *childItem = parentItem->child(row);
    if (childItem)
        return createIndex(row, column, childItem);
    return QModelIndex();
}

QModelIndex TreeModel::parent(const QModelIndex &index) const
{
    if (!index.isValid())
        return QModelIndex();

    Fichier *childItem = static_cast<Fichier*>(index.internalPointer());
    Dossier *parentItem = childItem->getParent();

    if (parentItem == m_rootItem)
        return QModelIndex();

    return createIndex(parentItem->row(), 0, parentItem);
}

int TreeModel::rowCount(const QModelIndex &parent) const
{
    Dossier *parentItem;
    if (parent.column() > 0)
        return 0;

    if (!parent.isValid())
        parentItem = m_rootItem;
    else
        parentItem = static_cast<Dossier *>(parent.internalPointer());

    return parentItem->childCount();
}

int TreeModel::columnCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent)
    return 1;
}

QVariant TreeModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid())
        return QVariant();
    if ((role == Qt::DisplayRole)||(role == Qt::EditRole)) {
        Fichier *item = static_cast<Fichier *>(index.internalPointer());
        return QString::fromStdString(item->getName());
    } else if (role == Qt::DecorationRole) {
        Fichier *item = static_cast<Fichier *>(index.internalPointer());
        Dossier *d = item->toDossier();
        return (d) ? QIcon(":/images/dir.png") : QIcon(":/images/file.png");
    }
    return QVariant();
}

bool TreeModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    if (!index.isValid()) return false;
    if (role == Qt::EditRole) {
        Fichier *item = static_cast<Fichier *>(index.internalPointer());
        QString oldName = QString::fromStdString(item->getName());
        QString oldFullName = QString::fromStdString(item->getFullName());
        if (!item->setName(value.toString().toStdString())) return false;
        if (oldFullName != QString::fromStdString(item->getFullName())) {
            startRemoteRename(oldFullName, QString::fromStdString(item->getName()));
            emit dataChanged(index, index);
            return true;
        }
    }
    return false;
}

Qt::ItemFlags TreeModel::flags(const QModelIndex &index) const
{
    if (!index.isValid()) return Qt::ItemIsDropEnabled;
    Qt::ItemFlags fla = QAbstractItemModel::flags(index) | Qt::ItemIsEditable;
    Fichier *f = static_cast<Fichier *>(index.internalPointer());
    Dossier *d = f->toDossier();
    if (d) fla |= Qt::ItemIsDropEnabled; else fla |= Qt::ItemIsDragEnabled;
    return fla;
}

QVariant TreeModel::headerData(int section, Qt::Orientation orientation,
                               int role) const
{
    Q_UNUSED(section)
    if (orientation == Qt::Horizontal && role == Qt::DisplayRole) return QString(tr("Carte SD distante"));
    return QVariant();
}

int TreeModel::insertDir(const QModelIndex &parent)
{
    Dossier *d, *newDir;
    if (!parent.isValid()) {
        d = m_rootItem;
    } else {
        d = static_cast<Dossier *>(parent.internalPointer());
    }
    int i = 0;
    QString str = "new";
    int row = d->dirCount();
    beginInsertRows(parent, row, row);
    while ((newDir = d->addDir(str.toLocal8Bit().data())) == nullptr) {
        str = QString("new_%1").arg(i++);
    }
    startRemoteMkdir(QString::fromStdString(newDir->getFullName()));
    endInsertRows();
    return row;
}

int TreeModel::insertFile(const QModelIndex &parent)
{
    Dossier *d;
    Fichier *newFile;
    if (!parent.isValid()) {
        d = m_rootItem;
    } else {
        d = static_cast<Dossier *>(parent.internalPointer());
    }
    int i = 0;
    QString str = "new.txt";
    int row = d->childCount();
    beginInsertRows(parent, row, row);
    while ((newFile = d->addFile(str.toLocal8Bit().data())) == nullptr) {
        str = QString("new_%1.txt").arg(i++);
    }
    startRemoteMkfile(QString::fromStdString(newFile->getFullName()));
    endInsertRows();
    return row;
}

bool TreeModel::remove(const QModelIndex &index)
{
    if (!index.isValid()) return false;
    Fichier *f = static_cast<Fichier *>(index.internalPointer());
    Dossier *d = f->getParent();
    startRemoteRemove(QString::fromStdString(f->getFullName()));
    beginRemoveRows(index.parent(), index.row(), index.row());
    d->rm(f);
    endRemoveRows();
    return true;
}

void TreeModel::updateModel()
{
    beginResetModel();
    m_rootItem->clear();
    endResetModel();
    m_listeChemin.clear();
    m_currentItem = m_rootItem;
    QByteArray data(1, CMD_CDROOT);
    bool ok = m_manager->receiveMulti(CAN_SD_CMD+1, this, SLOT(updateModelContinue()));
    if (!ok) {
        emit modelUpdated(false);
        return;
    }
    m_manager->send(CAN_SD_CMD, data);
}

void TreeModel::updateModel(Dossier *d)
{
    m_listeChemin.clear();
    Dossier *p = d;
    while (p->getParent()) {
        m_listeChemin.push_back(p->getParent()->indexOf(p));
        p = p->getParent();
    }
    m_currentItem = m_rootItem;
    QByteArray data(1, CMD_CDROOT);
    bool ok = m_manager->receiveMulti(CAN_SD_CMD+1, this, SLOT(updateModelContinue()));
    if (!ok) {
        emit modelUpdated(false);
        return;
    }
    m_manager->send(CAN_SD_CMD, data);
}

void TreeModel::updateModelContinue()
{
    QString str = m_manager->getMultiReply();
    Dossier *d = static_cast<Dossier *>(m_currentItem);
    if (!d->isFilled()) {
        beginResetModel();
        d->fill(const_cast<char *>(str.toStdString().c_str()));
        endResetModel();
    }
    if (!m_listeChemin.isEmpty()) {
        int n = m_listeChemin.takeLast();
        m_currentItem = d->getDir(n);
        QByteArray data(1, CMD_CD_NUM);
        data.append(n);
        bool ok = m_manager->receiveMulti(CAN_SD_CMD+1, this, SLOT(updateModelContinue()));
        if (!ok) {
            emit modelUpdated(false);
            return;
        }
        m_manager->send(CAN_SD_CMD, data);
    } else {
        Dossier *d = findUnFilled(m_rootItem);
        if (d) {
            updateModel(d);
            return;
        }
        sort(0);
        emit modelUpdated(true);
    }
}

Dossier *TreeModel::findUnFilled(Dossier *d)
{
    if (!d->isFilled()) return d;
    Dossier *child;
    int index = 0;
    while ((child = d->getDir(index)) != nullptr) {
        if (!child->isFilled()) {
            return child;
        } else {
            Dossier *p = findUnFilled(child);
            if (p) return p;
        }
        index++;
    }
    return nullptr;
}

void TreeModel::startRemoteMkdir(const QString &chemin)
{
    QByteArray cmd(1, CMD_MKDIR);
    m_manager->sendMulti(CAN_SD_CMD, chemin.toLocal8Bit(), nullptr, nullptr, cmd);
    m_manager->receiveMulti(CAN_SD_CMD+1, this, SLOT(mkdirGetReply()));
}

void TreeModel::mkdirGetReply()
{
    qDebug() << m_manager->getMultiReply();
}

void TreeModel::startRemoteMkfile(const QString &chemin)
{
    QByteArray cmd(1, CMD_MKFILE);
    m_manager->sendMulti(CAN_SD_CMD, chemin.toLocal8Bit(), nullptr, nullptr, cmd);
    m_manager->receiveMulti(CAN_SD_CMD+1, this, SLOT(mkdirGetReply()));
}

void TreeModel::mkfileGetReply()
{
    qDebug() << m_manager->getMultiReply();
}

void TreeModel::startRemoteRename(const QString &src, const QString &dest)
{
    QString data = src + ":" + dest;
    QByteArray cmd(1, CMD_RENAME);
    m_manager->sendMulti(CAN_SD_CMD, data.toLocal8Bit(), nullptr, nullptr, cmd);
    m_manager->receiveMulti(CAN_SD_CMD+1, this, SLOT(mkdirGetReply()));
}

void TreeModel::renameGetReply()
{
    qDebug() << m_manager->getMultiReply();
}

void TreeModel::startRemoteRemove(const QString &chemin)
{
    QByteArray cmd(1, CMD_DEL_NAME);
    m_manager->sendMulti(CAN_SD_CMD, chemin.toLocal8Bit(), nullptr, nullptr, cmd);
    m_manager->receiveMulti(CAN_SD_CMD+1, this, SLOT(removeGetReply()));
}

void TreeModel::removeGetReply()
{
    qDebug() << m_manager->getMultiReply();
}

bool TreeModel::upload(const QString &sourceFilename, QString &destFilename, bool forceIfExist, QString &altNameIfExist)
{
    Fichier *f = m_rootItem->findFile(destFilename.toStdString());
    if (f) {
        if (forceIfExist) {
            startRemoteUploadExistFile(sourceFilename, destFilename);
            return true;
        }
        Dossier *d = f->getParent();
        altNameIfExist = QString::fromStdString(d->getFullName() + "/" + d->suggestFileName(f->getName()));
        return false;
    }
    QString destPath = QString::fromStdString(Fichier::dirOfFile(destFilename.toStdString()));
    Dossier *d = m_rootItem->findDir(destPath.toStdString());
    if (!d) {
        d = m_rootItem;
        destFilename = "/";
        destPath = "/";
    } else if (destPath != QString::fromStdString(d->getFullName())) {
        if (!((destPath=="/")&&(d->getFullName()==""))) {
            destFilename = QString::fromStdString(d->getFullName() + "/");
            destPath = QString::fromStdString(d->getFullName());
        }
    }
    string name = Fichier::nameOfFile(destFilename.toStdString());
    if (name.size() == 0) {
        QFileInfo fi(sourceFilename);
        name = fi.fileName().toStdString();
        if (!Fichier::isValidFileName(name)) {
            name = fi.completeBaseName().left(8).toStdString();
            if (fi.suffix().size() > 0) {
                name += "." + fi.suffix().left(3).toStdString();
            }
            Fichier::validate(name);
        }
        destFilename += QString::fromStdString(name);
        if (d->fileExist(name)) {
            altNameIfExist = QString::fromStdString(d->getFullName() + "/" + d->suggestFileName(name));
        } else if (d->dirExist(name)) {
            destFilename = QString::fromStdString(d->getFullName() + "/" + d->suggestFileName(name));
        }
        return false;
    }
    if (!Fichier::isValidFileName(name)) {
        Fichier::validate(name);
        destFilename = destPath + "/" + QString::fromStdString(name);
        return false;
    }
    int row = d->childCount();
    QModelIndex parent = getPathModelIndex(destPath);
    beginInsertRows(parent, row, row);
    Fichier *newFile = d->addFile(name);
    startRemoteUploadCreateFile(sourceFilename, QString::fromStdString(newFile->getFullName()));
    endInsertRows();
    return true;
}

bool TreeModel::copy(const QString &sourceFilename, QString &destFilename, bool forceIfExist, QString &altNameIfExist)
{
    Fichier *f = m_rootItem->findFile(destFilename.toStdString());
    if (f) {
        if (forceIfExist) {
            startRemoteCopyExistFile(sourceFilename, destFilename);
            return true;
        }
        Dossier *d = f->getParent();
        altNameIfExist = QString::fromStdString(d->getFullName() + "/" + d->suggestFileName(f->getName()));
        return false;
    }
    QString destPath = QString::fromStdString(Fichier::dirOfFile(destFilename.toStdString()));
    Dossier *d = m_rootItem->findDir(destPath.toStdString());
    if (!d) {
        d = m_rootItem;
        destFilename = "/";
        destPath = "/";
    } else if (destPath != QString::fromStdString(d->getFullName())) {
        if (!((destPath=="/")&&(d->getFullName()==""))) {
            destFilename = QString::fromStdString(d->getFullName() + "/");
            destPath = QString::fromStdString(d->getFullName());
        }
    }
    string name = Fichier::nameOfFile(destFilename.toStdString());
    if (name.size() == 0) {
        QFileInfo fi(sourceFilename);
        name = fi.fileName().toStdString();
        if (!Fichier::isValidFileName(name)) {
            name = fi.completeBaseName().left(8).toStdString();
            if (fi.suffix().size() > 0) {
                name += "." + fi.suffix().left(3).toStdString();
            }
            Fichier::validate(name);
        }
        destFilename += QString::fromStdString(name);
        if (d->fileExist(name)) {
            altNameIfExist = QString::fromStdString(d->getFullName() + "/" + d->suggestFileName(name));
        } else if (d->dirExist(name)) {
            destFilename = QString::fromStdString(d->getFullName() + "/" + d->suggestFileName(name));
        }
        return false;
    }
    if (!Fichier::isValidFileName(name)) {
        Fichier::validate(name);
        destFilename = destPath + "/" + QString::fromStdString(name);
        return false;
    }
    int row = d->childCount();
    QModelIndex parent = getPathModelIndex(destPath);
    beginInsertRows(parent, row, row);
    Fichier *newFile = d->addFile(name);
    startRemoteCopyCreateFile(sourceFilename, QString::fromStdString(newFile->getFullName()));
    endInsertRows();
    return true;
}

void TreeModel::startRemoteUploadExistFile(const QString &filename, const QString &dest)
{
    emit progressValue(0);
    m_uploadFile.setFileName(filename);
    m_uploadFile.open(QIODevice::ReadOnly);
    m_sizeFile = m_uploadFile.size()+1;
    m_transferred = 0;
    QByteArray cmd(1, CMD_UPLOAD_EXIST);
    m_manager->sendMulti(CAN_SD_CMD, dest.toLocal8Bit(), nullptr, nullptr, cmd);
    m_manager->receiveMulti(CAN_SD_CMD+1, this, SLOT(uploadDatas()));
}

void TreeModel::startRemoteUploadCreateFile(const QString &filename, const QString &dest)
{
    emit progressValue(0);
    m_uploadFile.setFileName(filename);
    m_uploadFile.open(QIODevice::ReadOnly);
    m_sizeFile = m_uploadFile.size()+1;
    m_transferred = 0;
    QByteArray cmd(1, CMD_UPLOAD_CREATE);
    m_manager->sendMulti(CAN_SD_CMD, dest.toLocal8Bit(), nullptr, nullptr, cmd);
    m_manager->receiveMulti(CAN_SD_CMD+1, this, SLOT(uploadDatas()));
}

void TreeModel::uploadDatas()
{
    emit progressValue(m_transferred * 100 / m_sizeFile);
    QByteArray data = m_uploadFile.read(PACKET_SIZE);
    m_transferred += data.size();
    if (m_uploadFile.atEnd()) {
        m_uploadFile.close();
        m_manager->receiveMulti(CAN_SD_CMD+1, this, SLOT(uploadGetReply()));
        QByteArray cmd(1, 1);
        m_manager->sendMulti(CAN_SD_CMD+2, data, nullptr, nullptr, cmd);
    } else {
        m_manager->sendMulti(CAN_SD_CMD+2, data, this, SLOT(uploadDatas()));
    }
}

void TreeModel::uploadGetReply()
{
    emit progressValue(100);
    emit uploadFinished(true);
}

void TreeModel::startRemoteCopyExistFile(const QString &filename, const QString &dest)
{
    QString data = filename + ":" + dest;
    QByteArray cmd(1, CMD_COPY_EXIST);
    m_manager->sendMulti(CAN_SD_CMD, data.toLocal8Bit(), nullptr, nullptr, cmd);
    m_manager->receiveMulti(CAN_SD_CMD+1, this, SLOT(copyGetReply()));
}

void TreeModel::startRemoteCopyCreateFile(const QString &filename, const QString &dest)
{
    QString data = filename + ":" + dest;
    QByteArray cmd(1, CMD_COPY_CREATE);
    m_manager->sendMulti(CAN_SD_CMD, data.toLocal8Bit(), nullptr, nullptr, cmd);
    m_manager->receiveMulti(CAN_SD_CMD+1, this, SLOT(copyGetReply()));
}

void TreeModel::copyGetReply()
{
    qDebug() << m_manager->getMultiReply();
}

bool TreeModel::download(const QString &source, const QString &filename)
{
    emit progressValue(0);
    m_downloadFile.setFileName(filename);
    m_downloadFile.open(QIODevice::WriteOnly);
    m_downloadFile.resize(0);
    m_sizeFile = 0xFFFFFF;
    m_transferred = 0;
    QByteArray cmd(1, CMD_DOWNLOAD);
    m_manager->sendMulti(CAN_SD_CMD, source.toLocal8Bit(), nullptr, nullptr, cmd);
    m_manager->receiveMulti(CAN_SD_CMD+2, this, SLOT(downloadDatas()), true);
    return true;
}

void TreeModel::downloadDatas()
{
    QByteArray rep = m_manager->getMultiReply();
    m_transferred += rep.size();
    m_sizeFile = m_manager->getMultiExtraTotalSize();
    if (m_transferred < m_sizeFile) {
        m_manager->receiveMulti(CAN_SD_CMD+2, this, SLOT(downloadDatas()), true);
    }
    m_manager->send(CAN_SD_CMD+2);
    m_downloadFile.write(rep);
    if (m_transferred >= m_sizeFile) {
        m_downloadFile.close();
        emit progressValue(100);
        emit downloadFinished(true);
    } else {
        emit progressValue(m_transferred * 100 / m_sizeFile);
    }
}

QModelIndex TreeModel::getPathModelIndex(const QString &path)
{
    QModelIndex idx;
    QStringList liste = path.split('/');
    // liste vide : pas normal
    if (liste.isEmpty()) return idx;
    // premier élément pas vide : pas chemin absolu
    if (!liste[0].isEmpty()) return idx;
    Dossier *d = m_rootItem;
    for (int i=1; i<liste.size(); i++) {
        if (!d->dirExist(liste[i].toStdString())) break;
        d = d->getDir(liste[i].toStdString());
        idx = index(d->row(), 0, idx);
    }
    return idx;
}

void TreeModel::sort(int column, Qt::SortOrder order)
{
    Q_UNUSED(column)
    Q_UNUSED(order)
    beginResetModel();
    m_rootItem->sort();
    endResetModel();
}

//*************** Gestion du drop d'un fichier local
// Vérifie qu'on essaie de dropper un fichier local
bool TreeModel::canDropMimeData(const QMimeData *data, Qt::DropAction action, int row, int column, const QModelIndex &parent) const
{
    if (data->hasFormat("text/uri-list")) return true;
    return QAbstractItemModel::canDropMimeData(data, action, row, column, parent);
}

// Traite le drop
bool TreeModel::dropMimeData(const QMimeData *data, Qt::DropAction action, int row, int column, const QModelIndex &parent)
{
    Q_UNUSED(row)
    Q_UNUSED(column)
    if (action != Qt::CopyAction) return false;
    if (data->hasFormat("application/x-sdremote")) {
        QString filename = data->data("application/x-sdremote");
        emit selectCopyName(parent, filename);
        return true;
    }
    if (!data->hasUrls()) return false;
    if (data->urls().size() != 1) return false;
    if (!data->urls().at(0).isLocalFile()) return false;
    QString filename = data->urls().at(0).toLocalFile();
    emit selectUploadName(parent, filename);
    return true;
}

QStringList TreeModel::mimeTypes() const
{
    QStringList liste;
    liste.push_back("application/x-sdremote");
    return liste;
}

QMimeData *TreeModel::mimeData(const QModelIndexList &indexes) const
{
    if (indexes.size() != 1) return nullptr;
    QMimeData *data = new QMimeData;
    QByteArray fullName = QString(static_cast<Fichier *>(indexes[0].internalPointer())->getFullName().c_str()).toLocal8Bit();
    data->setData("application/x-sdremote", fullName);
    return data;
}

// Définit les données du drag

// ************** Fin gestion du drop d'un fichier local

