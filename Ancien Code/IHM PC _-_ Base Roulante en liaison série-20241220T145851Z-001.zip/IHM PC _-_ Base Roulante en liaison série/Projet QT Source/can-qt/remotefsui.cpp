#include <QAction>
#include <QLineEdit>
#include <QToolTip>
#include <QFileDialog>
#include <QMessageBox>
#include <QMenu>
#include <QDebug>
#include "remotefsui.h"
#include "ui_remotefsui.h"
#include "remoteFileSystem.h"
RemoteFsUi::RemoteFsUi(CanBusManager *manager, QWidget *parent) :
    QMainWindow(parent),
    m_ui(new Ui::RemoteFsUi),
    m_manager(manager)
{
    m_ui->setupUi(this);
    m_ui->dockWidget->setTitleBarWidget(new QWidget());
    m_ui->progressBar->hide();
    m_ui->treeView->setDisabled(true);
    m_ui->saveButton->setDisabled(true);
    m_ui->fileName->setText("");
    m_ui->uploadButton->setDisabled(true);
    m_ui->downloadButton->setDisabled(true);
    m_treeViewMenu = new QMenu(this);
    m_fileModel = new TreeModel(m_manager, this);
    m_dialogUpload = new DialogUpload(m_fileModel, this);
    m_editFilePath = "";
    m_editFileName = "new.txt";
    m_ui->treeView->setModel(m_fileModel);
    m_ui->treeView->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(m_ui->treeView, SIGNAL(customContextMenuRequested(const QPoint &)), this, SLOT(onTreeViewContextMenu(const QPoint &)));
    connect(m_ui->treeView->selectionModel(), &QItemSelectionModel::currentChanged, this, &RemoteFsUi::treeViewItemActivated);
    m_ui->treeView->setDragDropMode(QAbstractItemView::DragDrop);
    m_ui->treeView->setAcceptDrops(true);
    m_ui->treeView->setAutoExpandDelay(500);
    ItemDelegate *delegate = new ItemDelegate(m_ui->treeView);
    m_ui->treeView->setItemDelegate(delegate);
    connect(m_fileModel, SIGNAL(modelUpdated(bool)), m_ui->treeView, SLOT(setEnabled(bool)));
    connect(m_fileModel, SIGNAL(uploadFinished(bool)), this, SLOT(uploadFinished(bool)));
    connect(m_fileModel, SIGNAL(downloadFinished(bool)), this, SLOT(downloadFinished(bool)));
    connect(m_fileModel, SIGNAL(progressValue(int)), m_ui->progressBar, SLOT(setValue(int)));
    connect(m_fileModel, SIGNAL(selectUploadName(const QModelIndex &, const QString &)), this, SLOT(upload(const QModelIndex &, const QString &)));
    connect(m_fileModel, SIGNAL(selectCopyName(const QModelIndex &, const QString &)), this, SLOT(copy(const QModelIndex &, const QString &)));
    connect(m_ui->textEdit, SIGNAL(textChanged()), this, SLOT(on_textChanged()));
    connect(m_ui->refreshButton, SIGNAL(clicked()), this, SLOT(on_actionRefresh()));
    connect(m_ui->saveButton, SIGNAL(clicked()), this, SLOT(on_actionSave()));
    connect(m_ui->downloadButton, SIGNAL(clicked()), this, SLOT(on_actionEdit()));
    connect(m_ui->uploadButton, SIGNAL(clicked()), this, SLOT(on_actionSaveAs()));
    setAttribute(Qt::WA_QuitOnClose, false);
}
RemoteFsUi::~RemoteFsUi()
{
    delete m_ui;
    m_ui = nullptr;
    delete m_fileModel;
    m_fileModel = nullptr;
    delete m_dialogUpload;
    m_dialogUpload = nullptr;
}
void RemoteFsUi::treeViewItemActivated(const QModelIndex &current, const QModelIndex &previous)
{
    Q_UNUSED(previous)
    Fichier *f = static_cast<Fichier *>(current.internalPointer());
    Dossier *d = f->toDossier();
    bool isFile = !d;
    m_ui->downloadButton->setEnabled(isFile);
    m_ui->uploadButton->setEnabled(true);
    if (isFile) return;
    if (!d->isFilled()) m_fileModel->updateModel(d);
}
void RemoteFsUi::onTreeViewContextMenu(const QPoint &point)
{
    QModelIndex index = m_ui->treeView->indexAt(point);
    if (!index.isValid()) {
        m_ui->treeView->clearSelection();
        setMenuDossier(nullptr);
    } else {
        Fichier *f = static_cast<Fichier *>(index.internalPointer());
        Dossier *d = f->toDossier();
        if (d) setMenuDossier(d); else setMenuFichier(f);
    }
    m_treeViewMenu->exec(m_ui->treeView->viewport()->mapToGlobal(point));
}
void RemoteFsUi::setMenuDossier(Dossier *d)
{
    QAction *a;
    QString name = (d) ? QString::fromStdString(d->getFullName()) : "/";
    m_treeViewMenu->clear();
    m_treeViewMenu->addAction(QString(tr("Dossier : ")) + name);
    m_treeViewMenu->addSeparator();
    a = m_treeViewMenu->addAction(tr("Créer nouveau dossier"));
    connect(a, SIGNAL(triggered()), this, SLOT(on_actionNewDir()));
    a = m_treeViewMenu->addAction(tr("Créer nouveau fichier"));
    connect(a, SIGNAL(triggered()), this, SLOT(on_actionNewFile()));
    a = m_treeViewMenu->addAction(tr("Upload"));
    connect(a, SIGNAL(triggered()), this, SLOT(on_actionUpload()));
    if (d) {
        a = m_treeViewMenu->addAction(tr("Renommer"));
        connect(a, SIGNAL(triggered()), this, SLOT(on_actionRename()));
        if (d->isEmpty()) {
            a = m_treeViewMenu->addAction(tr("Supprimer"));
            connect(a, SIGNAL(triggered()), this, SLOT(on_actionDelete()));
        }
    }
}
void RemoteFsUi::setMenuFichier(Fichier *f)
{
    QAction *a;
    m_treeViewMenu->clear();
    m_treeViewMenu->addAction(QString(tr("Fichier : ")) + QString::fromStdString(f->getFullName()));
    m_treeViewMenu->addSeparator();
    a = m_treeViewMenu->addAction(tr("Editer"));
    connect(a, SIGNAL(triggered()), this, SLOT(on_actionEdit()));
    a = m_treeViewMenu->addAction(tr("Renommer"));
    connect(a, SIGNAL(triggered()), this, SLOT(on_actionRename()));
    a = m_treeViewMenu->addAction(tr("Supprimer"));
    connect(a, SIGNAL(triggered()), this, SLOT(on_actionDelete()));
    a = m_treeViewMenu->addAction(tr("Download"));
    connect(a, SIGNAL(triggered()), this, SLOT(on_actionDownload()));
}
void RemoteFsUi::on_actionRefresh()
{
    m_ui->downloadButton->setEnabled(false);
    m_ui->uploadButton->setEnabled(false);
    m_ui->treeView->setEnabled(false);
    m_fileModel->updateModel();
}
void RemoteFsUi::on_actionNewDir()
{
    QItemSelectionModel *ism = m_ui->treeView->selectionModel();
    QModelIndex m = ism->hasSelection() ? m_ui->treeView->currentIndex() : m_ui->treeView->rootIndex();
    if (m_ui->treeView->selectionModel()->selectedIndexes().size() == 0) m = m_ui->treeView->rootIndex();
    int row = m_fileModel->insertDir(m);
    QModelIndex newDir = m_fileModel->index(row , 0, m);
    if (m.isValid()) {
        m_ui->treeView->expand(m);
    }
    m_ui->treeView->setCurrentIndex(newDir);
    m_ui->treeView->edit(newDir);
}
void RemoteFsUi::on_actionNewFile()
{
    QItemSelectionModel *ism = m_ui->treeView->selectionModel();
    QModelIndex m = ism->hasSelection() ? m_ui->treeView->currentIndex() : m_ui->treeView->rootIndex();
    int row = m_fileModel->insertFile(m);
    QModelIndex newFile = m_fileModel->index(row , 0, m);
    if (m.isValid()) {
        m_ui->treeView->expand(m);
    }
    m_ui->treeView->setCurrentIndex(newFile);
    m_ui->treeView->edit(newFile);
}
void RemoteFsUi::on_actionRename()
{
    m_ui->treeView->edit(m_ui->treeView->currentIndex());
}
void RemoteFsUi::on_actionDelete()
{
    QModelIndex index = m_ui->treeView->currentIndex();
    if (!index.isValid()) return;
    Fichier *f = static_cast<Fichier *>(index.internalPointer());
    if (QMessageBox::warning(this, tr("Suppression"), tr("Confirmez-vous la suppression de\n")+QString::fromStdString(f->getFullName()), QMessageBox::Yes | QMessageBox::No, QMessageBox::No) == QMessageBox::Yes) {
        QModelIndex parent = index.parent();
        if (m_fileModel->remove(index)) {
            if (parent.isValid()) {
                m_ui->treeView->setCurrentIndex(parent);
            } else {
               m_ui->treeView->clearSelection();
            }
        }
    }
}
void RemoteFsUi::on_actionUpload()
{
    static QString fileName = "./sdcard";
    fileName = QFileDialog::getOpenFileName(this, tr("Upload"), fileName, tr("Tous les fichiers (*.*)"));
    if (!fileName.isNull()) {
        QItemSelectionModel *ism = m_ui->treeView->selectionModel();
        QModelIndex m = ism->hasSelection() ? m_ui->treeView->currentIndex() : m_ui->treeView->rootIndex();
        upload(m, fileName);
    }
}
void RemoteFsUi::upload(const QModelIndex &parent, const QString &filename)
{
    QString suggestName, altName;
    bool eraseExisting = false;
    Fichier *f;
    if (parent.isValid()) {
        f = static_cast<Fichier *>(parent.internalPointer());
        suggestName = QString::fromStdString(f->getFullName() + "/");
    } else {
        f = m_fileModel->root();
        suggestName = "/";
    }
    while (!m_fileModel->upload(filename, suggestName, eraseExisting, altName)) {
        m_dialogUpload->set(filename, suggestName, altName);
        if (!m_dialogUpload->exec()) return;
        eraseExisting  = m_dialogUpload->get(suggestName);
    }
    m_ui->treeView->setEnabled(false);
    m_ui->progressBar->show();
}
void RemoteFsUi::copy(const QModelIndex &parent, const QString &filename)
{
    QString suggestName, altName;
    bool eraseExisting = false;
    Fichier *f;
    if (parent.isValid()) {
        f = static_cast<Fichier *>(parent.internalPointer());
        suggestName = QString::fromStdString(f->getFullName() + "/");
    } else {
        f = m_fileModel->root();
        suggestName = "/";
    }
    while (!m_fileModel->copy(filename, suggestName, eraseExisting, altName)) {
        m_dialogUpload->set(filename, suggestName, altName);
        if (!m_dialogUpload->exec()) return;
        eraseExisting  = m_dialogUpload->get(suggestName);
    }
}
void RemoteFsUi::uploadFinished(bool ok)
{
    m_ui->treeView->setEnabled(ok);
    m_ui->progressBar->hide();
    QString msg = (ok) ? tr("Upload terminé ") + m_manager->getMultiReply() : tr("Upload erreur");
    m_ui->statusbar->showMessage(msg);
}
void RemoteFsUi::on_actionDownload()
{
    m_edit = false;
    static QString dir = "./sdcard";
    QModelIndex index = m_ui->treeView->currentIndex();
    if (!index.isValid()) return;
    Fichier *f = static_cast<Fichier *>(index.internalPointer());
    QString name = QString::fromStdString(f->getName());
    QString filename = QFileDialog::getSaveFileName(this, tr("Download"), dir + "/" + name, tr("Tous les fichiers (*.*)"));
    if (!filename.isNull()) {
        QFileInfo fi(filename);
        dir = fi.absolutePath();
        if (m_fileModel->download(QString::fromStdString(f->getFullName()), filename)) {
            m_ui->treeView->setEnabled(false);
            m_ui->progressBar->show();
        }
    }
}
void RemoteFsUi::downloadFinished(bool ok)
{
    m_ui->treeView->setEnabled(ok);
    m_ui->progressBar->hide();
    QString msg = (ok) ? tr("Download terminé ") : tr("Download erreur");
    m_ui->statusbar->showMessage(msg);
    if ((ok) && (m_edit)) {
        QFile file("./sdcard/tmp/" + m_editFileName);
        file.open(QFile::ReadOnly | QFile::Text);
        QTextStream ReadFile(&file);
        m_ui->textEdit->setPlainText(ReadFile.readAll());
        m_ui->fileName->setText(m_editFilePath + "/" + m_editFileName);
        m_ui->saveButton->setDisabled(true);
    }
}
void RemoteFsUi::on_actionEdit()
{
    if (m_ui->textEdit->document()->isModified()) {
        if (QMessageBox::warning(this, tr("Texte modifié"), tr("Ignorer les changements ?"), QMessageBox::Yes | QMessageBox::No, QMessageBox::No) == QMessageBox::No) {
            return;
        }
    }
    m_edit = true;
    QString dirPath = "./sdcard/tmp";
    QDir dir;
    dir.mkpath(dirPath);
    QModelIndex editIndex = m_ui->treeView->currentIndex();
    if (!editIndex.isValid()) return;
    Fichier *editFile = static_cast<Fichier *>(editIndex.internalPointer());
    m_editFileName = QString::fromStdString(editFile->getName());
    m_editFilePath = QString::fromStdString(editFile->getParent()->getFullName());
    QString filename = dirPath + "/" + m_editFileName;
    QFileInfo fi(filename);
    if (m_fileModel->download(QString::fromStdString(editFile->getFullName()), filename)) {
        m_ui->treeView->setEnabled(false);
        m_ui->progressBar->show();
    }
}
void RemoteFsUi::on_textChanged()
{
    m_ui->saveButton->setEnabled(true);
}
void RemoteFsUi::saveToTmp(const QString &filename)
{
    QFile file(filename);
    file.open(QIODevice::WriteOnly);
    file.resize(0);
    QTextStream stream(&file);
    stream << m_ui->textEdit->toPlainText();
    file.close();
}
void RemoteFsUi::on_actionSave()
{
    QString filename = "./sdcard/tmp/" + m_editFileName;
    saveToTmp(filename);
    QString suggestName = m_editFilePath + "/" + m_editFileName, altName;
    bool eraseExisting = false;
    while (!m_fileModel->upload(filename, suggestName, eraseExisting, altName)) {
        m_dialogUpload->set(filename, suggestName, altName, false);
        if (!m_dialogUpload->exec()) return;
        eraseExisting  = m_dialogUpload->get(suggestName);
    }
    m_editFileName = QString::fromStdString(Fichier::nameOfFile(suggestName.toStdString()));
    m_editFilePath = QString::fromStdString(Fichier::dirOfFile(suggestName.toStdString()));
    m_ui->fileName->setText(suggestName);
    m_ui->treeView->setEnabled(false);
    m_ui->progressBar->show();
    m_ui->textEdit->document()->setModified(false);
    m_ui->saveButton->setEnabled(false);
}
void RemoteFsUi::on_actionSaveAs()
{
    QModelIndex index = m_ui->treeView->currentIndex();
    Fichier *f = static_cast<Fichier *>(index.internalPointer());
    Dossier *d = f->toDossier();
    QString filename;
    QString suggestName, altName;
    if (d) {
        filename = "./sdcard/tmp/" + m_editFileName;
        suggestName = QString::fromStdString(d->getFullName()) + "/" + m_editFileName;
    } else {
        filename = "./sdcard/tmp/" + QString::fromStdString(f->getName());
        suggestName = QString::fromStdString(f->getFullName());
    }
    saveToTmp(filename);
    bool eraseExisting = false;
    while (!m_fileModel->upload(filename, suggestName, eraseExisting, altName)) {
        m_dialogUpload->set(filename, suggestName, altName, false);
        if (!m_dialogUpload->exec()) return;
        eraseExisting  = m_dialogUpload->get(suggestName);
    }
    m_editFileName = QString::fromStdString(Fichier::nameOfFile(suggestName.toStdString()));
    m_editFilePath = QString::fromStdString(Fichier::dirOfFile(suggestName.toStdString()));
    m_ui->fileName->setText(suggestName);
    m_ui->treeView->setEnabled(false);
    m_ui->progressBar->show();
    m_ui->textEdit->document()->setModified(false);
    m_ui->saveButton->setEnabled(false);
}
ItemDelegate::ItemDelegate(QObject *parent) : QStyledItemDelegate(parent)
{
    m_validator = new QRegularExpressionValidator(this);
    m_startEditor = false;
    m_editor = nullptr;
}
void ItemDelegate::setEditorData(QWidget * editor, const QModelIndex & index) const
{
    QStyledItemDelegate::setEditorData(editor, index);
    const_cast<ItemDelegate *>(this)->m_editor = dynamic_cast<QLineEdit *>(editor);
    if (m_editor) {
        connect(m_editor, SIGNAL(inputRejected()), this, SLOT(inputRejected()));
        Fichier *f = static_cast<Fichier *>(index.internalPointer());
        Dossier *d = f->toDossier();
        QRegularExpression regExp;
        const_cast<ItemDelegate *>(this)->m_editDir = (d != nullptr);
        if (m_editDir) {
            regExp.setPattern("[0-9a-zA-Z_.]+");
        } else {
            regExp.setPattern("[0-9a-zA-Z_.]+");
            connect(m_editor, SIGNAL(selectionChanged()), this, SLOT(modifySelection()));
            const_cast<ItemDelegate *>(this)->m_startEditor = true;
        }
        m_validator->setRegularExpression(regExp);
        m_editor->setValidator(m_validator);
    }
}
void ItemDelegate::inputRejected()
{
    QString msg;
    msg = "Caractères valides\nA-Z a-z 0-9 _ .";
    QToolTip::showText(m_editor->mapToGlobal(QPoint(0,0)), msg);
}
void ItemDelegate::modifySelection()
{
    if (m_startEditor) {
        m_startEditor = false;
        if (m_editor) {
            int pos = m_editor->text().indexOf('.');
            if (pos > 0) m_editor->setSelection(0, pos);
        }
    }
}
