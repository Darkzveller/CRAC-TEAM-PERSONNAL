#include "strategie.h"
#include "ui_strategie.h"
#include "ident_crac.h"




extern "C" {
#include "cybootloaderutils/cybtldr_api.h"
#include "cybootloaderutils/cybtldr_api2.h"
}


static Strategie *fenetre = nullptr;

const int Strategie::ID_BOOTLOAD_WRITE_MULTI = 0x400;
const int Strategie::ID_BOOTLOAD_READ_MULTI = 0x401;
const int Strategie::ID_BOOTLOAD_WRITE = 0x402;
const int Strategie::ID_BOOTLOAD_READ = 0x403;
const int Strategie::ID_MOTEURS_RESET = 0x780;

short origin_x = 0;
short origin_y = 0;
short last_x_robot = 0, last_y_robot = 0;
short offset_theta = 0;

bool FOLLOWXY = false;
int PosBaseCursor_x = 0;
int PosBaseCursor_y = 0;

int count = 0, etat =0; int X[20], Y[20];

static QByteArray dataFromHex(const QString &hex);

// // Définition d'une constante pour le nombre de points de la courbe de puissance de la commande de gaz
//     static const uint16_t THROTTLE_MAP_COUNT = 3;

//     // Tableau de la courbe de puissance de la commande de gaz
//     uint8_t throttleCurve[THROTTLE_MAP_COUNT];

//     // Tableau précalculé des factoriels
//     static const float factorialLookup[33] = {
//         1.0,
//         1.0,
//         2.0,
//         6.0,
//         24.0,
//         120.0,
//         720.0,
//         5040.0,
//         40320.0,
//         362880.0,
//         3628800.0,
//         39916800.0,
//         479001600.0,
//         6227020800.0,
//         87178291200.0,
//         1307674368000.0,
//         20922789888000.0,
//         355687428096000.0,
//         6402373705728000.0,
//         121645100408832000.0,
//         2432902008176640000.0,
//         51090942171709440000.0,
//         1124000727777607680000.0,
//         25852016738884976640000.0,
//         620448401733239439360000.0,
//         15511210043330985984000000.0,
//         403291461126605635584000000.0,
//         10888869450418352160768000000.0,
//         304888344611713860501504000000.0,
//         8841761993739701954543616000000.0,
//         265252859812191058636308480000000.0,
//         8222838654177922817725562880000000.0,
//         263130836933693530167218012160000000.0};
//     // Broches de commande de gauche et de droite du moteur
//     // uint8_t leftPin = A0, rightPin = A1;
//     // Puissance minimale et maximale de la commande de gaz
//     uint8_t minPower = 1, maxPower = 127;
//     // Dernières commandes de la broche gauche et de la broche droite
//     int lastCmdA = 0, lastCmdB = 0;
//     // Fonction pour calculer les factoriels
//     float factorial(int n);
//     // Fonction pour calculer les coefficients binomiaux
//     float Ni(int n, int i);
//     // Fonction pour calculer les polynômes de Bernstein
//     float Bernstein(int n, int i, float t);
//     // Fonction pour calculer les points sur la courbe de Bézier
//     void Bezier2D(float b[], int bCount, int cpts, float p[]);
//     // Constructeur de la classe BezierThrottleControl
//     BezierThrottleControl(uint8_t minPower, uint8_t maxPower, uint8_t lp, uint8_t rp);
//     // Fonction pour définir la plage de la commande de gaz
//     void setThrottleRange(uint8_t minPower, uint8_t maxPower);
//     void loop();


Strategie::Strategie(CanBusManager *manager, QWidget *parent) :
   QMainWindow(parent),
   m_ui(new Ui::Strategie)
{
   m_ui->setupUi(this);
   m_manager = manager;
   fenetre = this;
   connect(m_manager, &CanBusManager::framesReceived , this, &Strategie::checkMessages);
   //connect(m_ui->sendButton_couple_activer, &QPushButton::clicked, this, &Strategie::sendMessageCoupleActiver);
   setAttribute(Qt::WA_QuitOnClose, false);
   scene = new QGraphicsScene(this);

   QPushButton *Table = new QPushButton();
   QPixmap pixmapTable(":/images/table.png");
   QIcon TableIcon(pixmapTable);
   Table->setIcon(TableIcon);
   Table->setIconSize(pixmapTable.rect().size());
   Table->setStyleSheet("background: transparent");
   w = scene->addWidget(Table);

   QPushButton *robot = new QPushButton();
   QPixmap pixmap(":/images/robot.png");
   QIcon RobotIcon(pixmap);
   robot->setIcon(RobotIcon);
   robot->setIconSize(pixmap.rect().size());
   robot->setStyleSheet("background: transparent");
   w = scene->addWidget(robot);
   // Définir un point de rotation personnalisé (ici, à 10 pixels à droite et 10 pixels en bas)
   QPointF custom_rotation_point(118/2, 100/2);
   w->setTransformOriginPoint(custom_rotation_point);
   //QTransform transform;
   //transform.translate(200, 300);
   //m_ui->table->setTransform(transform);
   m_ui->table->setScene(scene);
   positionRobot(0, 0, 0);
   connect(robot, &QPushButton::pressed, this, &Strategie::followXYcursor);
   timer = new QTimer(this);
   // Connexion du signal timeout() au slot correspondant
   connect(timer, &QTimer::timeout, this, &Strategie::monTimer);
   // Démarrage du timer qui se déclenchera toutes les 100 ms
   timer->start(100);
   //cursor_position = QCursor::pos();
/*
 // Create the QGraphicsView
          my_graphics_view = new QGraphicsView(this);
          setCentralWidget(my_graphics_view);
          // Create the QGraphicsScene and add a QPixmap to it
          my_scene = new QGraphicsScene(this);
          my_graphics_view->setStyleSheet("background: transparent");
          my_graphics_view->setAttribute(Qt::WA_TranslucentBackground, true);
          my_graphics_view->setScene(my_scene);
          my_pixmap = new QGraphicsPixmapItem(QPixmap(":/images/robot.png"));
          my_scene->addItem(my_pixmap);
          // Set initial position and rotation of the QPixmap
          double x = 100, y = 100, theta = 90;
          my_pixmap->setPos(x, y);
          my_pixmap->setRotation(theta);
          // Move the QPixmap to a new position
          double new_x = 200, new_y = 200;
          my_pixmap->setPos(new_x, new_y);
          // Rotate the QPixmap
          double new_theta = M_PI / 4; // 45 degrees
          my_pixmap->setRotation(new_theta);*/
}

Strategie::~Strategie()
{
   delete m_ui;
}

static QByteArray dataFromHex(const QString &hex)
{
   QByteArray line = hex.toUtf8();
   line.replace(' ', QByteArray());
   return QByteArray::fromHex(line);
}

void Strategie::positionRobot(short x, short y, short theta)
{
   //200 pixel <-> 1000 mm
   //300 -> 80, x = 300 - 80 = 220

   w->setPos(x,y); last_x_robot = (x); last_y_robot = (y);
//    qDebug("Position de la souris: x=%d, y=%d, bouton : %d, last_x_robot : %d, last_y_robot : %d", cursor_position.x() - PosBaseCursor_x,
////                                                                                                   cursor_position.y() - PosBaseCursor_y,
//                                                                                                   cursor_buttons & Qt::LeftButton),
//                                                                                                   (int)last_x_robot,
//                                                                                                   (int)last_y_robot;
//    //qDebug() << "theta = " << theta;
   if(theta<0){
       w->setRotation((theta/10.0)+360 + offset_theta);
   }else{
       w->setRotation(theta/10.0 + offset_theta);
   }

   m_ui->table->setScene(scene);
}

void Strategie::checkMessages(const QCanBusFrame &frame)
{
   QString view;
   if (frame.frameType() == QCanBusFrame::ErrorFrame) {
       view = m_manager->getErrorString();
   } else {
       view = frame.toString();
   }


   const QString time = QString::fromLatin1("%1.%2  ")
           .arg(frame.timeStamp().seconds(), 10, 10, QLatin1Char(' '))
           .arg(frame.timeStamp().microSeconds() / 100, 4, 10, QLatin1Char('0'));



   if(frame.frameId() == 0x28){
       Odo_x = ((frame.payload()[1]&0xFF)     << 8)   | (frame.payload()[0]&0xFF);
       Odo_y = ((frame.payload()[3]&0xFF)     << 8)   | (frame.payload()[2]&0xFF);
       Odo_theta = (((frame.payload()[5]&0xFF) << 8)   | (frame.payload()[4]&0xFF));
       if(!FOLLOWXY){positionRobot(Odo_x*0.2 + origin_x, Odo_y*0.2 + origin_y , Odo_theta);}
      // QString string_x= QString::number(Odo_x),
      //         string_y= QString::number(Odo_y),
        //       string_theta= QString::number(Odo_theta/10.0);


       //m_ui->textEdit->append(time + "    x = "+ string_x + " mm" + "      y = " + string_y  + " mm" + "      theta = " + string_theta + "°");
   }

   /*cursor_position = QCursor::pos();

   // Afficher les coordonnées X et Y du curseur de la souris
   qDebug("Position de la souris: x=%d, y=%d", cursor_position.x(), cursor_position.y());
   // Convertir la position globale en position locale de la fenêtre*/


}

void Strategie::followXYcursor(){
   if(!FOLLOWXY){
       FOLLOWXY = true;
       cursor_position = QCursor::pos();
       PosBaseCursor_x = cursor_position.x() - last_x_robot;
       PosBaseCursor_y = cursor_position.y() - last_y_robot;
       //qDebug("Position de la souris: x=%d, y=%d, bouton : %d", cursor_position.x(), cursor_position.y(), cursor_buttons & Qt::LeftButton);
   }

}


void Strategie::monTimer(){
   //count++;

   cursor_buttons = qApp->mouseButtons();
   cursor_position = QCursor::pos();
//    Afficher les coordonnées X et Y du curseur de la souris
    /*qDebug("Position de la souris: x=%d, y=%d, bouton : %d, last_x_robot : %d, last_y_robot : %d", cursor_position.x() - PosBaseCursor_x,
                                                                                                   cursor_position.y() - PosBaseCursor_y,
                                                                                                   cursor_buttons & Qt::LeftButton),
                                                                                                   (int)last_x_robot,
                                                                                                   (int)last_y_robot;//*/

   // Convertir la position globale du curseur de la souris en position locale de la fenêtre*///la variation n'est pas la meme mais idk
   if(FOLLOWXY){
       positionRobot(cursor_position.x() - PosBaseCursor_x, cursor_position.y() - PosBaseCursor_y, Odo_theta);
       if(!(cursor_buttons & Qt::LeftButton)){
           FOLLOWXY = false;
           origin_x = cursor_position.x() - PosBaseCursor_x;
           origin_y = cursor_position.y() - PosBaseCursor_y;
       }
   }





}


void Strategie::courbeBezier(int x1, int y1, int x2, int y2)
{



   // Déplacement vers le deuxième point de contrôle
   //Mouvement_Elementaire(sqrt((x2 - xb) * (x2 - xb) + (y2 - yb) * (y2 - yb)), VMAX, AMAX, DMAX, 'l');

   // Déplacement vers la destination finale
   //Mouvement_Elementaire(sqrt((x2 - X_ROBOT) * (x2 - X_ROBOT) + (y2 - Y_ROBOT) * (y2 - Y_ROBOT)), VMAX, AMAX, DMAX, 'l');

   switch (etat)
    {
    case 0:{
       // Calcul des points de contrôle
       int xa = x1 + (x2 - x1) / 3;
       int ya = y1 + (y2 - y1) / 3;
       int xb = x1 + 2 * (x2 - x1) / 3;
       int yb = y1 + 2 * (y2 - y1) / 3;

       long pcons = sqrt((xa - x1) * (xa - x1) + (ya - y1) * (ya - y1));


       // Déplacement vers le premier point de contrôle
       //Mouvement_Elementaire(pcons, VMAX, AMAX, DMAX, 'l');

       // Déplacement selon la courbe de Bézier
        int i = 0;
       for (double t = 0; (t <= 1); t += 0.05)
       {
           int xt = x1 * pow(1 - t, 3) + 3 * xa * t * pow(1 - t, 2) + 3 * xb * pow(t, 2) * (1 - t) + x2 * pow(t, 3);
           int yt = y1 * pow(1 - t, 3) + 3 * ya * t * pow(1 - t, 2) + 3 * yb * pow(t, 2) * (1 - t) + y2 * pow(t, 3);
           int dx = xt - last_x_robot; // X_ROBOT est la position actuelle du robot
           X[i]= dx;
           int dy = yt - last_y_robot; // Y_ROBOT est la position actuelle du robot
           Y[i]= dy;
           //Mouvement_Elementaire(sqrt(dx * dx + dy * dy), VMAX, AMAX, DMAX, 'l');
           i++;
       }

        positionRobot(0, 0, Odo_theta);
        etat = 1;
   }
        break;
    case 1:
        positionRobot(X[count], Y[count], Odo_theta);
        count++;
        if(count>20){count = 0;}
        break;

    default:
        break;
    }

}






















/*
void Strategie::sendMessageCoupleActiver() const
{
   int ID = m_ui->lineEdit_couple->displayText().toInt(nullptr, 10);
   qDebug() << "ID = " << ID;

   QString string_HEX= QString::number(ID, 16);
   if(string_HEX.length() < 2){string_HEX = "0" + string_HEX;}

   m_ui->textEdit->append("Setting Torque on, ID Strategie = 0x" + string_HEX + "  ...");


   QString string_K = string_HEX + "60";
   QByteArray writings = dataFromHex(string_K);

   QCanBusFrame frame;
   writings.truncate(8);

   frame.setPayload(writings);
   qint32 id = ID_Strategie_TORQUE; //m_ui->idEdit->displayText().toInt(nullptr, 16);
   //if (id > 2047) id = 2047;
   frame.setFrameId(id);
   frame.setExtendedFrameFormat(false);
   frame.setFlexibleDataRateFormat(false);
   frame.setBitrateSwitch(false);



   frame.setFrameType(QCanBusFrame::DataFrame);

   m_manager->send(frame);
}*/



void Strategie::on_case0_clicked()//(-775 ; 1275)
{
  // positionRobot(pixmap.rect().size().width(), pixmap.rect().size().width(), Odo_theta);
    //courbeBezier(100, 100, 200, 0);
}




void Strategie::on_case1_clicked()//(775;1275)
{
   positionRobot(80, -380-100, Odo_theta);
}


void Strategie::on_case2_clicked()//(-775;375)
{
   positionRobot(-235, -200-100, Odo_theta);
}


void Strategie::on_case3_clicked()//(775;375)
{
   positionRobot(80, -200-100, Odo_theta);
}


void Strategie::on_case4_clicked()//(-775;-375)
{
   positionRobot(-235, -50-100, Odo_theta);
}


void Strategie::on_case5_clicked()//(775;-375)
{
   positionRobot(80, -50-100, Odo_theta);
}


void Strategie::on_case6_clicked()//(-775;-1275)
{
   positionRobot(-235, 125-100, Odo_theta);
}


void Strategie::on_case7_clicked()//(-275;-1275)
{
   positionRobot(-130, 125-100, Odo_theta);
}


void Strategie::on_case8_clicked()//(275;-1275)
{
   positionRobot(-20, 125-100, Odo_theta);
}


void Strategie::on_case9_clicked()//(775;-1275)
{
   positionRobot(80, 125-100, Odo_theta);
}



void Strategie::on_case3_3_clicked()
{
   offset_theta += 90/8;
}

void Strategie::on_case3_2_clicked()
{
   offset_theta -= 90/8;
}















void Strategie::on_browse()
{
   QString fileName = QFileDialog::getOpenFileName(this,
       tr("Open cyacd"),
       "/home/yves/Documents/qt5/can/PSoC_Creator/CRAC/Moteurs.cydsn/CortexM3/ARM_GCC_541/Release/Moteurs.cyacd"
       , tr("Cypress Bootloadable Files (*.cyacd)"));
   //if (!fileName.isNull()) m_ui->fileName->setText(fileName);
}

void Strategie::showMessage(const char *txt)
{
   //m_ui->status->setText(txt);
}


int Strategie::sendDatas(char *bytes, int size)
{
   if (size <= 8) {
       QByteArray data(bytes, size);
       m_manager->send(ID_BOOTLOAD_READ, data);
       return CYRET_SUCCESS;
   }
   QEventLoop loop;
   QTimer timer;
   timer.setSingleShot(true);
   QByteArray data = CanBusHelper::uint16ToFrame(size);
   connect(this, SIGNAL(rtrReceived()), &loop, SLOT(quit()));
   connect(&timer, SIGNAL(timeout()), &loop, SLOT(quit()));
   int retry = 1;
   while (1) {
       timer.start(1000);
       m_manager->send(ID_BOOTLOAD_READ_MULTI, data);
       loop.exec();
       if (!timer.isActive()) {
           retry--;
           if (retry==0) {
               closeCommunication();
               return CYRET_ERR_UNK;
           }
       } else {
           break;
       }
   }
   data.clear();
   data.append(bytes, size);
   while (data.size() > 0) {
       QByteArray sendData = data.leftJustified(8, '\0', true);
       retry = 2;
       while (1) {
           timer.start(1000);
           m_manager->send(ID_BOOTLOAD_READ_MULTI, sendData);
           loop.exec();
           if (!timer.isActive()) {
               retry--;
               if (retry==0) {
                   closeCommunication();
                   return CYRET_ERR_UNK;
               }
           } else {
               break;
           }
       }
       int n = data.size()-8;
       if (n<=0) data = ""; else data = data.right(n);
   }
   return CYRET_SUCCESS;
}

int Strategie::receiveDatas(char *bytes, int size)
{
   QEventLoop loop;
   QTimer timer;
   timer.setSingleShot(true);
   connect(this, SIGNAL(datasReceived()), &loop, SLOT(quit()));
   connect(&timer, SIGNAL(timeout()), &loop, SLOT(quit()));
   if (!m_receiveDatas.size()) {
       timer.start(1000);
       loop.exec();
       if (!timer.isActive()) {
           closeCommunication();
           return CYRET_ERR_UNK;
       }
   }
   memcpy(bytes, m_receiveDatas.data(), m_receiveDatas.size());
   m_receiveDatas.clear();
   return CYRET_SUCCESS;
}

void Strategie::framesReceived(const QCanBusFrame &frame)
{
   int id = frame.frameId();
   QString idStr = QString("0x%1").arg(id, 3, 16, QLatin1Char('0'));
   if (id == ID_BOOTLOAD_WRITE_MULTI) {
       int size = frame.payload().size();
       if (size == 2) {
           QByteArray data = frame.payload();
           m_size = CanBusHelper::fromFrameToUint16(data);
           m_manager->send(ID_BOOTLOAD_WRITE_MULTI); // rtr
       } else if (size == 8) {
           QByteArray data = frame.payload();
           if (data.size() > m_size) data.truncate(m_size);
           m_receiveDatas += data;
           m_size -= data.size();
           if (m_size == 0) emit datasReceived();
           m_manager->send(ID_BOOTLOAD_WRITE_MULTI); // rtr
       }
   } else if (id == ID_BOOTLOAD_READ_MULTI) {
       if (frame.frameType() == QCanBusFrame::RemoteRequestFrame) {
           emit rtrReceived();
       }
   } else if (id == ID_BOOTLOAD_WRITE) {
       m_receiveDatas = frame.payload();
       emit datasReceived();
       m_manager->send(ID_BOOTLOAD_WRITE);
   } else if (id == ID_BOOTLOAD_READ) {
       if (frame.frameType() == QCanBusFrame::RemoteRequestFrame) {
           emit rtrReceived();
       }
   }
}

int Strategie::openCommunication()
{
   if (!m_manager->isConnected()) return CYRET_ERR_BTLDR;
   recordLink();
   return CYRET_SUCCESS;
}

int Strategie::closeCommunication()
{
   removeLink();
   return CYRET_SUCCESS;
}

extern "C" {

static int openCommunication()
{
   return fenetre->openCommunication();
}

static int closeCommunication()
{
   return fenetre->closeCommunication();
}

static int writeData(unsigned char *bytes, int size)
{
   if (fenetre->sendDatas(reinterpret_cast<char *>(bytes), size)) return CYRET_ERR_UNK;
   return CYRET_SUCCESS;
}

static int readData(unsigned char *bytes, int size)
{
   if (fenetre->receiveDatas(reinterpret_cast<char *>(bytes), size)) return CYRET_ERR_UNK;
   return CYRET_SUCCESS;
}

static CyBtldr_CommunicationsData communication = {
   .OpenConnection = openCommunication,
   .CloseConnection = closeCommunication,
   .ReadData = readData,
   .WriteData = writeData,
   .MaxTransferSize = 64,
};

static void serial_progress_update(unsigned char arrayId, unsigned short rowNum)
{
   char str[100];
   sprintf(str, "Progress: array_id %d, row_num %d\n", arrayId, rowNum);
   fenetre->showMessage(str);
   fenetre->setProgress((100*rowNum)/1023);
}

}

void Strategie::setProgress(int value)
{
   //m_ui->progressBar->setValue(value);
}

void Strategie::on_program()
{
   //m_ui->progressBar->setValue(0);
   //m_ui->progressBar->setVisible(true);
   showMessage("");
   m_manager->send(ID_MOTEURS_RESET, QByteArray()); // reset du PSOC
   QTimer::singleShot(500, this, SLOT(program()));
}

void Strategie::program()
{
   int ret;// = CyBtldr_RunAction(PROGRAM, m_ui->fileName->text().toStdString().c_str(), NULL, 0, &communication, serial_progress_update);
   if (ret != CYRET_SUCCESS) {
       showMessage("Programming failed");
   } else {
       showMessage("Programming success");
   }
   //m_ui->progressBar->setVisible(false);
}












