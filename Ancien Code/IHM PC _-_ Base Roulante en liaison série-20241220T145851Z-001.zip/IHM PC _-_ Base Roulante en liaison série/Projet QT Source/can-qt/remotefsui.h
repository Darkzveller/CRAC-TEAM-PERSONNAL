#ifndef REMOTEFSUI_H
#define REMOTEFSUI_H

#include <QMainWindow>
#include <QStyledItemDelegate>
#include <QItemSelection>

#include "remoteFileSystem.h"
#include "dialogupload.h"

namespace Ui {
class RemoteFsUi;
}

class RemoteFsUi : public QMainWindow
{
    Q_OBJECT

public:
    explicit RemoteFsUi(CanBusManager *manager, QWidget *parent = nullptr);
    ~RemoteFsUi();
private:
    Ui::RemoteFsUi *m_ui;
    CanBusManager *m_manager = nullptr;
    TreeModel *m_fileModel;
    QMenu *m_treeViewMenu;
    DialogUpload *m_dialogUpload;
    bool m_edit;
    QString m_editFileName, m_editFilePath;
    void setMenuDossier(Dossier *d);
    void setMenuFichier(Fichier *f);
    void saveToTmp(const QString &filename);
private slots:
    void treeViewItemActivated(const QModelIndex &current, const QModelIndex &previous);
    void onTreeViewContextMenu(const QPoint &point);
    void on_actionRefresh();
    void on_actionNewDir();
    void on_actionNewFile();
    void on_actionRename();
    void on_actionDelete();
    void on_actionUpload();
    void uploadFinished(bool);
    void on_actionDownload();
    void downloadFinished(bool);
    void on_actionEdit();
    void on_textChanged();
    void on_actionSave();
    void on_actionSaveAs();
public slots:
    void upload(const QModelIndex &parent, const QString &filename);
    void copy(const QModelIndex &parent, const QString &filename);
};

/*! Classe de contrôle de l'édition
 *
 */
class ItemDelegate : public QStyledItemDelegate
{
    Q_OBJECT
public:
    explicit ItemDelegate(QObject *parent = 0);
protected:
    virtual void setEditorData(QWidget * editor, const QModelIndex & index) const override;
protected:
    QRegularExpressionValidator *m_validator;
    QLineEdit *m_editor;
    bool m_editDir;
    bool m_startEditor;
protected slots:
    void inputRejected();
    void modifySelection();
};

#endif // REMOTEFSUI_H
