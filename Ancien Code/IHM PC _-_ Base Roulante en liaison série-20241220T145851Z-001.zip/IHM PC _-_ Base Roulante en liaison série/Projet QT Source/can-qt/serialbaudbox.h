#ifndef SERIALBAUDBOX_H
#define SERIALBAUDBOX_H

#include <QComboBox>

QT_BEGIN_NAMESPACE
class QIntValidator;
QT_END_NAMESPACE

class SerialBaudBox : public QComboBox
{
    Q_OBJECT
public:
    explicit SerialBaudBox(QWidget *parent = nullptr);
    ~SerialBaudBox();

    int bitRate() const;

private slots:
    void checkCustomSpeedPolicy(int idx);

private:
    void fillBitRates();

    QIntValidator *m_customSpeedValidator = nullptr;
};

#endif // SERIALBAUDBOX_H
