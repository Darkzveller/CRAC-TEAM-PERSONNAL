﻿#include "lidar.h"
#include "ui_lidar.h"

#include "ident_crac.h"



extern "C" {
#include "cybootloaderutils/cybtldr_api.h"
#include "cybootloaderutils/cybtldr_api2.h"
}

#define MOITIEE_ROBOT 118
static Lidar *fenetre = nullptr;

const int Lidar::ID_BOOTLOAD_WRITE_MULTI = 0x400;
const int Lidar::ID_BOOTLOAD_READ_MULTI = 0x401;
const int Lidar::ID_BOOTLOAD_WRITE = 0x402;
const int Lidar::ID_BOOTLOAD_READ = 0x403;
const int Lidar::ID_MOTEURS_RESET = 0x780;

bool WAIT_ACK_Lidar_POSITION = false;
bool WAIT_ACK_Lidar_CHANGE_ID = false;



short lastx_robot = 0, lasty_robot = 0;
short offsettheta = 0;

bool FOLLOW = false;
int PosBaseCursorx = 0;
int PosBaseCursory = 0;

int counter = 0, etat_machine =0;// int X_[20], Y[20];

short originx = 0;
short originy = 0;


struct S_Instruction strat_instructions[1000]; // La liste des instruction chargé en mémoire
unsigned char nb_instructions = 0;                             // Le nombre d'instruction dans le fichier de strategie
unsigned char actual_instruction = 0;                      // La ligne de l'instruction en cours d'execution


char etat_ecriture_strat = 0;
bool button_recallage_clicked = false ,button_capture_clicked = false,
    button_depose_clicked = false, button_panier_clicked = false,
    button_arrive_clicked = false;

bool assiette_bleu_carre_clicked = false, assiette_bleu_rondeHC_clicked = false,
    assiette_bleu_rondeBC_clicked = false, assiette_bleu_rondeDH_clicked = false,
    assiette_bleu_rondeDB_clicked = false,assiette_verte_carre_clicked = false,
    assiette_verte_rondeHC_clicked = false, assiette_verte_rondeBC_clicked = false,
    assiette_verte_rondeDH_clicked = false, assiette_verte_rondeDB_clicked = false;

bool    button_roseHG_clicked = false, button_roseBG_clicked = false,
        button_roseHD_clicked = false, button_roseBD_clicked = false;
bool button_jauneHG_clicked = false, button_jauneBG_clicked = false, button_jauneHD_clicked = false, button_jauneBD_clicked = false;
bool button_brunHG_clicked = false, button_brunBG_clicked = false, button_brunHD_clicked = false, button_brunBD_clicked = false;

short pos_strat_x = 225, pos_strat_y = 300, pos_strat_theta = 900;
QString choixCouleur = " ";
//button :
    //cotés table :
QPushButton *cote_table_G; QPushButton *cote_table_D;
QPushButton *cote_table_H; QPushButton *cote_table_B;
  //assiette :
QPushButton *assiette_verte_carree ; QPushButton *assiette_bleu_carree ;
QPushButton *assiette_bleu_ronde_CH ; QPushButton *assiette_bleu_ronde_CB ;
QPushButton *assiette_bleu_ronde_DH ; QPushButton *assiette_bleu_ronde_DB ;
QPushButton *assiette_verte_ronde_CH ; QPushButton *assiette_verte_ronde_CB ;
QPushButton *assiette_verte_ronde_DH ; QPushButton *assiette_verte_ronde_DB ;
    //port cerises
QPushButton *port_cerises_G; QPushButton *port_cerises_H;
QPushButton *port_cerises_B; QPushButton *port_cerises_D;

    //gateau :
QPushButton *roseHD; QPushButton *roseHG;
QPushButton *roseBD; QPushButton *roseBG;

QPushButton *jauneHD; QPushButton *jauneHG;
QPushButton *jauneBD; QPushButton *jauneBG;

QPushButton *marronHD; QPushButton *marronHG;
QPushButton *marronBD; QPushButton *marronBG;

QPushButton *pile_gateau_RJM; QPushButton *pile_gateau_MJR;
QPushButton *pile_gateau_RJ; QPushButton *pile_gateau_JR;
QPushButton *pile_gateau_M;

// .

QPen redline(Qt::red,3,Qt::SolidLine);
QPen blackline(Qt::black,3,Qt::SolidLine);
static QGraphicsItem *item[1000]; int nb_item = 0;

long map(long x, long in_min, long in_max, long out_min, long out_max)
{
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

static QByteArray dataFromHexa(const QString &hex)
{
    QByteArray line = hex.toUtf8();
    line.replace(' ', QByteArray());
    return QByteArray::fromHex(line);
}

void ecriture_strategie();
void set_color_button_assiette(bool verte_carree, bool bleu_carree,
                               bool verte_ronde_CB, bool bleu_ronde_CB,
                               bool verte_ronde_CH, bool bleu_ronde_CH,
                               bool verte_ronde_DB, bool bleu_ronde_DB,
                               bool verte_ronde_DH, bool bleu_ronde_DH);
void set_color_gateau(bool HG, bool HD, bool BG, bool BD);
void set_color_port_cerises(bool Gauche, bool Haut, bool Bas,bool Droite);
void set_color_cote_table(bool Gauche, bool Haut, bool Bas,bool Droite);
void showPartGateau(bool show);

Lidar::Lidar(CanBusManager *manager, QWidget *parent) :
    QMainWindow(parent),
    m_ui(new Ui::Lidar)
{
    m_ui->setupUi(this);


    m_manager = manager;

    fenetre = this;


    connect(m_manager, &CanBusManager::framesReceived , this, &Lidar::checkMessages);
    setAttribute(Qt::WA_QuitOnClose, false);

    scene = new QGraphicsScene(this);


    if(1){
        cote_table_G = new QPushButton();
        QPixmap pixmap(":/images/cote_table_GD.png");
        QIcon Icon(pixmap);

        cote_table_G->setIcon(Icon);
        cote_table_G->setIconSize(pixmap.rect().size());
        cote_table_G->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(cote_table_G);
        short x = 0, y = -22;
        obj3->setPos((y * 0.2), (x * 0.2));
        m_ui->table->setScene(scene);
        connect(cote_table_G, &QPushButton:: clicked, this, &Lidar::on_button_cote_table_G_clicked);
    }    if(1){
        cote_table_D = new QPushButton();
        QPixmap pixmap(":/images/cote_table_GD.png");
        QIcon Icon(pixmap);

        cote_table_D->setIcon(Icon);
        cote_table_D->setIconSize(pixmap.rect().size());
        cote_table_D->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(cote_table_D);
        short x = 0, y = 3000;
        obj3->setPos((y * 0.2), (x * 0.2));
        m_ui->table->setScene(scene);
        connect(cote_table_D, &QPushButton:: clicked, this, &Lidar::on_button_cote_table_D_clicked);
    }    if(1){
        cote_table_H = new QPushButton();
        QPixmap pixmap(":/images/cote_table_HB.png");
        QIcon Icon(pixmap);

        cote_table_H->setIcon(Icon);
        cote_table_H->setIconSize(pixmap.rect().size());
        cote_table_H->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(cote_table_H);
        short x = -42, y = 0;
        obj3->setPos((y * 0.2), (x * 0.2));
        m_ui->table->setScene(scene);
        connect(cote_table_H, &QPushButton:: clicked, this, &Lidar::on_button_cote_table_H_clicked);
    }    if(1){
        cote_table_B = new QPushButton();
        QPixmap pixmap(":/images/cote_table_HB.png");
        QIcon Icon(pixmap);

        cote_table_B->setIcon(Icon);
        cote_table_B->setIconSize(pixmap.rect().size());
        cote_table_B->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(cote_table_B);
        short x = 2000 - 22, y = 0;
        obj3->setPos((y * 0.2), (x * 0.2));
        m_ui->table->setScene(scene);
        connect(cote_table_B, &QPushButton:: clicked, this, &Lidar::on_button_cote_table_B_clicked);

    }

    QPushButton *Table = new QPushButton();
    QPixmap pixmapTable(":/images/table2.png");
    QIcon TableIcon(pixmapTable);
    Table->setIcon(TableIcon);
    Table->setIconSize(pixmapTable.rect().size());
    Table->setStyleSheet("background: transparent");
    w = scene->addWidget(Table);
    w->setPos(0,0);
    m_ui->table->setScene(scene);



    if(1){//assiette_verte_carree
        //creationBouton(*assiette_verte_carree, ":/images/assiette_verte_carree.png", 0, 0, &Lidar::on_button_assiette_verte_carre_clicked);
        assiette_verte_carree = new QPushButton();
        QPixmap pixmap(":/images/assiette_verte_carree.png");
        QIcon Icon(pixmap);

        assiette_verte_carree->setIcon(Icon);
        assiette_verte_carree->setIconSize(pixmap.rect().size());
        assiette_verte_carree->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(assiette_verte_carree);
        short x = 0, y = 0;
        obj3->setPos((y * 0.2), (x * 0.2));
        m_ui->table->setScene(scene);
        connect(assiette_verte_carree, &QPushButton:: clicked, this, &Lidar::on_button_assiette_verte_carre_clicked);
    }
    if(1){//assiette_bleu_carree
        assiette_bleu_carree = new QPushButton();
        QPixmap pixmap(":/images/assiette_bleu_carree.png");
        QIcon Icon(pixmap);

        assiette_bleu_carree->setIcon(Icon);
        assiette_bleu_carree->setIconSize(pixmap.rect().size());
        assiette_bleu_carree->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(assiette_bleu_carree);
        short x = 2000-450, y = 0;
        obj3->setPos((y * 0.2), (x * 0.2));
        m_ui->table->setScene(scene);
        connect(assiette_bleu_carree, &QPushButton:: clicked, this, &Lidar::on_button_assiette_bleu_carre_clicked);
    }

    if(1){//assiette_bleu_ronde
        assiette_bleu_ronde_CH = new QPushButton();
        QPixmap pixmap(":/images/assiette_bleu_ronde.png");
        QIcon Icon(pixmap);

        assiette_bleu_ronde_CH->setIcon(Icon);
        assiette_bleu_ronde_CH->setIconSize(pixmap.rect().size());
        assiette_bleu_ronde_CH->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(assiette_bleu_ronde_CH);
        short x = 0, y = 900;
        obj3->setPos((y * 0.2), (x * 0.2));
        m_ui->table->setScene(scene);
        connect(assiette_bleu_ronde_CH, &QPushButton:: clicked, this, &Lidar::on_button_assiette_bleu_rondeHC_clicked);
    }
    if(1){
        assiette_bleu_ronde_CB = new QPushButton();
        QPixmap pixmap(":/images/assiette_bleu_ronde.png");
        QIcon Icon(pixmap);

        assiette_bleu_ronde_CB->setIcon(Icon);
        assiette_bleu_ronde_CB->setIconSize(pixmap.rect().size());
        assiette_bleu_ronde_CB->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(assiette_bleu_ronde_CB);
        short x = 1550, y = 900 +450 +300;
        obj3->setPos((y * 0.2), (x * 0.2));
        m_ui->table->setScene(scene);
        connect(assiette_bleu_ronde_CB, &QPushButton:: clicked, this, &Lidar::on_button_assiette_bleu_rondeBC_clicked);
    }
    if(1){
        assiette_bleu_ronde_DH = new QPushButton();
        QPixmap pixmap(":/images/assiette_bleu_ronde.png");
        QIcon Icon(pixmap);

        assiette_bleu_ronde_DH->setIcon(Icon);
        assiette_bleu_ronde_DH->setIconSize(pixmap.rect().size());
        assiette_bleu_ronde_DH->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(assiette_bleu_ronde_DH);
        short x = 0, y = 3000 - 450;
        obj3->setPos((y * 0.2), (x * 0.2));
        m_ui->table->setScene(scene);
         connect(assiette_bleu_ronde_DH, &QPushButton:: clicked, this, &Lidar::on_button_assiette_bleu_rondeDH_clicked);
    }
    if(1){
        assiette_bleu_ronde_DB = new QPushButton();
        QPixmap pixmap(":/images/assiette_bleu_ronde.png");
        QIcon Icon(pixmap);

        assiette_bleu_ronde_DB->setIcon(Icon);
        assiette_bleu_ronde_DB->setIconSize(pixmap.rect().size());
        assiette_bleu_ronde_DB->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(assiette_bleu_ronde_DB);
        short x = 1050, y = 3000 - 450;
        obj3->setPos((y * 0.2), (x * 0.2));
        m_ui->table->setScene(scene);
        connect(assiette_bleu_ronde_DB, &QPushButton:: clicked, this, &Lidar::on_button_assiette_bleu_rondeDB_clicked);
    }



    if(1){//assiette_verte_ronde
        assiette_verte_ronde_CH = new QPushButton();
        QPixmap pixmap(":/images/assiette_verte_ronde.png");
        QIcon Icon(pixmap);

        assiette_verte_ronde_CH->setIcon(Icon);
        assiette_verte_ronde_CH->setIconSize(pixmap.rect().size());
        assiette_verte_ronde_CH->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(assiette_verte_ronde_CH);
        short x = 0, y = 900 +450 +300;
        obj3->setPos((y * 0.2), (x * 0.2));
        m_ui->table->setScene(scene);
        connect(assiette_verte_ronde_CH, &QPushButton:: clicked, this, &Lidar::on_button_assiette_verte_rondeHC_clicked);
    }
    if(1){
        assiette_verte_ronde_CB = new QPushButton();
        QPixmap pixmap(":/images/assiette_verte_ronde.png");
        QIcon Icon(pixmap);

        assiette_verte_ronde_CB->setIcon(Icon);
        assiette_verte_ronde_CB->setIconSize(pixmap.rect().size());
        assiette_verte_ronde_CB->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(assiette_verte_ronde_CB);
        short x = 1550, y = 900;
        obj3->setPos((y * 0.2), (x * 0.2));
        m_ui->table->setScene(scene);
        connect(assiette_verte_ronde_CB, &QPushButton:: clicked, this, &Lidar::on_button_assiette_verte_rondeBC_clicked);
    }
    if(1){
        assiette_verte_ronde_DH = new QPushButton();
        QPixmap pixmap(":/images/assiette_verte_ronde.png");
        QIcon Icon(pixmap);

        assiette_verte_ronde_DH->setIcon(Icon);
        assiette_verte_ronde_DH->setIconSize(pixmap.rect().size());
        assiette_verte_ronde_DH->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(assiette_verte_ronde_DH);
        short x = 500, y = 3000 - 450;
        obj3->setPos((y * 0.2), (x * 0.2));
        m_ui->table->setScene(scene);
        connect(assiette_verte_ronde_DH, &QPushButton:: clicked, this, &Lidar::on_button_assiette_verte_rondeDH_clicked);
    }
    if(1){
        assiette_verte_ronde_DB = new QPushButton();
        QPixmap pixmap(":/images/assiette_verte_ronde.png");
        QIcon Icon(pixmap);

        assiette_verte_ronde_DB->setIcon(Icon);
        assiette_verte_ronde_DB->setIconSize(pixmap.rect().size());
        assiette_verte_ronde_DB->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(assiette_verte_ronde_DB);
        short x = 1550, y = 3000 - 450;
        obj3->setPos((y * 0.2), (x * 0.2));
        m_ui->table->setScene(scene);
        connect(assiette_verte_ronde_DB, &QPushButton:: clicked, this, &Lidar::on_button_assiette_verte_rondeDB_clicked);
    }



    if(1){
        port_cerises_G = new QPushButton();
        QPixmap pixmap(":/images/port_cerises.png");
        QIcon Icon(pixmap);

        port_cerises_G->setIcon(Icon);
        port_cerises_G->setIconSize(pixmap.rect().size());
        port_cerises_G->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(port_cerises_G);
        short x = 1000 - 30, y = 0;
        obj3->setPos((y * 0.2), (x * 0.2));
        m_ui->table->setScene(scene);
        connect(port_cerises_G, &QPushButton:: clicked, this, &Lidar::on_button_port_cerises_G_clicked);
    }
    if(1){
        port_cerises_H = new QPushButton();
        QPixmap pixmap(":/images/port_cerises.png");
        QIcon Icon(pixmap);

        port_cerises_H->setIcon(Icon);
        port_cerises_H->setIconSize(pixmap.rect().size());
        port_cerises_H->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(port_cerises_H);
        short x = -30, y = 900 + 450;
        obj3->setPos((y * 0.2), (x * 0.2));
        m_ui->table->setScene(scene);
        connect(port_cerises_H, &QPushButton:: clicked, this, &Lidar::on_button_port_cerises_H_clicked);
    }
    if(1){
        port_cerises_B = new QPushButton();
        QPixmap pixmap(":/images/port_cerises.png");
        QIcon Icon(pixmap);

        port_cerises_B->setIcon(Icon);
        port_cerises_B->setIconSize(pixmap.rect().size());
        port_cerises_B->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(port_cerises_B);
        short x = 2000 - 45, y = 900 + 450;
        obj3->setPos((y * 0.2), (x * 0.2));
        m_ui->table->setScene(scene);
        connect(port_cerises_B, &QPushButton:: clicked, this, &Lidar::on_button_port_cerises_B_clicked);
    }
    if(1){
        port_cerises_D = new QPushButton();
        QPixmap pixmap(":/images/port_cerises.png");
        QIcon Icon(pixmap);

        port_cerises_D->setIcon(Icon);
        port_cerises_D->setIconSize(pixmap.rect().size());
        port_cerises_D->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(port_cerises_D);
        short x = 1000 - 30, y = 3000 - 300;
        obj3->setPos((y * 0.2), (x * 0.2));
        m_ui->table->setScene(scene);
        connect(port_cerises_D, &QPushButton:: clicked, this, &Lidar::on_button_port_cerises_D_clicked);
    }




    if(1){//Haut droit
        roseHD = new QPushButton();
        QPixmap pixmap(":/images/face_couche_rose.png");
        QIcon roseIcon(pixmap);

        roseHD->setIcon(roseIcon);
        roseHD->setIconSize(pixmap.rect().size());
        roseHD->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(roseHD);

        short x = 225, y = 3000 - 575;
        obj3->setPos((y * 0.2)-24/2, (x * 0.2)-24/2);
        m_ui->table->setScene(scene);
        connect(roseHD, &QPushButton:: released, this, &Lidar::on_button_roseHD_clicked);
    }
    if(1){
        jauneHD = new QPushButton();
        QPixmap pixmap(":/images/face_couche_jaune.png");
        QIcon jauneIcon(pixmap);

        jauneHD->setIcon(jauneIcon);
        jauneHD->setIconSize(pixmap.rect().size());
        jauneHD->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(jauneHD);
        short x = 225, y = 3000 - 775;
        obj3->setPos((y * 0.2)-24/2, (x * 0.2)-24/2);
        m_ui->table->setScene(scene);
        connect(jauneHD, &QPushButton:: released, this, &Lidar::on_button_jauneHD_clicked);
    }
    if(1){
        marronHD = new QPushButton();
        QPixmap pixmap(":/images/face_couche_brun.png");
        QIcon marronIcon(pixmap);

        marronHD->setIcon(marronIcon);
        marronHD->setIconSize(pixmap.rect().size());
        marronHD->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(marronHD);
        short x = 725, y = 3000 - 1125;
        obj3->setPos((y * 0.2)-24/2, (x * 0.2)-24/2);
        m_ui->table->setScene(scene);
        connect(marronHD, &QPushButton:: released, this, &Lidar::on_button_brunHD_clicked);
    }


    if(1){//Bas droit
        roseBD = new QPushButton();
        QPixmap pixmap(":/images/face_couche_rose.png");
        QIcon roseIcon(pixmap);

        roseBD->setIcon(roseIcon);
        roseBD->setIconSize(pixmap.rect().size());
        roseBD->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(roseBD);

        short x = 2000 - 225, y = 3000 - 575;
        obj3->setPos((y * 0.2)-24/2, (x * 0.2)-24/2);
        m_ui->table->setScene(scene);
        connect(roseBD, &QPushButton:: released, this, &Lidar::on_button_roseBD_clicked);
    }
    if(1){
        jauneBD = new QPushButton();
        QPixmap pixmap(":/images/face_couche_jaune.png");
        QIcon jauneIcon(pixmap);

        jauneBD->setIcon(jauneIcon);
        jauneBD->setIconSize(pixmap.rect().size());
        jauneBD->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(jauneBD);
        short x = 2000 - 225, y = 3000 - 775;
        obj3->setPos((y * 0.2)-24/2, (x * 0.2)-24/2);
        m_ui->table->setScene(scene);
        connect(jauneBD, &QPushButton:: released, this, &Lidar::on_button_jauneBD_clicked);
    }
    if(1){
        marronBD = new QPushButton();
        QPixmap pixmap(":/images/face_couche_brun.png");
        QIcon marronIcon(pixmap);

        marronBD->setIcon(marronIcon);
        marronBD->setIconSize(pixmap.rect().size());
        marronBD->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(marronBD);
        short x = 2000 - 725, y = 3000 - 1125;
        obj3->setPos((y * 0.2)-24/2, (x * 0.2)-24/2);
        m_ui->table->setScene(scene);
        connect(marronBD, &QPushButton:: released, this, &Lidar::on_button_brunBD_clicked);

    }


    if(1){//Haut gauche
        roseHG = new QPushButton();
        QPixmap pixmap(":/images/face_couche_rose.png");
        QIcon roseIcon(pixmap);

        roseHG->setIcon(roseIcon);
        roseHG->setIconSize(pixmap.rect().size());
        roseHG->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(roseHG);

        short x = 225, y = 575;
        obj3->setPos((y * 0.2)-24/2, (x * 0.2)-24/2);
        m_ui->table->setScene(scene);
        connect(roseHG, &QPushButton:: released, this, &Lidar::on_button_roseHG_clicked);

    }
    if(1){
        jauneHG = new QPushButton();
        QPixmap pixmap(":/images/face_couche_jaune.png");
        QIcon jauneIcon(pixmap);

        jauneHG->setIcon(jauneIcon);
        jauneHG->setIconSize(pixmap.rect().size());
        jauneHG->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(jauneHG);
        short x = 225, y = 775;
        obj3->setPos((y * 0.2)-24/2, (x * 0.2)-24/2);
        m_ui->table->setScene(scene);
        connect(jauneHG, &QPushButton:: released, this, &Lidar::on_button_jauneHG_clicked);

    }
    if(1){
        marronHG = new QPushButton();
        QPixmap pixmap(":/images/face_couche_brun.png");
        QIcon marronIcon(pixmap);

        marronHG->setIcon(marronIcon);
        marronHG->setIconSize(pixmap.rect().size());
        marronHG->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(marronHG);
        short x = 725, y = 1125;
        obj3->setPos((y * 0.2)-24/2, (x * 0.2)-24/2);
        m_ui->table->setScene(scene);
        connect(marronHG, &QPushButton:: released, this, &Lidar::on_button_brunHG_clicked);
    }



    if(1){//Bas Gauche
        roseBG = new QPushButton();
        QPixmap pixmap(":/images/face_couche_rose.png");
        QIcon roseIcon(pixmap);

        roseBG->setIcon(roseIcon);
        roseBG->setIconSize(pixmap.rect().size());
        roseBG->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(roseBG);
        short x = 2000-225, y = 575;
        obj3->setPos((y * 0.2)-24/2, (x * 0.2)-24/2);
        m_ui->table->setScene(scene);
        connect(roseBG, &QPushButton:: released, this, &Lidar::on_button_roseBG_clicked);
    }
    if(1){
        jauneBG = new QPushButton();
        QPixmap pixmap(":/images/face_couche_jaune.png");
        QIcon jauneIcon(pixmap);

        jauneBG->setIcon(jauneIcon);
        jauneBG->setIconSize(pixmap.rect().size());
        jauneBG->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(jauneBG);
        short x = 2000-225, y = 775;
        obj3->setPos((y * 0.2)-24/2, (x * 0.2)-24/2);
        m_ui->table->setScene(scene);
        connect(jauneBG, &QPushButton:: released, this, &Lidar::on_button_jauneBG_clicked);
    }
    if(1){
        marronBG = new QPushButton();
        QPixmap pixmap(":/images/face_couche_brun.png");
        QIcon marronIcon(pixmap);

        marronBG->setIcon(marronIcon);
        marronBG->setIconSize(pixmap.rect().size());
        marronBG->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(marronBG);
        short x = 2000-725, y = 1125;
        obj3->setPos((y * 0.2)-24/2, (x * 0.2)-24/2);
        m_ui->table->setScene(scene);
        connect(marronBG, &QPushButton:: released, this, &Lidar::on_button_brunBG_clicked);
    }

    if(1){
        pile_gateau_RJM = new QPushButton();
        QPixmap pixmap(":/images/pile_gateau_rose_jaune_brun.png");
        QIcon Icon(pixmap);

        pile_gateau_RJM->setIcon(Icon);
        pile_gateau_RJM->setIconSize(pixmap.rect().size());
        obj3 = scene->addWidget(pile_gateau_RJM);
        obj3->setPos( 300 - 70, -75);
        m_ui->table->setScene(scene);
        connect(pile_gateau_RJM, &QPushButton:: released, this, &Lidar::on_button_pile_gateau_RJM_clicked);
    }
    if(1){
        pile_gateau_MJR = new QPushButton();
        QPixmap pixmap(":/images/pile_gateau_brun_jaune_marron.png");
        QIcon Icon(pixmap);

        pile_gateau_MJR->setIcon(Icon);
        pile_gateau_MJR->setIconSize(pixmap.rect().size());
        obj3 = scene->addWidget(pile_gateau_MJR);
        obj3->setPos( 300 - 35, -75);
        m_ui->table->setScene(scene);
        connect(pile_gateau_MJR, &QPushButton:: released, this, &Lidar::on_button_pile_gateau_MJR_clicked);
    }
    if(1){
        pile_gateau_RJ = new QPushButton();
        QPixmap pixmap(":/images/pile_gateau_rose_jaune.png");
        QIcon Icon(pixmap);

        pile_gateau_RJ->setIcon(Icon);
        pile_gateau_RJ->setIconSize(pixmap.rect().size());
        obj3 = scene->addWidget(pile_gateau_RJ);
        obj3->setPos( 300 +35, -75);
        m_ui->table->setScene(scene);
        connect(pile_gateau_RJ, &QPushButton:: released, this, &Lidar::on_button_pile_gateau_RJ_clicked);
    }
    if(1){
        pile_gateau_JR = new QPushButton();
        QPixmap pixmap(":/images/pile_gateau_jaune_rose.png");
        QIcon Icon(pixmap);

        pile_gateau_JR->setIcon(Icon);
        pile_gateau_JR->setIconSize(pixmap.rect().size());
        obj3 = scene->addWidget(pile_gateau_JR);
        obj3->setPos( 300 + 70, -75);
        m_ui->table->setScene(scene);
        connect(pile_gateau_JR, &QPushButton:: released, this, &Lidar::on_button_pile_gateau_JR_clicked);
    }
    if(1){
        pile_gateau_M = new QPushButton();
        QPixmap pixmap(":/images/pile_gateau_marron.png");
        QIcon Icon(pixmap);

        pile_gateau_M->setIcon(Icon);
        pile_gateau_M->setIconSize(pixmap.rect().size());
        obj3 = scene->addWidget(pile_gateau_M);
        obj3->setPos( 300 + 70 +35, -75);
        m_ui->table->setScene(scene);
        connect(pile_gateau_M, &QPushButton:: released, this, &Lidar::on_button_pile_gateau_M_clicked);
    }
    showPartGateau(false);






    /*if(1){//origin
        QPushButton *origin = new QPushButton();
        QPixmap pixmap(":/images/origin.png");
        QIcon obstacleIcon(pixmap);

        origin->setIcon(obstacleIcon);
        origin->setIconSize(pixmap.rect().size());
        origin->setStyleSheet("background: transparent");
        obj1->setPos(0,0);
        m_ui->table->setScene(scene);

    }
    if(1){//fleche
        QPushButton *droite = new QPushButton();
        QPixmap pixmap(":/images/rotation_droite.png");
        QIcon obstacleIcon(pixmap);

        droite->setIcon(obstacleIcon);
        droite->setIconSize(pixmap.rect().size());
        droite->setStyleSheet("background: transparent");
        DROITE = scene->addWidget(droite);

        connect(droite, &QPushButton::pressed, this, &Lidar::rotation_droite);

        DROITE->setPos(2920*48/240, -15);
        m_ui->table->setScene(scene);

    }
    if(1){//fleche
        QPushButton *gauche = new QPushButton();
        QPixmap pixmap(":/images/rotation_gauche.png");
        QIcon obstacleIcon(pixmap);

        gauche->setIcon(obstacleIcon);
        gauche->setIconSize(pixmap.rect().size());
        gauche->setStyleSheet("background: transparent");
        GAUCHE = scene->addWidget(gauche);


        connect(gauche, &QPushButton::pressed, this, &Lidar::rotation_gauche);

        GAUCHE->setPos(2840*48/240, -15);
        m_ui->table->setScene(scene);

    }//*/
    if(1){//obstacle 1
        QPushButton *obstacle = new QPushButton();
        QPixmap pixmap(":/images/obstacle.png");
        QIcon obstacleIcon(pixmap);

        obstacle->setIcon(obstacleIcon);
        obstacle->setIconSize(pixmap.rect().size());
        obstacle->setStyleSheet("background: transparent");
        obj1 = scene->addWidget(obstacle);
        // Définir un point de rotation personnalisé (ici, à 10 pixels à droite et 10 pixels en bas)
        QPointF custom_rotation_point(48/2, 48/2);
        obj1->setTransformOriginPoint(custom_rotation_point);

        positionObstacle1(-50, -50);

    }
    if(1){//obstacle 2
        QPushButton *obstacle = new QPushButton();
        QPixmap pixmap(":/images/obstacle.png");
        QIcon obstacleIcon(pixmap);

        obstacle->setIcon(obstacleIcon);
        obstacle->setIconSize(pixmap.rect().size());
        obstacle->setStyleSheet("background: transparent");
        obj2 = scene->addWidget(obstacle);
        // Définir un point de rotation personnalisé (ici, à 10 pixels à droite et 10 pixels en bas)
        QPointF custom_rotation_point(48/2, 48/2);
        obj2->setTransformOriginPoint(custom_rotation_point);

        positionObstacle2(-50, -50);
    }
    if(1){//obstacle 3
        QPushButton *obstacle = new QPushButton();
        QPixmap pixmap(":/images/obstacle.png");
        QIcon obstacleIcon(pixmap);

        obstacle->setIcon(obstacleIcon);
        obstacle->setIconSize(pixmap.rect().size());
        obstacle->setStyleSheet("background: transparent");
        obj3 = scene->addWidget(obstacle);
        // Définir un point de rotation personnalisé (ici, à 10 pixels à droite et 10 pixels en bas)
        QPointF custom_rotation_point(48/2, 48/2);
        obj3->setTransformOriginPoint(custom_rotation_point);

        positionObstacle3(-50, -50);
    }//*/




    if(1){//robot
        QPushButton *robot = new QPushButton();
        QPixmap pixmap(":/images/robot.png");
        QIcon RobotIcon(pixmap);

        robot->setIcon(RobotIcon);
        robot->setIconSize(pixmap.rect().size());
        robot->setStyleSheet("background: transparent");
        w = scene->addWidget(robot);
        // Définir un point de rotation personnalisé (ici, à 10 pixels à droite et 10 pixels en b8as)
      //QPointF custom_rotation_point(48/2, 48/2);
        //w->setTransformOriginPoint(custom_rotation_point);

//        QTransform transform;
//        transform.translate(200, 300);
//        m_ui->table->setTransform(transform);
        // Définir un point de rotation personnalisé (ici, à 10 pixels à droite et 10 pixels en bas)
        QPointF custom_rotation_point(48/2, 48/2);
        w->setTransformOriginPoint(custom_rotation_point);

        short posBaseX = 450,posBasey = 450;
        positionRobot((posBaseX*48/240), ((posBasey)*48/240), 900);
        connect(robot, &QPushButton:: pressed, this, &Lidar::followXYcursor);
        MyTimer = new QTimer(this);
        // Connexion du signal timeout() au slot correspondant
        connect(MyTimer, &QTimer::timeout, this, &Lidar::monTimer);
        // Démarrage du timer qui se déclenchera toutes les 100 ms
        MyTimer->start(100);
    }


    set_color_button_assiette(1,1,1,1,1,1,1,1,1,1);

//    scene->addLine(1500*0.2, 1000*0.2, 3000*0.2, 2000*0.2, redline);

}

Lidar::~Lidar()
{
    delete m_ui;
}



void Lidar::checkMessages(const QCanBusFrame &frame)
{
    QString view;
    if (frame.frameType() == QCanBusFrame::ErrorFrame) {
        view = m_manager->getErrorString();
    } else {
        view = frame.toString();
    }
    QCanBusFrame copyFrame = frame;
/*
    const QString time = QString::fromLatin1("%1.%2  ")
            .arg(frame.timeStamp().seconds(), 10, 10, QLatin1Char(' '))
            .arg(frame.timeStamp().microSeconds() / 100, 4, 10, QLatin1Char('0'));//*/

    uint8_t data[8] = {0};
    for(int i = 0; i<frame.payload().length(); i++){
        data[i] = frame.payload()[i]&0xFF;
    }

    if(frame.frameId() == IDCAN_LIDAR_DISTANCE_ANGLE){
        short distance = (data[1]<< 8)   | data[0];
        short angle = (data[3]<< 8)   | data[2];

        m_ui->textEdit->append("angle :  " + QString::number(angle, 10)
                               + ",   distance = " + QString::number(distance, 10)
                               + " ");
    }else if(frame.frameId() == IDCAN_LIDAR_POS_XY_OBJET){
        uint8_t numObjet = data[0];
//        short x = (data[2]<< 8)   | data[1];
//        short y = (data[4]<< 8)   | data[3];
//        int delta_x = x - Odo_x, delta_y = y - Odo_y;
//        int distance_lidar = sqrt((delta_x * delta_x) + (delta_y * delta_y));
        short distance = (data[2]<< 8)   | data[1];
        short angle = (data[4]<< 8)      | data[3];

        m_ui->textEdit->append("Objet detecté :) ! Numéro :  " + QString::number(numObjet, 10)
                                +"angle :  "         + QString::number(angle, 10)
                               + ",   distance = " + QString::number(distance, 10)
                               + " ");
//        int x = Odo_x + cos((angle - Odo_th))

//        if(numObjet){
//            m_ui->textEdit->append("Objet detecté :) ! Numéro :  " + QString::number(numObjet, 10)
//                                   + "angle :  "         + QString::number(angle, 10)
//                                   + ",   distance = " + QString::number(distance, 10)
//                                   + ",   x = " + QString::number(x, 10)
//                                   + ",   y = " + QString::number(y, 10)
//                                   + ",   distance = " + QString::number(distance_lidar, 10)
//                                   + " ");
//            switch (numObjet)
//            {
//            case 1:
//              {
//                  positionObstacle1((y*48/240),((x)*48/240));
//              }
//              break;
//            case 2:
//              {
//                positionObstacle2((y*48/240),((x)*48/240));
//              }
//              break;
//            case 3:
//              {
//                positionObstacle3((y*48/240),((x)*48/240));
//              }
//              break;

//            default:
//              break;
//            }

//        }else{
//            m_ui->textEdit->append("Aucun objet detecté :| !");
//        }

    }else if(frame.frameId() == 0x28){
        Odo_x = ((frame.payload()[1]&0xFF)     << 8)   | (frame.payload()[0]&0xFF);
        Odo_y = ((frame.payload()[3]&0xFF)     << 8)   | (frame.payload()[2]&0xFF);
        Odo_theta = (((frame.payload()[5]&0xFF) << 8)   | (frame.payload()[4]&0xFF));
        if(!FOLLOW){positionRobot((Odo_y)*48.0/240.0 + originy , Odo_x*48.0/240.0 + originx, Odo_theta);}
       // QString string_x= QString::number(Odo_x),
       //         string_y= QString::number(Odo_y),
         //       string_theta= QString::number(Odo_theta/10.0);


        //m_ui->textEdit->append(time + "    x = "+ string_x + " mm" + "      y = " + string_y  + " mm" + "      theta = " + string_theta + "°");
    }


}





void Lidar::monTimer(){
   //count++;

   cursorButtons = qApp->mouseButtons();
   cursorPosition = QCursor::pos();
//    Afficher les coordonnées X et Y du curseur de la souris
    /*qDebug("Position de la souris: x=%d, y=%d, bouton : %d, Position echelle table de x : %d, Position echelle table de y : %d", cursorPosition.x() - PosBaseCursorx,
                                                                                                   cursorPosition.y() - PosBaseCursory,
                                                                                                   cursorButtons & Qt::LeftButton),
                                                                                                   (short)(cursorPosition.x() - PosBaseCursorx)*240.0/48,
                                                                                                   (short)(2000-(cursorPosition.y() - PosBaseCursory)*220.0/40);//*/

   // Convertir la position globale du curseur de la souris en position locale de la fenêtre*///la variation n'est pas la meme mais idk
   if(FOLLOW){
       positionRobot(cursorPosition.x() - PosBaseCursorx, cursorPosition.y() - PosBaseCursory, 0);
       if(!(cursorButtons & Qt::LeftButton)){
           FOLLOW = false;
//           originx = cursorPosition.x() - PosBaseCursorx;
//           originy = cursorPosition.y() - PosBaseCurso+ry;
           short Y = (cursorPosition.x() - PosBaseCursorx)*240.0/48.0;
           short X = ((cursorPosition.y() - PosBaseCursory)*240.0/48.0);
           short theta = Odo_theta;
           short sens = 1;
           int deltaX = X - Odo_x, deltaY = Y - Odo_y;
           if(deltaX<0 || deltaY < 0){sens = -1;}
            qDebug("Deplacement vers x : %d, y : %d, deltaX = %d, deltaY : %d", X, Y, deltaX, deltaY);



            QString string_X;
            QString string_X_2;

            QString string_Y;
            QString string_Y_2;

            QString string_theta;
            QString string_theta_2;

            QString string_sens;

            QString total;


                string_X= QString::number((X&0xFF), 16);
            if(string_X.length()      < 2){string_X = "0" + string_X;}

            string_X_2= QString::number(((X>>8)&0xFF), 16);
            if(string_X_2.length()      < 2){string_X_2 = "0" + string_X_2;}



                string_Y= QString::number((Y&0xFF), 16);
            if(string_Y.length() < 2){string_Y = "0" + string_Y;}

            string_Y_2= QString::number(((Y>>8)&0xFF), 16);
            if(string_Y_2.length() < 2){string_Y_2 = "0" + string_Y_2;}



                string_theta= QString::number((theta&0xFF), 16);
            if(string_theta.length() < 2){string_theta = "0" + string_theta;}

            string_theta_2= QString::number(((theta>>8)&0xFF), 16);
            if(string_theta_2.length() < 2){string_theta_2 = "0" + string_theta_2;}



                string_sens= QString::number((sens&0xFF), 16);
            if(string_sens.length() < 2){string_sens = "0" + string_sens;}


            total = string_X + string_X_2 + string_Y + string_Y_2 + string_theta + string_theta_2 + string_sens;

           m_ui->textEdit->append("");
           m_ui->textEdit->append("StepMotor, Position Control      0x  " + total
                                  + "  ...");

           SendMessageCan(ASSERVISSEMENT_XYT, total);

           //positionObstacle1(x*48/240,(2000-y)*40/220);//pour test sans robot
       }
   }


    ecriture_strategie();


}







void Lidar::SendMessageCan(qint32 id, QString hex){

    QByteArray writings = dataFromHexa(hex);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    //qint32 id = ID_HERKULEX_TORQUE; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);
}



void Lidar::positionRobot(short x, short y, short theta)
{
    //200 pixel <-> 1000 mm
    //300 -> 80, x = 300 - 80 = 220
    w->setPos(x-48/2,y-40/2); lastx_robot = (x); lasty_robot = (y);
//    qDebug("Position de la souris: x=%d, y=%d, bouton : %d, lastx_robot : %d, lasty_robot : %d", cursorPosition.x() - PosBaseCursorx,
////                                                                                                   cursorPosition.y() - PosBaseCursory,
//                                                                                                   cursorButtons & Qt::LeftButton),
//                                                                                                   (int)lastx_robot,
//                                                                                                   (int)lasty_robot;
//    //qDebug() << "theta = " << theta;
    theta *= -1;
    if(theta<0){
        w->setRotation((theta/10.0)+360 + offsettheta);
    }else{
        w->setRotation(theta/10.0 + offsettheta);
    }

    m_ui->table->setScene(scene);
}

void Lidar::positionObstacle1(short x, short y){
    obj1->setPos(x-48/2,y-40/2);
    m_ui->table->setScene(scene);

}
void Lidar::positionObstacle2(short x, short y){
    obj2->setPos(x-48/2,y-40/2);
    m_ui->table->setScene(scene);

}
void Lidar::positionObstacle3(short x, short y){
    obj3->setPos(x-48/2,y-40/2);
    m_ui->table->setScene(scene);
}

void Lidar::followXYcursor(){
   if(!FOLLOW){
       FOLLOW = true;
       cursorPosition = QCursor::pos();
       PosBaseCursorx = cursorPosition.x() - lastx_robot;
       PosBaseCursory = cursorPosition.y() - lasty_robot;
       //qDebug("Position de la souris: x=%d, y=%d, bouton : %d", cursorPosition.x(), cursorPosition.y(), cursorButtons & Qt::LeftButton);
   }

}

void Lidar::rotation_droite(){
    unsigned short K = 45*10;
    QString string_K, string_K_2;
        string_K= QString::number((K&0xFF), 16);
         if(string_K.length() < 2){string_K = "0" + string_K;}

        string_K_2 = QString::number(((K>>8)&0xFF), 16);
        if(string_K_2.length() < 2){string_K_2 = "0" + string_K_2;}

    QString total = string_K + string_K_2;

    m_ui->textEdit->append("Sending rotation request, ASSERVISSEMENT_ROTATION, rotation = " + QString::number(K, 10) + "      Id : 0x0F5 Hex : 0x" + total + "  ...");


    QByteArray writings = dataFromHexa(total);


    //qDebug() << "Kp Array= " << writings.toDouble(nullptr);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ASSERVISSEMENT_ROTATION; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);

}

void Lidar::rotation_gauche(){

    unsigned short K = - 45*10;
    QString string_K, string_K_2;
        string_K= QString::number((K&0xFF), 16);
         if(string_K.length() < 2){string_K = "0" + string_K;}

        string_K_2 = QString::number(((K>>8)&0xFF), 16);
        if(string_K_2.length() < 2){string_K_2 = "0" + string_K_2;}

    QString total = string_K + string_K_2;

    m_ui->textEdit->append("Sending rotation request, ASSERVISSEMENT_ROTATION, rotation = " + QString::number(K, 10) + "      Id : 0x0F5 Hex : 0x" + total + "  ...");


    QByteArray writings = dataFromHexa(total);

    //qDebug() << "Kp Array= " << writings.toDouble(nullptr);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ASSERVISSEMENT_ROTATION; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);

}


void ecriture_strategie(){
    switch (etat_ecriture_strat)
    {
    case 0:{
    }break;
    case 1:{
        if(button_recallage_clicked = true){
            button_recallage_clicked = false;

        }
        if(button_capture_clicked = true){
            button_capture_clicked = false;
            /*set_color_button_assiette(0,0,0,0,0,0,0,0,0,0);
            set_color_gateau(1,1,1,1);
            etat_ecriture_strat = 3;*/
        }
        if(button_depose_clicked = true){
            button_depose_clicked = false;

        }
    }break;
    case 2:{//recallage
    }break;

    case 3:{//capture
//        if(button_roseHG_clicked || button_jauneHG_clicked || button_brunHG_clicked){
//            remplirStruct_capture_gateau("HG");
//            etat_ecriture_strat = 1;
//            set_color_gateau(1,0,0,0);
//        }
//        if(button_roseBG_clicked || button_jauneBG_clicked || button_brunBG_clicked){
//            remplirStruct_capture_gateau("BG");
//            etat_ecriture_strat = 1;
//            set_color_gateau(0,0,1,0);
//        }
//        if(button_roseHD_clicked || button_jauneHD_clicked || button_brunHD_clicked){
//            remplirStruct_capture_gateau("HD");
//            etat_ecriture_strat = 1;
//            set_color_gateau(0,1,0,0);
//        }
//        if(button_roseBD_clicked || button_jauneBD_clicked || button_brunBD_clicked){
//            remplirStruct_capture_gateau("BD");
//            etat_ecriture_strat = 1;
//            set_color_gateau(0,0,0,1);
//        }



    }break;




    default:
      break;
    }
}

void set_color_button_assiette(bool verte_carree, bool bleu_carree,
                               bool verte_ronde_CB, bool bleu_ronde_CB,
                               bool verte_ronde_CH, bool bleu_ronde_CH,
                               bool verte_ronde_DB, bool bleu_ronde_DB,
                               bool verte_ronde_DH, bool bleu_ronde_DH){
    QString color = "background: red";
    if(verte_carree){assiette_verte_carree->setStyleSheet(color);}
    else{assiette_verte_carree->setStyleSheet("background: transparent");}

        if(verte_ronde_CB){assiette_verte_ronde_CB->setStyleSheet(color);}
        else{assiette_verte_ronde_CB->setStyleSheet("background: transparent");}

        if(verte_ronde_CH){assiette_verte_ronde_CH->setStyleSheet(color);}
        else{assiette_verte_ronde_CH->setStyleSheet("background: transparent");}

        if(verte_ronde_DB){assiette_verte_ronde_DB->setStyleSheet(color);}
        else{assiette_verte_ronde_DB->setStyleSheet("background: transparent");}

        if(verte_ronde_DH){assiette_verte_ronde_DH->setStyleSheet(color);}
        else{assiette_verte_ronde_DH->setStyleSheet("background: transparent");}

        if(bleu_carree){assiette_bleu_carree->setStyleSheet(color);}
        else{assiette_bleu_carree->setStyleSheet("background: transparent");}

        if(bleu_ronde_CB){assiette_bleu_ronde_CB->setStyleSheet(color);}
        else{assiette_bleu_ronde_CB->setStyleSheet("background: transparent");}

        if(bleu_ronde_CH){assiette_bleu_ronde_CH->setStyleSheet(color);}
        else{assiette_bleu_ronde_CH->setStyleSheet("background: transparent");}

        if(bleu_ronde_DB){assiette_bleu_ronde_DB->setStyleSheet(color);}
        else{assiette_bleu_ronde_DB->setStyleSheet("background: transparent");}

        if(bleu_ronde_DH){assiette_bleu_ronde_DH->setStyleSheet(color);}
        else{assiette_bleu_ronde_DH->setStyleSheet("background: transparent");}
}

void set_color_gateau(bool HG, bool HD, bool BG, bool BD){
    QString color = "background: rgb(255, 87, 126)";
    if(HG){
        roseHG->setStyleSheet(color);
        jauneHG->setStyleSheet(color);
        marronHG->setStyleSheet(color);
    }else{
        roseHG->setStyleSheet("background: transparent");
        jauneHG->setStyleSheet("background: transparent");
        marronHG->setStyleSheet("background: transparent");
    }

    if(BG){
        roseBG->setStyleSheet(color);
        jauneBG->setStyleSheet(color);
        marronBG->setStyleSheet(color);
    }else{
        roseBG->setStyleSheet("background: transparent");
        jauneBG->setStyleSheet("background: transparent");
        marronBG->setStyleSheet("background: transparent");
    }

    if(HD){
        roseHD->setStyleSheet(color);
        jauneHD->setStyleSheet(color);
        marronHD->setStyleSheet(color);
    }else{
        roseHD->setStyleSheet("background: transparent");
        jauneHD->setStyleSheet("background: transparent");
        marronHD->setStyleSheet("background: transparent");
    }

    if(BD){
        roseBD->setStyleSheet(color);
        jauneBD->setStyleSheet(color);
        marronBD->setStyleSheet(color);
    }else{
        roseBD->setStyleSheet("background: transparent");
        jauneBD->setStyleSheet("background: transparent");
        marronBD->setStyleSheet("background: transparent");
    }
}

void set_color_port_cerises(bool Gauche, bool Haut, bool Bas,bool Droite){
    QString color = "background: red";
    if(Gauche){port_cerises_G->setStyleSheet(color);}
    else{port_cerises_G->setStyleSheet("background: transparent");}

    if(Haut){port_cerises_H->setStyleSheet(color);}
    else{port_cerises_H->setStyleSheet("background: transparent");}

    if(Bas){port_cerises_B->setStyleSheet(color);}
    else{port_cerises_B->setStyleSheet("background: transparent");}

    if(Droite){port_cerises_D->setStyleSheet(color);}
    else{port_cerises_D->setStyleSheet("background: transparent");}
}

void set_color_cote_table(bool Gauche, bool Haut, bool Bas,bool Droite){
    QString color = "background: rgb(245, 245, 220)";
    if(Gauche){cote_table_G->setStyleSheet(color);}
    else{cote_table_G->setStyleSheet("background: transparent");}

    if(Haut){cote_table_H->setStyleSheet(color);}
    else{cote_table_H->setStyleSheet("background: transparent");}

    if(Bas){cote_table_B->setStyleSheet(color);}
    else{cote_table_B->setStyleSheet("background: transparent");}

    if(Droite){cote_table_D->setStyleSheet(color);}
    else{cote_table_D->setStyleSheet("background: transparent");}
}

void showPartGateau(bool show){
    if(show){
        pile_gateau_RJM->show();
        pile_gateau_MJR->show();
        pile_gateau_RJ->show();
        pile_gateau_JR->show();
        pile_gateau_M->show();
    }else{
        pile_gateau_RJM->hide();
        pile_gateau_MJR->hide();
        pile_gateau_RJ->hide();
        pile_gateau_JR->hide();
        pile_gateau_M->hide();
    }
}

void Lidar::on_button_reset_clicked()
{
    nb_instructions = 0;
    etat_ecriture_strat = 0;
    set_color_button_assiette(1,1,1,1,1,1,1,1,1,1);
    set_color_gateau(0,0,0,0);
    set_color_port_cerises(0,0,0,0);
    set_color_cote_table(0,0,0,0);
    for(int i = 0; i<nb_item; i++){
        scene->removeItem(item[i]);
    }

}

void Lidar::on_button_ctrlZ_clicked()
{
//    for(int i =nb_instructions; i>0 ; i--){
//        if(strat_instructions[i].order == MV_LINE || strat_instructions[i].order == MV_XYT || strat_instructions[i].order == MV_RECALAGE || strat_instructions[i].order == MV_TURN || strat_instructions[i].order == MV_BEZIER || strat_instructions[i].order == MV_COURBURE){
//            nb_instructions = i-1;
//            break;
//        }
//    }
//    nb_instructions --;
//    scene->removeItem(item[nb_item]);
//    nb_item--;
}



void Lidar::on_button_pos_debut_clicked()
{
    nb_instructions = 0;

    strat_instructions[nb_instructions].lineNumber = nb_instructions;
    strat_instructions[nb_instructions].order = POSITION_DEBUT;
    strat_instructions[nb_instructions].direction = ((choixCouleur == "Vert")? GREEN : BLUE);
    strat_instructions[nb_instructions].arg1 = pos_strat_x;//x
    strat_instructions[nb_instructions].arg2 = pos_strat_y;//y
    strat_instructions[nb_instructions].arg3 = pos_strat_theta; //theta
    strat_instructions[nb_instructions].precision = NOPRECISION;
    strat_instructions[nb_instructions].nextActionType = NONEXTACTION;
    strat_instructions[nb_instructions].jumpAction = NONEXTACTIONJUMPTYPE;
    strat_instructions[nb_instructions].JumpTimeOrX =0;
    strat_instructions[nb_instructions].JumpY =0;
    strat_instructions[nb_instructions].nextLineOK = nb_instructions+1;
    strat_instructions[nb_instructions].nextLineError = nb_instructions+1;
    strat_instructions[nb_instructions].arg4 =0;
    strat_instructions[nb_instructions].arg5 =0;
    strat_instructions[nb_instructions].arg6 =0;

    nb_instructions ++;

        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        etat_ecriture_strat = 1;

}




void Lidar::on_button_recallage_clicked()
{
    if(etat_ecriture_strat == 1){
        //button_recallage_clicked = true;
        set_color_cote_table(1,1,1,1);
        etat_ecriture_strat = 5;
    }
}


void Lidar::on_button_capture_clicked()
{
    if(etat_ecriture_strat == 1){
        //button_capture_clicked = true;
        set_color_button_assiette(0,0,0,0,0,0,0,0,0,0);
        set_color_gateau(1,1,1,1);
        set_color_port_cerises(1,1,1,1);
        etat_ecriture_strat = 3;
    }
}


void Lidar::on_button_depose_clicked()
{
    if(etat_ecriture_strat == 1){
       // button_depose_clicked = true;
        if(choixCouleur == "Vert"){
            set_color_button_assiette(1,0,1,0,1,0,1,0,1,0);
        }else{
            set_color_button_assiette(0,1,0,1,0,1,0,1,0,1);
        }
        //set_color_panier(1,1);
        set_color_gateau(0,0,0,0);
        etat_ecriture_strat = 4;
    }
}


void Lidar::on_button_panier_clicked()
{
    if(etat_ecriture_strat == 1)button_panier_clicked = true;
}


void Lidar::on_button_arrive_clicked()
{
    if(etat_ecriture_strat == 1)button_arrive_clicked = true;
}




void Lidar::on_button_creation_txt_clicked()
{
    m_ui->textEdit->append("******************************************");
    m_ui->textEdit->append(" ");
    for(int i = 0; i<nb_instructions; i++){
        QString line = InstructionTostring(strat_instructions[i]);
        m_ui->textEdit->append(line);
    }
    m_ui->textEdit->append(" ");
    m_ui->textEdit->append("******************************************");
}


void Lidar::dessineLigne(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2){
    item[nb_item] = scene->addLine(y1 * 0.2, x1 * 0.2, y2 * 0.2, x2 * 0.2, blackline); nb_item ++ ;
}

void Lidar::on_button_assiette_bleu_carre_clicked(){
    short old_x = pos_strat_x, old_y = pos_strat_y, old_theta = pos_strat_theta;
    qDebug("on_button_assiette_bleu_carre_clicked");
    assiette_bleu_carre_clicked = true;
    if(etat_ecriture_strat == 0){
        choixCouleur = "Bleu";
        pos_strat_x = 2000 - 225; pos_strat_y = 300; pos_strat_theta = 900;
        set_color_button_assiette(0,1,0,0,0,0,0,0,0,0);
    }else if(etat_ecriture_strat == 4 && choixCouleur == "Bleu"){//depot = tri
        remplirStrut_depot_gateau(2000 - 450, 450 , 0, true);
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        etat_ecriture_strat = 1;
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }

}

void Lidar::on_button_assiette_bleu_rondeHC_clicked(){
    short old_x = pos_strat_x, old_y = pos_strat_y, old_theta = pos_strat_theta;
    qDebug("on_button_assiette_bleu_rondeHC_clicked");
    assiette_bleu_rondeHC_clicked = true;
    if(etat_ecriture_strat == 0){
        choixCouleur = "Bleu";
         pos_strat_x = 225; pos_strat_y = 900 + 225; pos_strat_theta = 0;
         set_color_button_assiette(0,0,0,0,0,1,0,0,0,0);
    }else if(etat_ecriture_strat == 4 && choixCouleur == "Bleu"){
        remplirStrut_depot_gateau(450, 900+450 , 1800, 0);
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        etat_ecriture_strat = 1;
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }

}

void Lidar::on_button_assiette_bleu_rondeBC_clicked(){
    short old_x = pos_strat_x, old_y = pos_strat_y, old_theta = pos_strat_theta;
     qDebug("on_button_assiette_bleu_rondeBC_clicked");
    assiette_bleu_rondeBC_clicked = true;
    if(etat_ecriture_strat == 0){
        choixCouleur = "Bleu";
         pos_strat_x = 2000 - 225; pos_strat_y = 3000 - 900 - 225; pos_strat_theta = 1800;
         set_color_button_assiette(0,0,0,1,0,0,0,0,0,0);
    }else if(etat_ecriture_strat == 4 && choixCouleur == "Bleu"){
        remplirStrut_depot_gateau(2000 - 450, 3000 - 900 - 450 , 0, 0);
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        etat_ecriture_strat = 1;
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}

void Lidar::on_button_assiette_bleu_rondeDH_clicked(){
    short old_x = pos_strat_x, old_y = pos_strat_y, old_theta = pos_strat_theta;
     qDebug("on_button_assiette_bleu_rondeDH_clicked");
    assiette_bleu_rondeDH_clicked = true;
    if(etat_ecriture_strat == 0){
        choixCouleur = "Bleu";
         pos_strat_x = 225; pos_strat_y = 3000 - 300; pos_strat_theta = -900;
         set_color_button_assiette(0,0,0,0,0,0,0,0,0,1);
    }else if(etat_ecriture_strat == 4 && choixCouleur == "Bleu"){
        remplirStrut_depot_gateau(450, 3000 - 450 , 1800, 0);
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        etat_ecriture_strat = 1;
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}

void Lidar::on_button_assiette_bleu_rondeDB_clicked(){
    short old_x = pos_strat_x, old_y = pos_strat_y, old_theta = pos_strat_theta;
     qDebug("on_button_assiette_bleu_rondeDB_clicked");
    assiette_bleu_rondeDB_clicked = true;
    if(etat_ecriture_strat == 0){
        choixCouleur = "Bleu";
         pos_strat_x = 1050+225; pos_strat_y = 3000 -300; pos_strat_theta = -900;
         set_color_button_assiette(0,0,0,0,0,0,0,1,0,0);
    }else if(etat_ecriture_strat == 4 && choixCouleur == "Bleu"){
        remplirStrut_depot_gateau(2000 - 500 - 450, 3000 - 450 , 0, 0);
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        etat_ecriture_strat = 1;
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}

void Lidar::on_button_assiette_verte_carre_clicked(){
    short old_x = pos_strat_x, old_y = pos_strat_y, old_theta = pos_strat_theta;
     qDebug("on_button_assiette_verte_carre_clicked");
    assiette_verte_carre_clicked = true;
    if(etat_ecriture_strat == 0){
        choixCouleur = "Vert";
         pos_strat_x = 225; pos_strat_y = 300; pos_strat_theta = 900;
         set_color_button_assiette(1,0,0,0,0,0,0,0,0,0);
    }else if(etat_ecriture_strat == 4 && choixCouleur == "Vert"){
        remplirStrut_depot_gateau(450, 450 , 1800, 0);
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        etat_ecriture_strat = 1;
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}

void Lidar::on_button_assiette_verte_rondeHC_clicked(){
    short old_x = pos_strat_x, old_y = pos_strat_y, old_theta = pos_strat_theta;
     qDebug("on_button_assiette_verte_rondeHC_clicked");
    assiette_verte_rondeHC_clicked = true;
    if(etat_ecriture_strat == 0){
        choixCouleur = "Vert";
         pos_strat_x = 225; pos_strat_y = 3000 - 900 - 225; pos_strat_theta = 0;
         set_color_button_assiette(0,0,0,0,1,0,0,0,0,0);
    }else if(etat_ecriture_strat == 4 && choixCouleur == "Vert"){
        remplirStrut_depot_gateau(450, 3000 - 900 - 450 , 1800, true);
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        etat_ecriture_strat = 1;
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}

void Lidar::on_button_assiette_verte_rondeBC_clicked(){
    short old_x = pos_strat_x, old_y = pos_strat_y, old_theta = pos_strat_theta;
     qDebug("on_button_assiette_verte_rondeBC_clicked");
    assiette_verte_rondeBC_clicked = true;
    if(etat_ecriture_strat == 0){
        choixCouleur = "Vert";
         pos_strat_x = 2000 - 225; pos_strat_y = 900 + 225; pos_strat_theta = 1800;
         set_color_button_assiette(0,0,1,0,0,0,0,0,0,0);
    }else if(etat_ecriture_strat == 4 && choixCouleur == "Vert"){
        remplirStrut_depot_gateau(2000 - 450, 900, 0, 0);
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        etat_ecriture_strat = 1;
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}

void Lidar::on_button_assiette_verte_rondeDH_clicked(){
    short old_x = pos_strat_x, old_y = pos_strat_y, old_theta = pos_strat_theta;
     qDebug("on_button_assiette_verte_rondeDH_clicked");
    assiette_verte_rondeDH_clicked = true;
    if(etat_ecriture_strat == 0){
        choixCouleur = "Vert";
         pos_strat_x = 500+225; pos_strat_y = 3000-300; pos_strat_theta = -900;
         set_color_button_assiette(0,0,0,0,0,0,0,0,1,0);
    }else if(etat_ecriture_strat == 4 && choixCouleur == "Vert"){
        remplirStrut_depot_gateau(500, 3000 - 450 , 0, 0);
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        etat_ecriture_strat = 1;
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}

void Lidar::on_button_assiette_verte_rondeDB_clicked(){
    short old_x = pos_strat_x, old_y = pos_strat_y, old_theta = pos_strat_theta;
     qDebug("on_button_assiette_verte_rondeDB_clicked");
    assiette_verte_rondeDB_clicked = true;
    if(etat_ecriture_strat == 0){
        choixCouleur = "Vert";
         pos_strat_x = 2000 - 225; pos_strat_y = 3000 -300; pos_strat_theta = -900;
         set_color_button_assiette(0,0,0,0,0,0,1,0,0,0);
    }else if(etat_ecriture_strat == 4 && choixCouleur == "Vert"){
        remplirStrut_depot_gateau(2000 - 450, 3000 - 450 , 0, 0);
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        etat_ecriture_strat = 1;
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}




void Lidar::on_button_roseHG_clicked(){
    if(etat_ecriture_strat == 3){
        set_color_gateau(1,0,0,0);
        set_color_port_cerises(0,0,0,0);
        etat_ecriture_strat = 31;
        showPartGateau(true);
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }

}
void Lidar::on_button_roseBG_clicked(){
    if(etat_ecriture_strat == 3){
        set_color_gateau(0,0,1,0);
        set_color_port_cerises(0,0,0,0);
        etat_ecriture_strat = 32;
        showPartGateau(true);
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}
void Lidar::on_button_roseHD_clicked(){
    if(etat_ecriture_strat == 3){
        set_color_gateau(0,1,0,0);
        set_color_port_cerises(0,0,0,0);
        etat_ecriture_strat = 33;
        showPartGateau(true);
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}
void Lidar::on_button_roseBD_clicked(){
    if(etat_ecriture_strat == 3){
        set_color_gateau(0,1,0,0);
        set_color_port_cerises(0,0,0,0);
        etat_ecriture_strat = 34;
        showPartGateau(true);
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}



void Lidar::on_button_jauneHG_clicked(){
    if(etat_ecriture_strat == 3){
        set_color_gateau(1,0,0,0);
        set_color_port_cerises(0,0,0,0);
        etat_ecriture_strat = 31;
        showPartGateau(true);
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}
void Lidar::on_button_jauneBG_clicked(){
    if(etat_ecriture_strat == 3){
        //remplirStruct_capture_gateau("BG");
        set_color_gateau(0,0,1,0);
        set_color_port_cerises(0,0,0,0);
        etat_ecriture_strat = 32;
        showPartGateau(true);
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}
void Lidar::on_button_jauneHD_clicked(){
    if(etat_ecriture_strat == 3){
        set_color_gateau(0,1,0,0);
        set_color_port_cerises(0,0,0,0);
        etat_ecriture_strat = 33;
        showPartGateau(true);
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}
void Lidar::on_button_jauneBD_clicked(){
    if(etat_ecriture_strat == 3){
        set_color_gateau(0,1,0,0);
        set_color_port_cerises(0,0,0,0);
        etat_ecriture_strat = 34;
        showPartGateau(true);
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}





void Lidar::on_button_brunHG_clicked(){

   // button_brunHG_clicked = true;
    if(etat_ecriture_strat == 3){
        //button_roseHG_clicked = true;
        //remplirStruct_capture_gateau("HG");
        set_color_gateau(1,0,0,0);
        set_color_port_cerises(0,0,0,0);
        etat_ecriture_strat = 31;
        showPartGateau(true);
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}
void Lidar::on_button_brunBG_clicked(){
    if(etat_ecriture_strat == 3){
        //remplirStruct_capture_gateau("BG");
        set_color_gateau(0,0,1,0);
        set_color_port_cerises(0,0,0,0);
        etat_ecriture_strat = 32;
        showPartGateau(true);
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}
void Lidar::on_button_brunHD_clicked(){
    if(etat_ecriture_strat == 3){
        set_color_gateau(0,1,0,0);
        set_color_port_cerises(0,0,0,0);
        etat_ecriture_strat = 33;
        showPartGateau(true);
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}
void Lidar::on_button_brunBD_clicked(){
    if(etat_ecriture_strat == 3){
        set_color_gateau(0,1,0,0);
        set_color_port_cerises(0,0,0,0);
        etat_ecriture_strat = 34;
        showPartGateau(true);
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}


//choix pile gateau :
void  Lidar::on_button_pile_gateau_RJM_clicked(){
    switch (etat_ecriture_strat) {
    case 31://HG
    {
        remplirStruct_capture_gateau("HG");

    }break;
    case 32://BG
    {
        remplirStruct_capture_gateau("BG");
    }break;
    case 33://HD
    {
        remplirStruct_capture_gateau("HD");
    }break;
    case 34://BD
    {
        remplirStruct_capture_gateau("BD");

    }break;
    default:
        break;
    }
    positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
    showPartGateau(false);
    etat_ecriture_strat = 1;
}
void  Lidar::on_button_pile_gateau_MJR_clicked(){

    switch (etat_ecriture_strat) {
    case 31://HG
    {
        remplirStruct_capture_gateau("HG-MJR");

    }break;
    case 32://BG
    {
        remplirStruct_capture_gateau("BG-MJR");
    }break;
    case 33://HD
    {
        remplirStruct_capture_gateau("HD-MJR");
    }break;
    case 34://BD
    {
        remplirStruct_capture_gateau("BD-MJR");

    }break;
    default:
        break;
    }
    positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
    showPartGateau(false);
    etat_ecriture_strat = 1;
}
void  Lidar::on_button_pile_gateau_RJ_clicked(){

    switch (etat_ecriture_strat) {
    case 31://HG
    {
        remplirStruct_capture_gateau("HG-RJ");

    }break;
    case 32://BG
    {
        remplirStruct_capture_gateau("BG-RJ");
    }break;
    case 33://HD
    {
        remplirStruct_capture_gateau("HD-RJ");
    }break;
    case 34://BD
    {
        remplirStruct_capture_gateau("BD-RJ");

    }break;
    default:
        break;
    }
    positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
    showPartGateau(false);
    etat_ecriture_strat = 1;
}
void  Lidar::on_button_pile_gateau_JR_clicked(){
    switch (etat_ecriture_strat) {
    case 31://HG
    {
        remplirStruct_capture_gateau("HG-JR");

    }break;
    case 32://BG
    {
        remplirStruct_capture_gateau("BG-JR");
    }break;
    case 33://HD
    {
        remplirStruct_capture_gateau("HD-JR");
    }break;
    case 34://BD
    {
        remplirStruct_capture_gateau("BD-JR");

    }break;
    default:
        break;
    }
    positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
    showPartGateau(false);
    etat_ecriture_strat = 1;
}

void Lidar::on_button_pile_gateau_M_clicked(){
    switch (etat_ecriture_strat) {
    case 31://HG
    {
        remplirStruct_capture_gateau("HG-M");

    }break;
    case 32://BG
    {
        remplirStruct_capture_gateau("BG-M");
    }break;
    case 33://HD
    {
        remplirStruct_capture_gateau("HD-M");
    }break;
    case 34://BD
    {
        remplirStruct_capture_gateau("BD-M");

    }break;
    default:
        break;
    }
    positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
    showPartGateau(false);
    etat_ecriture_strat = 1;
}



//port cerises :
void Lidar::on_button_port_cerises_G_clicked(){
    short old_x = pos_strat_x, old_y = pos_strat_y, old_theta = pos_strat_theta;
    if(etat_ecriture_strat == 3){
        remplirStruct_capture_cerise("G");
        etat_ecriture_strat = 1;
        set_color_gateau(0,0,0,0);
        set_color_port_cerises(1,0,0,0);
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}
void Lidar::on_button_port_cerises_H_clicked(){
    short old_x = pos_strat_x, old_y = pos_strat_y, old_theta = pos_strat_theta;
    if(etat_ecriture_strat == 3){
        remplirStruct_capture_cerise("H");
        etat_ecriture_strat = 1;
        set_color_gateau(0,0,0,0);
        set_color_port_cerises(0,1,0,0);
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}
void Lidar::on_button_port_cerises_B_clicked(){
    short old_x = pos_strat_x, old_y = pos_strat_y, old_theta = pos_strat_theta;
    if(etat_ecriture_strat == 3){
        remplirStruct_capture_cerise("B");
        etat_ecriture_strat = 1;
        set_color_gateau(0,0,0,0);
        set_color_port_cerises(0,0,1,0);
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}
void Lidar::on_button_port_cerises_D_clicked(){
    short old_x = pos_strat_x, old_y = pos_strat_y, old_theta = pos_strat_theta;
    if(etat_ecriture_strat == 3){
        remplirStruct_capture_cerise("D");
        etat_ecriture_strat = 1;
        set_color_gateau(0,0,0,0);
        set_color_port_cerises(0,0,0,1);
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}



//coté table :
void Lidar::on_button_cote_table_G_clicked(){
    short old_x = pos_strat_x, old_y = pos_strat_y, old_theta = pos_strat_theta;
    if(etat_ecriture_strat == 5){
        etat_ecriture_strat = 1;

        short val_recalage = MOITIEE_ROBOT;
        E_InstructionDirection direction = FORWARD;
        if(pos_strat_theta>0 && pos_strat_theta < 1800){direction = BACKWARD;}
        strat_instructions[nb_instructions] = Recalage(val_recalage, direction, RECALAGE_Y); nb_instructions ++;
        set_color_gateau(0,0,0,0);
        set_color_port_cerises(0,0,0,0);
        set_color_cote_table(1,0,0,0);

        pos_strat_y = val_recalage; if(direction == BACKWARD){pos_strat_theta = 900;}else{pos_strat_theta = -900;}
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}

void Lidar::on_button_cote_table_H_clicked(){
    short old_x = pos_strat_x, old_y = pos_strat_y, old_theta = pos_strat_theta;
    if(etat_ecriture_strat == 5){
        etat_ecriture_strat = 1;

        short val_recalage = MOITIEE_ROBOT;
        E_InstructionDirection direction = FORWARD;
        if(pos_strat_theta>-900 && pos_strat_theta < 900){direction = BACKWARD;}
        strat_instructions[nb_instructions] = Recalage(val_recalage, direction, RECALAGE_X); nb_instructions ++;
        set_color_gateau(0,0,0,0);
        set_color_port_cerises(0,0,0,0);
        set_color_cote_table(0,1,0,0);

        pos_strat_x = val_recalage; if(direction == BACKWARD){pos_strat_theta = 0;}else{pos_strat_theta = 1800;}
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}

void Lidar::on_button_cote_table_B_clicked(){
    short old_x = pos_strat_x, old_y = pos_strat_y, old_theta = pos_strat_theta;
    if(etat_ecriture_strat == 5){
        etat_ecriture_strat = 1;

        short val_recalage = 2000 - MOITIEE_ROBOT;
        E_InstructionDirection direction = BACKWARD;
        if(pos_strat_theta>-900 && pos_strat_theta < 900){direction = FORWARD ;}
        strat_instructions[nb_instructions] = Recalage(val_recalage, direction, RECALAGE_X); nb_instructions ++;
        set_color_gateau(0,0,0,0);
        set_color_port_cerises(0,0,0,0);
        set_color_cote_table(0,0,1,0);

        pos_strat_x = val_recalage; if(direction == FORWARD){pos_strat_theta = 0;}else{pos_strat_theta = 1800;}
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}

void Lidar::on_button_cote_table_D_clicked(){
    short old_x = pos_strat_x, old_y = pos_strat_y, old_theta = pos_strat_theta;
    if(etat_ecriture_strat == 5){
        etat_ecriture_strat = 1;

        short val_recalage = 3000 - MOITIEE_ROBOT;
        E_InstructionDirection direction = BACKWARD ;
        if(pos_strat_theta>0 && pos_strat_theta < 1800){direction = FORWARD ;}
        strat_instructions[nb_instructions] = Recalage(val_recalage, direction, RECALAGE_Y); nb_instructions ++;
        set_color_gateau(0,0,0,0);
        set_color_port_cerises(0,0,0,0);
        set_color_cote_table(0,0,0,1);

        pos_strat_y = val_recalage; if(direction == FORWARD){pos_strat_theta = 900;}else{pos_strat_theta = -900;}
        positionRobot(pos_strat_y*0.2, pos_strat_x*0.2, pos_strat_theta);
        //dessineLigne(old_x, old_y, pos_strat_x, pos_strat_y);
    }
}





struct S_Instruction Lidar::pince(uint8_t etage, uint8_t etatHerkulex, uint8_t sens){
    struct S_Instruction instruction;
    instruction.lineNumber = nb_instructions;
    instruction.order = PINCE;
    instruction.direction = NODIRECTION;
    instruction.arg1 = etage;
    instruction.arg2 = etatHerkulex;
    instruction.arg3 = sens;
    instruction.precision = NOPRECISION;
    instruction.nextActionType = WAIT;
    instruction.jumpAction = NONEXTACTIONJUMPTYPE;
    instruction.JumpTimeOrX =0;
    instruction.JumpY =0;
    instruction.nextLineOK = nb_instructions+1;
    instruction.nextLineError = nb_instructions+1;
    instruction.arg4 =0;
    instruction.arg5 =0;
    instruction.arg6 =0;
    return instruction;
}

struct S_Instruction Lidar::XYT(short x, short y, short theta, enum E_InstructionDirection direction){
    dessineLigne(pos_strat_x, pos_strat_y, x, y);
    pos_strat_x = x; pos_strat_y = y; pos_strat_theta = theta;
    struct S_Instruction instruction;
    instruction.lineNumber = nb_instructions;
    instruction.order = MV_XYT;
    instruction.direction = direction;
    instruction.arg1 = x;
    instruction.arg2 = y;
    instruction.arg3 = theta;
    instruction.precision = NOPRECISION;
    instruction.nextActionType = WAIT;
    instruction.jumpAction = JUMP_TIME;
    instruction.JumpTimeOrX =0;
    instruction.JumpY =0;
    instruction.nextLineOK = nb_instructions+1;
    instruction.nextLineError = nb_instructions+1;
    instruction.arg4 =0;
    instruction.arg5 =0;
    instruction.arg6 =0;
    return instruction;
}

struct S_Instruction Lidar::toutDroit(int distance){
    //cos(z)=x/distance sin(z)=y/distance
    short x2 = pos_strat_x + (cos((pos_strat_theta/10.0)*M_PI/180.0) * distance),
          y2 = pos_strat_y + (sin((pos_strat_theta/10.0)*M_PI/180.0) * distance);
    dessineLigne(pos_strat_x, pos_strat_y, x2, y2);
    pos_strat_x = x2; pos_strat_y = y2; pos_strat_theta = pos_strat_theta;
    struct S_Instruction instruction;
    instruction.lineNumber = nb_instructions;
    instruction.order = MV_LINE;
    instruction.direction = FORWARD;
    instruction.arg1 = distance;
    instruction.arg2 = 0;
    instruction.arg3 = 0;
    instruction.precision = NOPRECISION;
    instruction.nextActionType = WAIT;
    instruction.jumpAction = JUMP_TIME;
    instruction.JumpTimeOrX =0;
    instruction.JumpY =0;
    instruction.nextLineOK = nb_instructions+1;
    instruction.nextLineError = nb_instructions+1;
    instruction.arg4 =0;
    instruction.arg5 =0;
    instruction.arg6 =0;
    return instruction;
}

struct S_Instruction Lidar::poseCerise(){
    struct S_Instruction instruction;
    instruction.lineNumber = nb_instructions;
    instruction.order = ACTION;
    instruction.direction = NODIRECTION;
    instruction.arg1 = 30;
    instruction.arg2 = 0;
    instruction.arg3 = 0;
    instruction.precision = NOPRECISION;
    instruction.nextActionType = WAIT;
    instruction.jumpAction = JUMP_TIME;
    instruction.JumpTimeOrX =0;
    instruction.JumpY =0;
    instruction.nextLineOK = nb_instructions+1;
    instruction.nextLineError = nb_instructions+1;
    instruction.arg4 =0;
    instruction.arg5 =0;
    instruction.arg6 =0;
    return instruction;
}

struct S_Instruction Lidar::pinceArriere(uint8_t position, bool cerise){
    struct S_Instruction instruction;
    instruction.lineNumber = nb_instructions;
    instruction.order = ACTION;
    instruction.direction = NODIRECTION;
    instruction.arg1 = 10;
    instruction.arg2 = position;
    instruction.arg3 = cerise;
    instruction.precision = NOPRECISION;
    instruction.nextActionType = WAIT;
    instruction.jumpAction = JUMP_TIME;
    instruction.JumpTimeOrX =0;
    instruction.JumpY =0;
    instruction.nextLineOK = nb_instructions+1;
    instruction.nextLineError = nb_instructions+1;
    instruction.arg4 =0;
    instruction.arg5 =0;
    instruction.arg6 =0;
    return instruction;
}

struct S_Instruction Lidar::Recalage(int val_recalage, enum E_InstructionDirection direction, enum E_InstructionPrecisionOuRecalage    axe){
    int x2 = 0, y2 = 0;
    if(axe == RECALAGE_Y) {x2 = pos_strat_x ; y2 = val_recalage;}
    else if(axe == RECALAGE_X) {y2 = pos_strat_y ; x2 = val_recalage;}
    dessineLigne(pos_strat_x, pos_strat_y, x2, y2);
    pos_strat_x = x2; pos_strat_y = y2; pos_strat_theta = pos_strat_theta;
    struct S_Instruction instruction;
    instruction.lineNumber = nb_instructions;
    instruction.order = MV_RECALAGE;
    instruction.direction = direction;
    instruction.arg1 = val_recalage;
    instruction.arg2 = 0;
    instruction.arg3 = 0;
    instruction.precision = axe;
    instruction.nextActionType = MECANIQUE;
    instruction.jumpAction = NONEXTACTIONJUMPTYPE;
    instruction.JumpTimeOrX =0;
    instruction.JumpY =0;
    instruction.nextLineOK = nb_instructions+1;
    instruction.nextLineError = nb_instructions+1;
    instruction.arg4 =0;
    instruction.arg5 =0;
    instruction.arg6 =0;
    return instruction;
}

struct S_Instruction Lidar::Aspirateur(bool activation){
    struct S_Instruction instruction;
    instruction.lineNumber = nb_instructions;
    instruction.order = ACTION;
    instruction.direction = NODIRECTION;
    instruction.arg1 = 20;
    instruction.arg2 = activation;
    instruction.arg3 = 0;
    instruction.precision = NOPRECISION;
    instruction.nextActionType = WAIT;
    instruction.jumpAction = JUMP_TIME;
    instruction.JumpTimeOrX =0;
    instruction.JumpY =0;
    instruction.nextLineOK = nb_instructions+1;
    instruction.nextLineError = nb_instructions+1;
    instruction.arg4 =0;
    instruction.arg5 =0;
    instruction.arg6 =0;
    return instruction;
}


void Lidar::remplirStruct_capture_gateau(QString gateau){
    if(gateau == "HG"){
        strat_instructions[nb_instructions] = pince(0,0,0); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(225,300,900, FORWARD); nb_instructions ++;
        //pos_strat_x = 225; pos_strat_y = 300; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = XYT(225,500,900, FORWARD); nb_instructions ++;
//        pos_strat_x = 225; pos_strat_y = 500; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(225,700,900, FORWARD); nb_instructions ++;
//        pos_strat_x = 225; pos_strat_y = 700; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = pince(0,0,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(720,890,900, FORWARD); nb_instructions ++;
//        pos_strat_x = 720; pos_strat_y = 890; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = XYT(720,1050,900, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(0,0,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(1,1,-1); nb_instructions ++;
//        pos_strat_x = 720; pos_strat_y = 1050; pos_strat_theta = 900;
    }
    else if(gateau == "BG"){
        strat_instructions[nb_instructions] = pince(0,0,0); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 225,300,900, FORWARD); nb_instructions ++;
//        pos_strat_x = 2000 - 225; pos_strat_y = 300; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = XYT(2000 - 225,500,900, FORWARD); nb_instructions ++;
//        pos_strat_x = 2000 - 225; pos_strat_y = 500; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 225,700,900, FORWARD); nb_instructions ++;
//        pos_strat_x = 2000 - 225; pos_strat_y = 700; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = pince(0,0,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 720,890,900, FORWARD); nb_instructions ++;
//        pos_strat_x = 2000 - 720; pos_strat_y = 890; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = XYT(2000 - 720,1050,900, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(0,0,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(1,1,-1); nb_instructions ++;
//        pos_strat_x = 2000 - 720; pos_strat_y = 1050; pos_strat_theta = 900;
    }
    else if(gateau == "HD"){
        strat_instructions[nb_instructions] = pince(0,0,0); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(225,3000 - 300, -900, FORWARD); nb_instructions ++;
//        pos_strat_x = 225; pos_strat_y = 3000 - 300; pos_strat_theta = -900;
        strat_instructions[nb_instructions] = XYT(225,3000 - 500,-900, FORWARD); nb_instructions ++;
//        pos_strat_x = 225; pos_strat_y = 3000 - 500; pos_strat_theta = -900;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(225,3000 - 700,-900, FORWARD); nb_instructions ++;
//        pos_strat_x = 225; pos_strat_y = 3000 - 700; pos_strat_theta = -900;
        strat_instructions[nb_instructions] = pince(0,0,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(720,3000 - 890,-900, FORWARD); nb_instructions ++;
//        pos_strat_x = 720; pos_strat_y = 3000 - 890; pos_strat_theta = -900;
        strat_instructions[nb_instructions] = XYT(720,3000 - 1050,-900, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(0,0,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(1,1,-1); nb_instructions ++;
//        pos_strat_x = 720; pos_strat_y = 3000 - 1050; pos_strat_theta = -900;
    }
    else if(gateau == "BD"){
        strat_instructions[nb_instructions] = pince(0,0,0); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 225,3000 - 300,-900, FORWARD); nb_instructions ++;
//        pos_strat_x = 3000 - 300; pos_strat_y = 3000 - 300; pos_strat_theta = -900;
        strat_instructions[nb_instructions] = XYT(2000 - 225,3000 - 500,-900, FORWARD); nb_instructions ++;
//        pos_strat_x = 2000 - 225; pos_strat_y = 3000 - 500; pos_strat_theta = -900;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 225,3000 - 700,-900, FORWARD); nb_instructions ++;
//        pos_strat_x = 2000 - 225; pos_strat_y = 3000 - 700; pos_strat_theta = -900;
        strat_instructions[nb_instructions] = pince(0,0,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 720,3000 - 890,-900, FORWARD); nb_instructions ++;
//        pos_strat_x = 2000 - 720; pos_strat_y = 3000 - 890; pos_strat_theta = -900;
        strat_instructions[nb_instructions] = XYT(2000 - 720,3000 - 1050,-900, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(0,0,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(1,1,-1); nb_instructions ++;
//        pos_strat_x = 2000 - 720; pos_strat_y = 3000 - 1050; pos_strat_theta = -900;
    }


    //MJR : ----------------------------------------



    else if(gateau == "HG-MJR"){
        strat_instructions[nb_instructions] = pince(0,0,0); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(720,1300,-900, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(720,1125,-900, FORWARD); nb_instructions ++;
        //pos_strat_x = 225; pos_strat_y = 300; pos_strat_theta = 900;
//        pos_strat_x = 225; pos_strat_y = 500; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(225,950,-900, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(225,700,-900, FORWARD); nb_instructions ++;
//        pos_strat_x = 225; pos_strat_y = 700; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = pince(0,0,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(225,600,-900, FORWARD); nb_instructions ++;
//        pos_strat_x = 720; pos_strat_y = 890; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = pince(0,0,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(1,1,-1); nb_instructions ++;
//        pos_strat_x = 720; pos_strat_y = 1050; pos_strat_theta = 900;
    }
    else if(gateau == "BG-MJR"){
        strat_instructions[nb_instructions] = pince(0,0,0); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 720,1300,-900, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 720,1125,-900, FORWARD); nb_instructions ++;
        //pos_strat_x = 225; pos_strat_y = 300; pos_strat_theta = 900;
//        pos_strat_x = 225; pos_strat_y = 500; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 225,950,-900, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 225,700,-900, FORWARD); nb_instructions ++;
//        pos_strat_x = 225; pos_strat_y = 700; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = pince(0,0,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 225,600,-900, FORWARD); nb_instructions ++;
//        pos_strat_x = 720; pos_strat_y = 890; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = pince(0,0,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(1,1,-1); nb_instructions ++;
//        pos_strat_x = 720; pos_strat_y = 1050; pos_strat_theta = 900;
    }
    else if(gateau == "HD-MJR"){
        strat_instructions[nb_instructions] = pince(0,0,0); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(720,3000 - 1300,900, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(720,3000 - 1125,900, FORWARD); nb_instructions ++;
        //pos_strat_x = 225; pos_strat_y = 300; pos_strat_theta = 900;
//        pos_strat_x = 225; pos_strat_y = 500; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(225,3000 - 950,900, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(225,3000 - 700,900, FORWARD); nb_instructions ++;
//        pos_strat_x = 225; pos_strat_y = 700; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = pince(0,0,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(225,3000 - 600,900, FORWARD); nb_instructions ++;
//        pos_strat_x = 720; pos_strat_y = 890; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = pince(0,0,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(1,1,-1); nb_instructions ++;
//        pos_strat_x = 720; pos_strat_y = 1050; pos_strat_theta = 900;
    }
    else if(gateau == "BD-MJR"){
        strat_instructions[nb_instructions] = pince(0,0,0); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 720,3000 - 1300,900, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 720,3000 - 1125,900, FORWARD); nb_instructions ++;
        //pos_strat_x = 225; pos_strat_y = 300; pos_strat_theta = 900;
//        pos_strat_x = 225; pos_strat_y = 500; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 225,3000 - 950,900, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 225,3000 - 700,900, FORWARD); nb_instructions ++;
//        pos_strat_x = 225; pos_strat_y = 700; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = pince(0,0,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 225,3000 - 600,900, FORWARD); nb_instructions ++;
//        pos_strat_x = 720; pos_strat_y = 890; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = pince(0,0,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(1,1,-1); nb_instructions ++;
//        pos_strat_x = 720; pos_strat_y = 1050; pos_strat_theta = 900;
    }

    //RJ : ---------------------------------------------- A terminer
    else if(gateau == "HG-RJ"){
        strat_instructions[nb_instructions] = pince(0,0,0); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(225,300,900, FORWARD); nb_instructions ++;
        //pos_strat_x = 225; pos_strat_y = 300; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = XYT(225,500,900, FORWARD); nb_instructions ++;
//        pos_strat_x = 225; pos_strat_y = 500; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(225,700,900, FORWARD); nb_instructions ++;
//        pos_strat_x = 225; pos_strat_y = 700; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = pince(0,0,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
    }
    else if(gateau == "BG-RJ"){
        strat_instructions[nb_instructions] = pince(0,0,0); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 225,300,900, FORWARD); nb_instructions ++;
//        pos_strat_x = 2000 - 225; pos_strat_y = 300; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = XYT(2000 - 225,500,900, FORWARD); nb_instructions ++;
//        pos_strat_x = 2000 - 225; pos_strat_y = 500; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 225,700,900, FORWARD); nb_instructions ++;
//        pos_strat_x = 2000 - 225; pos_strat_y = 700; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = pince(0,0,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;

    }
    else if(gateau == "HD-RJ"){
        strat_instructions[nb_instructions] = pince(0,0,0); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(225,3000 - 300, -900, FORWARD); nb_instructions ++;
//        pos_strat_x = 225; pos_strat_y = 3000 - 300; pos_strat_theta = -900;
        strat_instructions[nb_instructions] = XYT(225,3000 - 500,-900, FORWARD); nb_instructions ++;
//        pos_strat_x = 225; pos_strat_y = 3000 - 500; pos_strat_theta = -900;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(225,3000 - 700,-900, FORWARD); nb_instructions ++;
//        pos_strat_x = 225; pos_strat_y = 3000 - 700; pos_strat_theta = -900;
        strat_instructions[nb_instructions] = pince(0,0,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;

    }
    else if(gateau == "BD-RJ"){
        strat_instructions[nb_instructions] = pince(0,0,0); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 225,3000 - 300,-900, FORWARD); nb_instructions ++;
//        pos_strat_x = 3000 - 300; pos_strat_y = 3000 - 300; pos_strat_theta = -900;
        strat_instructions[nb_instructions] = XYT(2000 - 225,3000 - 500,-900, FORWARD); nb_instructions ++;
//        pos_strat_x = 2000 - 225; pos_strat_y = 3000 - 500; pos_strat_theta = -900;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 225,3000 - 700,-900, FORWARD); nb_instructions ++;
//        pos_strat_x = 2000 - 225; pos_strat_y = 3000 - 700; pos_strat_theta = -900;
        strat_instructions[nb_instructions] = pince(0,0,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;

    }


    //JR : ------------------------------------------------ A terminer

    else if(gateau == "HG-JR"){
        strat_instructions[nb_instructions] = pince(0,0,0); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(225,950,-900, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(225,700,-900, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(225,600,-900, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(0,0,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
//        pos_strat_x = 720; pos_strat_y = 1050; pos_strat_theta = 900;
    }
    else if(gateau == "BG-JR"){
        strat_instructions[nb_instructions] = pince(0,0,0); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 225,950,-900, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 225,700,-900, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 225,600,-900, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(0,0,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
    }
    else if(gateau == "HD-JR"){
        strat_instructions[nb_instructions] = pince(0,0,0); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(225,3000 - 950,900, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(225,3000 - 700,900, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(225,3000 - 600,900, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(0,0,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
//        pos_strat_x = 720; pos_strat_y = 1050; pos_strat_theta = 900;
    }
    else if(gateau == "BD-JR"){
        strat_instructions[nb_instructions] = pince(0,0,0); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 225,3000 - 950,900, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 225,3000 - 700,900, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 225,3000 - 600,900, FORWARD); nb_instructions ++;
//        pos_strat_x = 720; pos_strat_y = 890; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = pince(0,0,-1); nb_instructions ++;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
//        pos_strat_x = 720; pos_strat_y = 1050; pos_strat_theta = 900;
    }



    //M : ------------------------------------------------------------------------------------



    else if(gateau == "HG-M"){
        strat_instructions[nb_instructions] = pince(0,0,0); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(570,1125,0, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(720,1125,0, FORWARD); nb_instructions ++;
        //pos_strat_x = 225; pos_strat_y = 300; pos_strat_theta = 900;
//        pos_strat_x = 225; pos_strat_y = 500; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
    }
    else if(gateau == "BG-M"){
        strat_instructions[nb_instructions] = pince(0,0,0); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 570,1125,1800, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 720,1125,1800, FORWARD); nb_instructions ++;
        //pos_strat_x = 225; pos_strat_y = 300; pos_strat_theta = 900;
//        pos_strat_x = 225; pos_strat_y = 500; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
    }
    else if(gateau == "HD-M"){
        strat_instructions[nb_instructions] = pince(0,0,0); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(570,3000 - 1125,0, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(720,3000 - 1125,0, FORWARD); nb_instructions ++;
        //pos_strat_x = 225; pos_strat_y = 300; pos_strat_theta = 900;
//        pos_strat_x = 225; pos_strat_y = 500; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
    }
    else if(gateau == "BD-M"){
        strat_instructions[nb_instructions] = pince(0,0,0); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 570,3000 - 1125,1800, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(2000 - 720,3000 - 1125,1800, FORWARD); nb_instructions ++;
        //pos_strat_x = 225; pos_strat_y = 300; pos_strat_theta = 900;
//        pos_strat_x = 225; pos_strat_y = 500; pos_strat_theta = 900;
        strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
    }
}



void Lidar::remplirStrut_depot_gateau(short posbasx, short posbasy, short posbastheta, bool inverse){
    short inver = 1;
    int distanceUne = 140, distanceDeux = 160;
    if(inverse){inver = -1;}

    strat_instructions[nb_instructions] = XYT(posbasx + (distanceUne * cos(posbastheta * M_PI/1800)), posbasy + (distanceUne * sin(posbastheta * M_PI/1800)), posbastheta, FORWARD); nb_instructions ++;
    pos_strat_x = posbasx; pos_strat_y = posbasy; pos_strat_theta = posbastheta;

//    strat_instructions[nb_instructions] = toutDroit(distanceUne); nb_instructions ++;
    strat_instructions[nb_instructions] = pince(1,0,0); nb_instructions ++;
    strat_instructions[nb_instructions] = pince(2,1,-1); nb_instructions ++;
    strat_instructions[nb_instructions] = XYT(posbasx, posbasy, posbastheta+(450 * inver), BACKWARD); nb_instructions ++;

    strat_instructions[nb_instructions] = toutDroit(distanceDeux); nb_instructions ++;
    strat_instructions[nb_instructions] = pince(1,0,0); nb_instructions ++;//centre
    strat_instructions[nb_instructions] = pince(2,1,-1); nb_instructions ++;
    strat_instructions[nb_instructions] = XYT(posbasx, posbasy, posbastheta+(900 * inver), BACKWARD); nb_instructions ++;

    strat_instructions[nb_instructions] = toutDroit(distanceUne); nb_instructions ++;
    strat_instructions[nb_instructions] = pince(2,0,0); nb_instructions ++;
    strat_instructions[nb_instructions] = pince(3,1,-1); nb_instructions ++;
    strat_instructions[nb_instructions] = XYT(posbasx, posbasy, posbastheta+(450 * inver), BACKWARD); nb_instructions ++;

    strat_instructions[nb_instructions] = toutDroit(distanceDeux); nb_instructions ++;
    strat_instructions[nb_instructions] = pince(2,0,0); nb_instructions ++;
    strat_instructions[nb_instructions] = pince(3,1,-1); nb_instructions ++;
    strat_instructions[nb_instructions] = XYT(posbasx, posbasy, posbastheta, BACKWARD); nb_instructions ++;

    strat_instructions[nb_instructions] = toutDroit(distanceUne); nb_instructions ++;
    strat_instructions[nb_instructions] = pince(3,0,0); nb_instructions ++;
    strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
    strat_instructions[nb_instructions] = XYT(posbasx, posbasy, posbastheta+(450 * inver), BACKWARD); nb_instructions ++;

    strat_instructions[nb_instructions] = toutDroit(distanceDeux); nb_instructions ++;
    strat_instructions[nb_instructions] = pince(3,0,0); nb_instructions ++;
    strat_instructions[nb_instructions] = pince(4,1,-1); nb_instructions ++;
    strat_instructions[nb_instructions] = XYT(posbasx, posbasy, posbastheta+(900 * inver), BACKWARD); nb_instructions ++;

    strat_instructions[nb_instructions] = toutDroit(distanceUne); nb_instructions ++;
    strat_instructions[nb_instructions] = pince(3,0,0); nb_instructions ++;

    strat_instructions[nb_instructions] = XYT(posbasx, posbasy, posbastheta + (1800* inver), BACKWARD); nb_instructions ++;
    strat_instructions[nb_instructions] = pinceArriere(2,0); nb_instructions ++;
    //Gateau fait maintenant pose cerise

    strat_instructions[nb_instructions] = toutDroit(-distanceDeux); nb_instructions ++;
    strat_instructions[nb_instructions] = pinceArriere(1,1); nb_instructions ++;
    strat_instructions[nb_instructions] = pinceArriere(2,0); nb_instructions ++;
    strat_instructions[nb_instructions] = XYT(posbasx, posbasy, (posbastheta + (1800* inver)) + (450* inver), FORWARD); nb_instructions ++;

    strat_instructions[nb_instructions] = toutDroit(-distanceDeux-20 ); nb_instructions ++;
    strat_instructions[nb_instructions] = pinceArriere(1,1); nb_instructions ++;
    strat_instructions[nb_instructions] = pinceArriere(2,0); nb_instructions ++;
    strat_instructions[nb_instructions] = XYT(posbasx, posbasy, (posbastheta + (1800* inver)) + (900* inver), FORWARD); nb_instructions ++;

    strat_instructions[nb_instructions] = toutDroit(-distanceDeux); nb_instructions ++;
    strat_instructions[nb_instructions] = pinceArriere(1,1); nb_instructions ++;
    strat_instructions[nb_instructions] = pinceArriere(2,0); nb_instructions ++;

    strat_instructions[nb_instructions] = XYT(posbasx, posbasy, posbastheta, FORWARD); nb_instructions ++;
//   pos_strat_x = posbasx; pos_strat_y = posbasy; pos_strat_theta = posbastheta;
}

//A terminer gros----------------------------------------------------------------------------------------------------
void Lidar::remplirStruct_capture_cerise(QString port_cerises){
    short posbasx, posbasy, posbastheta, val_recalage = MOITIEE_ROBOT;
    if(port_cerises == "G"){
        posbasx = 1000+15+MOITIEE_ROBOT; posbasy = 500; posbastheta = 900;
        strat_instructions[nb_instructions] = XYT(posbasx, posbasy, posbastheta+10, BACKWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = pinceArriere(0,0); nb_instructions ++;
        strat_instructions[nb_instructions] = toutDroit(-200); nb_instructions ++;
        strat_instructions[nb_instructions] = Recalage(val_recalage, BACKWARD, RECALAGE_Y); nb_instructions ++;
        strat_instructions[nb_instructions] = Aspirateur(true); nb_instructions ++;
        //strat_instructions[nb_instructions] = SortirLeTube(true); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(posbasx, posbasy, posbastheta, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = Aspirateur(false); nb_instructions ++;
        //strat_instructions[nb_instructions] = SortirLeTube(false); nb_instructions ++;
//        pos_strat_x = posbasx; pos_strat_y = posbasy; pos_strat_theta = posbastheta;
    }
    else if(port_cerises == "H"){

        //pos_strat_x = posbasx; pos_strat_y = posbasy; pos_strat_theta = posbastheta;
    }
    else if(port_cerises == "D"){
        posbasx = 1000-15-MOITIEE_ROBOT; posbasy = 3000-500; posbastheta = -900; val_recalage = 3000 - val_recalage;
        strat_instructions[nb_instructions] = XYT(posbasx, posbasy, posbastheta-10, BACKWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = pinceArriere(0,0); nb_instructions ++;
        strat_instructions[nb_instructions] = toutDroit(-200); nb_instructions ++;
        strat_instructions[nb_instructions] = Recalage(val_recalage, BACKWARD, RECALAGE_Y); nb_instructions ++;
        strat_instructions[nb_instructions] = Aspirateur(true); nb_instructions ++;
        //strat_instructions[nb_instructions] = SortirLeTube(true); nb_instructions ++;
        strat_instructions[nb_instructions] = XYT(posbasx, posbasy, posbastheta, FORWARD); nb_instructions ++;
        strat_instructions[nb_instructions] = Aspirateur(false); nb_instructions ++;
        //strat_instructions[nb_instructions] = SortirLeTube(false); nb_instructions ++;
//        pos_strat_x = posbasx; pos_strat_y = posbasy; pos_strat_theta = posbastheta;
    }
    else if(port_cerises == "D"){

        //pos_strat_x = posbasx; pos_strat_y = posbasy; pos_strat_theta = posbastheta;
    }


}


























































































void Lidar::on_browse()
{
    QString fileName = QFileDialog::getOpenFileName(this,
        tr("Open cyacd"),
        "/home/yves/Documents/qt5/can/PSoC_Creator/CRAC/Moteurs.cydsn/CortexM3/ARM_GCC_541/Release/Moteurs.cyacd"
        , tr("Cypress Bootloadable Files (*.cyacd)"));
    //if (!fileName.isNull()) m_ui->fileName->setText(fileName);
}

void Lidar::showMessage(const char *txt)
{
    //m_ui->status->setText(txt);
}


int Lidar::sendDatas(char *bytes, int size)
{
    if (size <= 8) {
        QByteArray data(bytes, size);
        m_manager->send(ID_BOOTLOAD_READ, data);
        return CYRET_SUCCESS;
    }
    QEventLoop loop;
    QTimer timer;
    timer.setSingleShot(true);
    QByteArray data = CanBusHelper::uint16ToFrame(size);
    connect(this, SIGNAL(rtrReceived()), &loop, SLOT(quit()));
    connect(&timer, SIGNAL(timeout()), &loop, SLOT(quit()));
    int retry = 1;
    while (1) {
        timer.start(1000);
        m_manager->send(ID_BOOTLOAD_READ_MULTI, data);
        loop.exec();
        if (!timer.isActive()) {
            retry--;
            if (retry==0) {
                closeCommunication();
                return CYRET_ERR_UNK;
            }
        } else {
            break;
        }
    }
    data.clear();
    data.append(bytes, size);
    while (data.size() > 0) {
        QByteArray sendData = data.leftJustified(8, '\0', true);
        retry = 2;
        while (1) {
            timer.start(1000);
            m_manager->send(ID_BOOTLOAD_READ_MULTI, sendData);
            loop.exec();
            if (!timer.isActive()) {
                retry--;
                if (retry==0) {
                    closeCommunication();
                    return CYRET_ERR_UNK;
                }
            } else {
                break;
            }
        }
        int n = data.size()-8;
        if (n<=0) data = ""; else data = data.right(n);
    }
    return CYRET_SUCCESS;
}

int Lidar::receiveDatas(char *bytes, int size)
{
    QEventLoop loop;
    QTimer timer;
    timer.setSingleShot(true);
    connect(this, SIGNAL(datasReceived()), &loop, SLOT(quit()));
    connect(&timer, SIGNAL(timeout()), &loop, SLOT(quit()));
    if (!m_receiveDatas.size()) {
        timer.start(1000);
        loop.exec();
        if (!timer.isActive()) {
            closeCommunication();
            return CYRET_ERR_UNK;
        }
    }
    memcpy(bytes, m_receiveDatas.data(), m_receiveDatas.size());
    m_receiveDatas.clear();
    return CYRET_SUCCESS;
}

void Lidar::framesReceived(const QCanBusFrame &frame)
{
    int id = frame.frameId();
    QString idStr = QString("0x%1").arg(id, 3, 16, QLatin1Char('0'));
    if (id == ID_BOOTLOAD_WRITE_MULTI) {
        int size = frame.payload().size();
        if (size == 2) {
            QByteArray data = frame.payload();
            m_size = CanBusHelper::fromFrameToUint16(data);
            m_manager->send(ID_BOOTLOAD_WRITE_MULTI); // rtr
        } else if (size == 8) {
            QByteArray data = frame.payload();
            if (data.size() > m_size) data.truncate(m_size);
            m_receiveDatas += data;
            m_size -= data.size();
            if (m_size == 0) emit datasReceived();
            m_manager->send(ID_BOOTLOAD_WRITE_MULTI); // rtr
        }
    } else if (id == ID_BOOTLOAD_READ_MULTI) {
        if (frame.frameType() == QCanBusFrame::RemoteRequestFrame) {
            emit rtrReceived();
        }
    } else if (id == ID_BOOTLOAD_WRITE) {
        m_receiveDatas = frame.payload();
        emit datasReceived();
        m_manager->send(ID_BOOTLOAD_WRITE);
    } else if (id == ID_BOOTLOAD_READ) {
        if (frame.frameType() == QCanBusFrame::RemoteRequestFrame) {
            emit rtrReceived();
        }
    }
}

int Lidar::openCommunication()
{
    if (!m_manager->isConnected()) return CYRET_ERR_BTLDR;
    recordLink();
    return CYRET_SUCCESS;
}

int Lidar::closeCommunication()
{
    removeLink();
    return CYRET_SUCCESS;
}

extern "C" {

static int openCommunication()
{
    return fenetre->openCommunication();
}

static int closeCommunication()
{
    return fenetre->closeCommunication();
}

static int writeData(unsigned char *bytes, int size)
{
    if (fenetre->sendDatas(reinterpret_cast<char *>(bytes), size)) return CYRET_ERR_UNK;
    return CYRET_SUCCESS;
}

static int readData(unsigned char *bytes, int size)
{
    if (fenetre->receiveDatas(reinterpret_cast<char *>(bytes), size)) return CYRET_ERR_UNK;
    return CYRET_SUCCESS;
}

static CyBtldr_CommunicationsData communication = {
    .OpenConnection = openCommunication,
    .CloseConnection = closeCommunication,
    .ReadData = readData,
    .WriteData = writeData,
    .MaxTransferSize = 64,
};

static void serial_progress_update(unsigned char arrayId, unsigned short rowNum)
{
    char str[100];
    sprintf(str, "Progress: array_id %d, row_num %d\n", arrayId, rowNum);
    fenetre->showMessage(str);
    fenetre->setProgress((100*rowNum)/1023);
}

}

void Lidar::setProgress(int value)
{
    //m_ui->progressBar->setValue(value);
}

void Lidar::on_program()
{
    //m_ui->progressBar->setValue(0);
    //m_ui->progressBar->setVisible(true);
    showMessage("");
    m_manager->send(ID_MOTEURS_RESET, QByteArray()); // reset du PSOC
    QTimer::singleShot(500, this, SLOT(program()));
}

void Lidar::program()
{
    int ret;// = CyBtldr_RunAction(PROGRAM, m_ui->fileName->text().toStdString().c_str(), NULL, 0, &communication, serial_progress_update);
    if (ret != CYRET_SUCCESS) {
        showMessage("Programming failed");
    } else {
        showMessage("Programming success");
    }
    //m_ui->progressBar->setVisible(false);
}

void Lidar::on_graphicsView_rubberBandChanged(const QRect &viewportRect, const QPointF &fromScenePoint, const QPointF &toScenePoint)
{

}







