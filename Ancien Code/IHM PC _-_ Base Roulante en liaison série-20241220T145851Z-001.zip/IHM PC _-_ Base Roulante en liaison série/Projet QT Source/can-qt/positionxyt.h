#ifndef POSITIONXYT_H
#define POSITIONXYT_H

#include <QMainWindow>
#include "canbusmanager.h"

namespace Ui {
class PositionXYT;
}

class PositionXYT : public QMainWindow
{
    Q_OBJECT

public:
    explicit PositionXYT(CanBusManager *manager, QWidget *parent = nullptr);
    ~PositionXYT();

private:
    Ui::PositionXYT *ui;
    CanBusManager *m_manager;
};

#endif // POSITIONXYT_H
