#include "moteurswindow.h"
#include "ident_crac.h"
#include "ui_moteurswindow.h"
#include <QFileDialog>
#include <QTimer>
#include <QDebug>

#include <QCanBus>
#include <QCanBusFrame>
#include <QCloseEvent>
#include <QDesktopServices>
#include <QtDebug>
#include <QTreeView>
#include <QProgressDialog>

extern "C" {
#include "cybootloaderutils/cybtldr_api.h"
#include "cybootloaderutils/cybtldr_api2.h"
}

const int MoteursWindow::ID_BOOTLOAD_WRITE_MULTI = 0x400;
const int MoteursWindow::ID_BOOTLOAD_READ_MULTI = 0x401;
const int MoteursWindow::ID_BOOTLOAD_WRITE = 0x402;
const int MoteursWindow::ID_BOOTLOAD_READ = 0x403;
const int MoteursWindow::ID_MOTEURS_RESET = 0x780;

static MoteursWindow *fenetre = nullptr;

static QByteArray dataFromHex(const QString &hex);

MoteursWindow::MoteursWindow(CanBusManager *manager, QWidget *parent) :
    QMainWindow(parent),
    m_ui(new Ui::MoteursWindow)
{
    m_ui->setupUi(this);
    m_ui->progressBar->hide();

    m_manager = manager;

    fenetre = this;

    connect(m_ui->browse, SIGNAL(clicked()), this, SLOT(on_browse()));
    connect(m_ui->program, SIGNAL(clicked()), this, SLOT(on_program()));

    setAttribute(Qt::WA_QuitOnClose, false);

    connect(m_manager, &CanBusManager::framesReceived , this, &MoteursWindow::checkMessages);
    connect(m_ui->sendButton_Kp,                    &QPushButton::clicked, this, &MoteursWindow::sendMessageKp);
    connect(m_ui->sendButton_Kd,                    &QPushButton::clicked, this, &MoteursWindow::sendMessageKd);
    connect(m_ui->sendButton_Ki,                    &QPushButton::clicked, this, &MoteursWindow::sendMessageKi);
    connect(m_ui->sendButton_largeurRobot,          &QPushButton::clicked, this, &MoteursWindow::sendMessageLargeurRobot);
    connect(m_ui->sendButton_resolutionRoueCodeuse, &QPushButton::clicked, this, &MoteursWindow::sendMessageKi);
    connect(m_ui->sendButton_rotation,              &QPushButton::clicked, this, &MoteursWindow::sendMessageRotation);
    connect(m_ui->sendButton_translation,           &QPushButton::clicked, this, &MoteursWindow::sendMessageTranslation);
    connect(m_ui->sendButton_position,              &QPushButton::clicked, this, &MoteursWindow::sendMessagePosition);
    connect(m_ui->sendButton_courbure,              &QPushButton::clicked, this, &MoteursWindow::sendMessageCourbure);
}


void MoteursWindow::checkMessages(const QCanBusFrame &frame)
{
    QString view;
    if (frame.frameType() == QCanBusFrame::ErrorFrame) {
        view = m_manager->getErrorString();
    } else {
        view = frame.toString();
    }

    const QString time = QString::fromLatin1("%1.%2  ")
            .arg(frame.timeStamp().seconds(), 10, 10, QLatin1Char(' '))
            .arg(frame.timeStamp().microSeconds() / 100, 4, 10, QLatin1Char('0'));




    if(frame.frameId() == 0x28){
        Odo_x = ((frame.payload()[1]&0xFF)     << 8)   | (frame.payload()[0]&0xFF);
        Odo_y = ((frame.payload()[3]&0xFF)     << 8)   | (frame.payload()[2]&0xFF);
        Odo_theta = ((frame.payload()[5]&0xFF) << 8)   | (frame.payload()[4]&0xFF);
        /*qDebug() << "Odo_x = " << Odo_x;s
        qDebug() << "Odo_y = " << Odo_y;
        qDebug() << "Odo_theta = " << Odo_x;*/
        QString string_x= QString::number(Odo_x),
                string_y= QString::number(Odo_y),
                string_theta= QString::number(Odo_theta/10.0);


        m_ui->textEdit->append(time + "    x = "+ string_x + " mm" + "      y = " + string_y  + " mm" + "      theta = " + string_theta + "°");
    }



}

static QByteArray dataFromHex(const QString &hex)
{
    QByteArray line = hex.toUtf8();
    line.replace(' ', QByteArray());
    return QByteArray::fromHex(line);
}

void MoteursWindow::sendMessageKp() const
{
    double Kdouble = m_ui->lineEdit_Kp->displayText().toDouble(nullptr);
    short K = Kdouble * 1000.0;
    qDebug() << "Kp*1000 = " << K;

    QString string_HEX= QString::number(K, 16);

    QString ZERO = "0";
    for(int i=1 ; i<8-(string_HEX.length()); i++){
        ZERO += "0";
    }

    QString string_K = ZERO + string_HEX;

    m_ui->textEdit->append("Sending Kp, Kp = " + QString::number(K, 'f', 3) + "      Id : 0x0F0 Hex : 0x" + string_K + "  ...");



    QByteArray writings = dataFromHex(string_K);

    qDebug() << "Kp Array= " << string_K[0];

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ASSERVISSEMENT_CONFIG_KPP_Qt; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);


}
void MoteursWindow::sendMessageKd() const
{
    double Kdouble = m_ui->lineEdit_Kd->displayText().toDouble(nullptr);
    int K = Kdouble * 1000.0;
    qDebug() << "Kp*1000 = " << K;

    QString string_HEX= QString::number(K, 16);

    QString ZERO = "0";
    for(int i=1 ; i<8-(string_HEX.length()); i++){
        ZERO += "0";
    }

    QString string_K = ZERO + string_HEX;

    m_ui->textEdit->append("Sending Kp, Kp = " + QString::number(K, 'f', 3) + "      Id : 0x0F1 Hex : 0x" + string_K + "  ...");



    QByteArray writings = dataFromHex(string_K);

    qDebug() << "string_K.length()= " << string_K.length();

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ASSERVISSEMENT_CONFIG_KPD_Qt; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);


}
void MoteursWindow::sendMessageKi() const
{
    double Kdouble = m_ui->lineEdit_Ki->displayText().toDouble(nullptr);
    int K = Kdouble * 1000.0;
    qDebug() << "Kp*1000 = " << K;

    QString string_HEX= QString::number(K, 16);

    QString ZERO = "0";
    for(int i=1 ; i<8-(string_HEX.length()); i++){
        ZERO += "0";
    }

    QString string_K = ZERO + string_HEX;

    m_ui->textEdit->append("Sending Kp, Kp = " + QString::number(K, 'f', 3) + "      Id : 0x0F2 Hex : 0x" + string_K + "  ...");



    QByteArray writings = dataFromHex(string_K);

    //qDebug() << "Kp Array= " << writings.toDouble(nullptr);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ASSERVISSEMENT_CONFIG_KPI_Qt; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);


}

void MoteursWindow::sendMessageLargeurRobot() const
{
    double Kdouble = m_ui->lineEdit_largeurRobot->displayText().toDouble(nullptr);
    int K = Kdouble * 100.000;
    qDebug() << "largeur robot*100 = " << K;

    QString string_HEX= QString::number(K, 16);

    QString ZERO = "0";
    for(int i=1 ; i<8-(string_HEX.length()); i++){
        ZERO += "0";
    }

    QString string_K = ZERO + string_HEX;

    m_ui->textEdit->append("Sending largeur robot, largeur = " + QString::number(K, 'f', 3) + "      Id : 0x0F3 Hex : 0x" + string_K + "  ...");



    QByteArray writings = dataFromHex(string_K);

    //qDebug() << "Kp Array= " << writings.toDouble(nullptr);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ASSERVISSEMENT_CONFIG_LARGEUR_ROBOT_Qt; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);


}
void MoteursWindow::sendMessageResolutionRoueCodeuse() const
{
    double Kdouble = m_ui->lineEdit_resolutionRoueCodeuse->displayText().toDouble(nullptr);
    int K = Kdouble * 100.000;
    qDebug() << "resolution roue codeuse*100 = " << K;

    QString string_HEX= QString::number(K, 16);

    QString ZERO = "0";
    for(int i=1 ; i<8-(string_HEX.length()); i++){
        ZERO += "0";
    }

    QString string_K = ZERO + string_HEX;

    m_ui->textEdit->append("Sending resolution roue codeuse, resolution roue codeuse = " + QString::number(K, 'f', 3) + "      Id : 0x0F4 Hex : 0x" + string_K + "  ...");



    QByteArray writings = dataFromHex(string_K);

    //qDebug() << "Kp Array= " << writings.toDouble(nullptr);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ASSERVISSEMENT_CONFIG_PERIMETRE_ROUE_CODEUSE_Qt; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);


}


void MoteursWindow::sendMessageRotation() const
{
    //double Kdouble = m_ui->lineEdit_rotation->displayText().toDouble(nullptr) * 10.0;
    //int K = Kdouble * 100.000;
    short K = m_ui->lineEdit_rotation->displayText().toShort(nullptr, 10) * 10.0;
    qDebug() << "rotation en dizieme de deg = " << K;
/*
    QString string_HEX= QString::number(K, 16);

    QString ZERO = "0";
    for(int i=1 ; i<8-(string_HEX.length()); i++){
        ZERO += "0";
    }

    QString string_K = ZERO + string_HEX;
*/
    QString string_K;
    if(K>=0){
        string_K= QString::number((K&0xFFFF), 16);
    }else{
        K = K * -1;
        qDebug() << "K = " << K;
        unsigned short inverse = ~(K&0xFFFF) +1;
         qDebug() << "inverse = " << inverse;
         K = (K + inverse)&0xFFFF;
         qDebug() << "complément à deux = " << K;
         string_K= QString::number(inverse, 16);
    }

    m_ui->textEdit->append("Sending rotation request, rotation = " + QString::number(K, 10) + "      Id : 0x0F5 Hex : 0x" + string_K + "  ...");


    QByteArray writings = dataFromHex(string_K);

    //qDebug() << "Kp Array= " << writings.toDouble(nullptr);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ASSERVISSEMENT_ROTATION_Qt; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);


}
void MoteursWindow::sendMessageTranslation() const
{
    //double Kdouble = m_ui->lineEdit_rotation->displayText().toDouble(nullptr) * 10.0;
    //int K = Kdouble * 100.000;
    short K = m_ui->lineEdit_translation->displayText().toShort(nullptr, 10);
    qDebug() << "rotation en dizieme de deg = " << K;
/*
    QString string_HEX= QString::number(K, 16);

    QString ZERO = "0";
    for(int i=1 ; i<8-(string_HEX.length()); i++){
        ZERO += "0";
    }

    QString string_K = ZERO + string_HEX;
*/
    QString string_K;
    if(K>=0){
        string_K= QString::number((K&0xFFFF), 16);
    }else{
        K = K * -1;
        qDebug() << "K = " << K;
        unsigned short inverse = ~(K&0xFFFF) +1;
         qDebug() << "inverse = " << inverse;
         K = (K + inverse)&0xFFFF;
         qDebug() << "complément à deux = " << K;
         string_K= QString::number(inverse, 16);
    }

    m_ui->textEdit->append("Sending rotation request, rotation = " + QString::number(K, 10) + "      Id : 0x0F5 Hex : 0x" + string_K + "  ...");

    QByteArray writings = dataFromHex(string_K);

    //qDebug() << "Kp Array= " << writings.toDouble(nullptr);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ASSERVISSEMENT_RECALAGE_Qt; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);


}

void MoteursWindow::sendMessagePosition() const
{

    short X = m_ui->lineEdit_pos_X->displayText().toShort(nullptr, 10);
    short Y = m_ui->lineEdit_pos_Y->displayText().toShort(nullptr, 10);
    short theta = m_ui->lineEdit_pos_theta->displayText().toShort(nullptr, 10) * 10.0;
    unsigned short sens = m_ui->lineEdit_pos_sens->displayText().toShort(nullptr, 10);


    qDebug() << "Pos X = " << X;
    qDebug() << "Pos Y = " << Y;
    qDebug() << "theta = " << theta;
    qDebug() << "sens = " << sens;
/*
    QString string_HEX= QString::number(K, 16);

    QString ZERO = "0";
    for(int i=1 ; i<8-(string_HEX.length()); i++){
        ZERO += "0";
    }

    QString string_K = ZERO + string_HEX;
*/
    QString string_X;
    QString string_Y;
    QString string_theta;
    QString string_sens;

    QString total;

    if(X>=0){
        string_X= QString::number((X&0xFFFF), 16);
    }else{
        X = X * -1;
        qDebug() << "X = " << X;
        unsigned short inverse_X = ~(X&0xFFFF) +1;
        qDebug() << "inverse = " << inverse_X;
        X = (X + inverse_X)&0xFFFF;
        qDebug() << "complément à deux = " << X;
        string_X= QString::number(inverse_X, 16);
    }
    if(string_X.length()      < 2){string_X = "000" + string_X;}
    else if(string_X.length() < 3){string_X = "00" + string_X;}
    else if(string_X.length() < 4){string_X = "0" + string_X;}

    if(Y>=0){
        string_Y= QString::number((Y&0xFFFF), 16);
    }else{
        Y = Y * -1;
        qDebug() << "Y = " << Y;
        unsigned short inverse_Y = ~(Y&0xFFFF) +1;
        qDebug() << "inverse = " << inverse_Y;
        Y = (Y + inverse_Y)&0xFFFF;
        qDebug() << "complément à deux = " << Y;
        string_X= QString::number(inverse_Y, 16);
    }
    if(string_Y.length() < 2){string_Y = "000" + string_Y;}
    else if(string_Y.length() < 3){string_Y = "00" + string_Y;}
    else if(string_Y.length() < 4){string_Y = "0" + string_Y;}

    if(theta>=0){
        string_theta= QString::number((theta&0xFFFF), 16);
    }else{
        theta = theta * -1;
        qDebug() << "theta = " << theta;
        unsigned short inverse_theta = ~(theta&0xFFFF) +1;
        qDebug() << "inverse = " << inverse_theta;
        theta = (theta + inverse_theta)&0xFFFF;
        qDebug() << "complément à deux = " << theta;
        string_theta= QString::number(inverse_theta, 16);
    }
    if(string_theta.length() < 2){string_theta = "000" + string_theta;}
    else if(string_theta.length() < 3){string_theta = "00" + string_theta;}
    else if(string_theta.length() < 4){string_theta = "0" + string_theta;}

    if(sens>=0){
        string_sens= QString::number((sens&0xFF), 16);
    }else{
        sens = sens * -1;
        qDebug() << "sens = " << sens;
        unsigned short inverse_sens = ~(sens&0xFF) +1;
        qDebug() << "inverse = " << inverse_sens;
        sens = (sens + inverse_sens)&0xFFFF;
        qDebug() << "complément à deux = " << sens;
        string_sens= QString::number(inverse_sens, 16);
    }

    if(string_sens.length() < 2){string_sens = "0" + string_sens;}


    total = string_X + string_Y + string_theta + string_sens;

    m_ui->textEdit->append("Sending position request, X = " + QString::number(X, 10) +
                           "  Y = " + QString::number(Y, 10) +
                           " theta en 1/10 de degré = " + QString::number(theta, 10) +
                           "      Id : 0x0F7 Hex : 0x " + total + "  ...");

    QByteArray writings = dataFromHex(total);

    //qDebug() << "Kp Array= " << writings.toDouble(nullptr);

    QCanBusFrame frame;
    writings.truncate(8);
    frame.setPayload(writings);
    qint32 id = ASSERVISSEMENT_XYT_Qt; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    //if (m_ui->remoteBox->isChecked())
        //frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    //else
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);


}


void MoteursWindow::sendMessageCourbure() const
{

    short rayon = m_ui->lineEdit_courbure_rayon->displayText().toShort(nullptr, 10);
    short theta = m_ui->lineEdit_courbure_theta->displayText().toShort(nullptr, 10) * 10.0;
    unsigned short sens = m_ui->lineEdit_courbure_sens->displayText().toShort(nullptr, 10);


    qDebug() << "rayon = " << rayon;
    qDebug() << "theta = " << theta;
    qDebug() << "sens = " << sens;
/*
    QString string_HEX= QString::number(K, 16);

    QString ZERO = "0";
    for(int i=1 ; i<8-(string_HEX.length()); i++){
        ZERO += "0";
    }

    QString string_K = ZERO + string_HEX;
*/
    QString string_rayon;
    QString string_theta;
    QString string_sens;

    QString total;

    if(rayon>=0){
        string_rayon= QString::number((rayon&0xFFFF), 16);
    }else{
        rayon = rayon * -1;
        qDebug() << "rayon = " << rayon;
        unsigned short inverse_rayon = ~(rayon&0xFFFF) +1;
        qDebug() << "inverse = " << inverse_rayon;
        rayon = (rayon + inverse_rayon)&0xFFFF;
        qDebug() << "complément à deux = " << rayon;
        string_rayon= QString::number(inverse_rayon, 16);
    }
    if(string_rayon.length()      < 2){string_rayon = "000" + string_rayon;}
    else if(string_rayon.length() < 3){string_rayon = "00" + string_rayon;}
    else if(string_rayon.length() < 4){string_rayon = "0" + string_rayon;}

    if(theta>=0){
        string_theta= QString::number((theta&0xFFFF), 16);
    }else{
        theta = theta * -1;
        qDebug() << "theta = " << theta;
        unsigned short inverse_theta = ~(theta&0xFFFF) +1;
        qDebug() << "inverse = " << inverse_theta;
        theta = (theta + inverse_theta)&0xFFFF;
        qDebug() << "complément à deux = " << theta;
        string_theta= QString::number(inverse_theta, 16);
    }
    if(string_theta.length() < 2){string_theta = "000" + string_theta;}
    else if(string_theta.length() < 3){string_theta = "00" + string_theta;}
    else if(string_theta.length() < 4){string_theta = "0" + string_theta;}

    if(sens>=0){
        string_sens= QString::number((sens&0xFF), 16);
    }else{
        sens = sens * -1;
        qDebug() << "sens = " << sens;
        unsigned short inverse_sens = ~(sens&0xFF) +1;
        qDebug() << "inverse = " << inverse_sens;
        sens = (sens + inverse_sens)&0xFFFF;
        qDebug() << "complément à deux = " << sens;
        string_sens= QString::number(inverse_sens, 16);
    }

    if(string_sens.length() < 2){string_sens = "0" + string_sens;}


    total = string_rayon + string_theta + string_sens;

    m_ui->textEdit->append("Sending position request, X = " + QString::number(rayon, 10)        +
                           " theta en 1/10 de degré = "     + QString::number(theta, 10)    +
                           "      Id : 0x0F8 Hex : 0x "     + total + "  ...");

    QByteArray writings = dataFromHex(total);

    //qDebug() << "Kp Array= " << writings.toDouble(nullptr);

    QCanBusFrame frame;
    writings.truncate(8);
    frame.setPayload(writings);
    qint32 id = ASSERVISSEMENT_COURBURE_Qt; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    //if (m_ui->remoteBox->isChecked())
        //frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    //else
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);


}




void MoteursWindow::on_browse()
{
    QString fileName = QFileDialog::getOpenFileName(this,
        tr("Open cyacd"),
        "/home/yves/Documents/qt5/can/PSoC_Creator/CRAC/Moteurs.cydsn/CortexM3/ARM_GCC_541/Release/Moteurs.cyacd"
        , tr("Cypress Bootloadable Files (*.cyacd)"));
    if (!fileName.isNull()) m_ui->fileName->setText(fileName);
}

void MoteursWindow::showMessage(const char *txt)
{
    m_ui->status->setText(txt);
}

MoteursWindow::~MoteursWindow()
{
    delete m_ui;
}

int MoteursWindow::sendDatas(char *bytes, int size)
{
    if (size <= 8) {
        QByteArray data(bytes, size);
        m_manager->send(ID_BOOTLOAD_READ, data);
        return CYRET_SUCCESS;
    }
    QEventLoop loop;
    QTimer timer;
    timer.setSingleShot(true);
    QByteArray data = CanBusHelper::uint16ToFrame(size);
    connect(this, SIGNAL(rtrReceived()), &loop, SLOT(quit()));
    connect(&timer, SIGNAL(timeout()), &loop, SLOT(quit()));
    int retry = 1;
    while (1) {
        timer.start(1000);
        m_manager->send(ID_BOOTLOAD_READ_MULTI, data);
        loop.exec();
        if (!timer.isActive()) {
            retry--;
            if (retry==0) {
                closeCommunication();
                return CYRET_ERR_UNK;
            }
        } else {
            break;
        }
    }
    data.clear();
    data.append(bytes, size);
    while (data.size() > 0) {
        QByteArray sendData = data.leftJustified(8, '\0', true);
        retry = 2;
        while (1) {
            timer.start(1000);
            m_manager->send(ID_BOOTLOAD_READ_MULTI, sendData);
            loop.exec();
            if (!timer.isActive()) {
                retry--;
                if (retry==0) {
                    closeCommunication();
                    return CYRET_ERR_UNK;
                }
            } else {
                break;
            }
        }
        int n = data.size()-8;
        if (n<=0) data = ""; else data = data.right(n);
    }
    return CYRET_SUCCESS;
}

int MoteursWindow::receiveDatas(char *bytes, int size)
{
    QEventLoop loop;
    QTimer timer;
    timer.setSingleShot(true);
    connect(this, SIGNAL(datasReceived()), &loop, SLOT(quit()));
    connect(&timer, SIGNAL(timeout()), &loop, SLOT(quit()));
    if (!m_receiveDatas.size()) {
        timer.start(1000);
        loop.exec();
        if (!timer.isActive()) {
            closeCommunication();
            return CYRET_ERR_UNK;
        }
    }
    memcpy(bytes, m_receiveDatas.data(), m_receiveDatas.size());
    m_receiveDatas.clear();
    return CYRET_SUCCESS;
}

void MoteursWindow::framesReceived(const QCanBusFrame &frame)
{
    int id = frame.frameId();
    QString idStr = QString("0x%1").arg(id, 3, 16, QLatin1Char('0'));
    if (id == ID_BOOTLOAD_WRITE_MULTI) {
        int size = frame.payload().size();
        if (size == 2) {
            QByteArray data = frame.payload();
            m_size = CanBusHelper::fromFrameToUint16(data);
            m_manager->send(ID_BOOTLOAD_WRITE_MULTI); // rtr
        } else if (size == 8) {
            QByteArray data = frame.payload();
            if (data.size() > m_size) data.truncate(m_size);
            m_receiveDatas += data;
            m_size -= data.size();
            if (m_size == 0) emit datasReceived();
            m_manager->send(ID_BOOTLOAD_WRITE_MULTI); // rtr
        }
    } else if (id == ID_BOOTLOAD_READ_MULTI) {
        if (frame.frameType() == QCanBusFrame::RemoteRequestFrame) {
            emit rtrReceived();
        }
    } else if (id == ID_BOOTLOAD_WRITE) {
        m_receiveDatas = frame.payload();
        emit datasReceived();
        m_manager->send(ID_BOOTLOAD_WRITE);
    } else if (id == ID_BOOTLOAD_READ) {
        if (frame.frameType() == QCanBusFrame::RemoteRequestFrame) {
            emit rtrReceived();
        }
    }
}

int MoteursWindow::openCommunication()
{
    if (!m_manager->isConnected()) return CYRET_ERR_BTLDR;
    recordLink();
    return CYRET_SUCCESS;
}

int MoteursWindow::closeCommunication()
{
    removeLink();
    return CYRET_SUCCESS;
}

extern "C" {

static int openCommunication()
{
    return fenetre->openCommunication();
}

static int closeCommunication()
{
    return fenetre->closeCommunication();
}

static int writeData(unsigned char *bytes, int size)
{
    if (fenetre->sendDatas(reinterpret_cast<char *>(bytes), size)) return CYRET_ERR_UNK;
    return CYRET_SUCCESS;
}

static int readData(unsigned char *bytes, int size)
{
    if (fenetre->receiveDatas(reinterpret_cast<char *>(bytes), size)) return CYRET_ERR_UNK;
    return CYRET_SUCCESS;
}

static CyBtldr_CommunicationsData communication = {
    .OpenConnection = openCommunication,
    .CloseConnection = closeCommunication,
    .ReadData = readData,
    .WriteData = writeData,
    .MaxTransferSize = 64,
};

static void serial_progress_update(unsigned char arrayId, unsigned short rowNum)
{
    char str[100];
    sprintf(str, "Progress: array_id %d, row_num %d\n", arrayId, rowNum);
    fenetre->showMessage(str);
    fenetre->setProgress((100*rowNum)/1023);
}

}

void MoteursWindow::setProgress(int value)
{
    m_ui->progressBar->setValue(value);
}

void MoteursWindow::on_program()
{
    m_ui->progressBar->setValue(0);
    m_ui->progressBar->setVisible(true);
    showMessage("");
    m_manager->send(ID_MOTEURS_RESET, QByteArray()); // reset du PSOC
    QTimer::singleShot(500, this, SLOT(program()));
}

void MoteursWindow::program()
{
    int ret = CyBtldr_RunAction(PROGRAM, m_ui->fileName->text().toStdString().c_str(), NULL, 0, &communication, serial_progress_update);
    if (ret != CYRET_SUCCESS) {
        showMessage("Programming failed");
    } else {
        showMessage("Programming success");
    }
    m_ui->progressBar->setVisible(false);
}



