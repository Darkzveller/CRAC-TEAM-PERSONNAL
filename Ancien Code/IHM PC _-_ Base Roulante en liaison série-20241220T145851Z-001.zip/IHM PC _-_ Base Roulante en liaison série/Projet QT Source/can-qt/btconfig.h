#ifndef BTCONFIG_H
#define BTCONFIG_H

#include <QQuickWidget>
#include "canbusmanager.h"

class BtConfig : public QQuickWidget
{
    Q_OBJECT
public:
    BtConfig(CanBusManager *manager);
    QString canDataLSB;
public slots:
    void envoyer(QString dataStart, QString dataEnd, QString cstInclu); // déclaration des données dans envoyer()
private:
    CanBusManager *m_manager;
};

#endif // BTCONFIG_H
