#ifndef CANBUSMANAGER_H
#define CANBUSMANAGER_H

#include <QObject>
#include <QCanBus>
#include <QCanBusDevice>
#include <QVariant>
#include <QCanBusFrame>

#include "canmultiframes.h"

class CanBusManager : public QObject
{
    Q_OBJECT
public:
    CanBusManager(QObject *parent = nullptr);
    virtual ~CanBusManager();
    bool connectDevice(const QString &plugin, const QString &interfaceName);
    void disconnectDevice();
private:
    typedef QPair<QCanBusDevice::ConfigurationKey, QVariant> ConfigurationItem;
    QCanBusDevice *m_canDevice = nullptr;
    QString m_errorString, m_statusString;
    int m_bitrate = 1000000;
    int m_serialBaud = 921600;
    CanMultiFramesReader *m_multiReader;
    CanMultiFramesWriter *m_multiWriter;
    QMetaObject::Connection m_extMultiReaderCnx, m_extMultiWriterCnx;
    void writeFrame(const QCanBusFrame &frame);
public:
    const QString &getErrorString() const { return m_errorString; }
    const QString &getStatusString() const { return m_statusString; }
    bool isConnected() const { return m_canDevice; }
    void setBitrate(int bitrate) { m_bitrate = bitrate; }
    void setSerialBaud(int baud) { m_serialBaud = baud; }
    void send(QCanBusFrame &frame);
    void send(quint16 id, QByteArray data);
    void send(quint16 id, int len = 0); // Remote Request
    bool sendMulti(quint16 id, QByteArray data, const QObject *obj = nullptr, const char *method = nullptr, const QByteArray &initData = QByteArray());
    bool receiveMulti(quint16 id, const QObject *obj = nullptr, const char *method = nullptr, bool noLastRemoteRequest = false);
    int statusMultiReader() { return m_multiReader->status(); }
    int statusMultiWriter() { return m_multiWriter->status(); }
    QByteArray &getMultiReply() { return m_multiReader->getReply(); }
    int getMultiExtraError() { return m_multiReader->getExtraError(); }
    int getMultiExtraTotalSize() { return m_multiReader->getExtraTotalSize(); }
signals:
    void errorOccurred();
    void framesReceived(const QCanBusFrame &);
    void framesWritten(qint64 n);
private slots:
    void receive();
    void sendFrames(qint64 n) { emit framesWritten(n); }
    void canBusError(QCanBusDevice::CanBusError);
};

#endif // CANBUSMANAGER_H
