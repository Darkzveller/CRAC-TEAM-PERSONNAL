#include "moteurswindow.h"
#include "ident_crac.h"
#include "ui_moteurswindow.h"


extern "C" {
#include "cybootloaderutils/cybtldr_api.h"
#include "cybootloaderutils/cybtldr_api2.h"
}

#define PI 3.141592653589793238462643383279502884197

const int MoteursWindow::ID_BOOTLOAD_WRITE_MULTI = 0x400;
const int MoteursWindow::ID_BOOTLOAD_READ_MULTI = 0x401;
const int MoteursWindow::ID_BOOTLOAD_WRITE = 0x402;
const int MoteursWindow::ID_BOOTLOAD_READ = 0x403;
const int MoteursWindow::ID_MOTEURS_RESET = 0x780;

static MoteursWindow *fenetre = nullptr;


QString SuiteAction[100];
unsigned char nbAction = 0, FIN_MOUV_ALGO_GATEAU = 0, etat_algo_gateau = 0, position_stepMotor = 0;
const char FIN_MOUV_ROTATION = 0x30, FIN_MOUV_TRANSLATION = 0x40;
bool ENREGISTREMENT_BOUTON = false, ALGO_GATEAU = false, ALGO_GATEAU_DESORDRE = false, WAITING_FOR_BASE_TRANSLATION = false, WAITING_FOR_HERKULEX = false, WAITING_FOR_BASE_ROTATION = false, WAITING_FOR_STEP_MOTOR = false;



static QByteArray dataFromHex(const QString &hex);
MoteursWindow::MoteursWindow(CanBusManager *manager, QWidget *parent) :
    QMainWindow(parent),
    m_ui(new Ui::MoteursWindow)
{
    m_ui->setupUi(this);
    m_ui->progressBar->hide();

    m_manager = manager;

    fenetre = this;

    connect(m_ui->browse, SIGNAL(clicked()), this, SLOT(on_browse()));
    connect(m_ui->program, SIGNAL(clicked()), this, SLOT(on_program()));

    setAttribute(Qt::WA_QuitOnClose, false);

    connect(m_manager, &CanBusManager::framesReceived , this, &MoteursWindow::checkMessages);
    connect(m_ui->sendButton_Kp,                    &QPushButton::clicked, this, &MoteursWindow::sendMessageKp);
    connect(m_ui->sendButton_Kd,                    &QPushButton::clicked, this, &MoteursWindow::sendMessageKd);
    connect(m_ui->sendButton_Ki,                    &QPushButton::clicked, this, &MoteursWindow::sendMessageKi);
    connect(m_ui->sendButton_largeurRobot,          &QPushButton::clicked, this, &MoteursWindow::sendMessageLargeurRobot);
    connect(m_ui->sendButton_resolutionRoueCodeuse, &QPushButton::clicked, this, &MoteursWindow::sendMessageResolutionRoueCodeuse);
    connect(m_ui->sendButton_Ki,                    &QPushButton::clicked, this, &MoteursWindow::sendMessageKi);
    connect(m_ui->sendButton_rotation,              &QPushButton::clicked, this, &MoteursWindow::sendMessageRotation);
    connect(m_ui->sendButton_translation,           &QPushButton::clicked, this, &MoteursWindow::sendMessageTranslation);
    connect(m_ui->sendButton_position,              &QPushButton::clicked, this, &MoteursWindow::sendMessagePosition);
    connect(m_ui->sendButton_courbure,              &QPushButton::clicked, this, &MoteursWindow::sendMessageCourbure);
    connect(m_ui->sendButton_recalage,              &QPushButton::clicked, this, &MoteursWindow::sendMessageRecalage);
    unsigned short K = 140;
    double theta = (90+45) * PI/180;
    qDebug() << "translation en mm de deg = " << K;
    unsigned short x = (short(cos(theta))*K);//si theta ==
    unsigned short y = (short(sin(theta))*K);
    qDebug() << "x = " << x;
    qDebug() << "y = " << y;

}


void MoteursWindow::checkMessages(const QCanBusFrame &frame)
{
    QString view;
    if (frame.frameType() == QCanBusFrame::ErrorFrame) {
        view = m_manager->getErrorString();
    } else {
        view = frame.toString();
    }

    const QString time = QString::fromLatin1("%1.%2  ")
            .arg(frame.timeStamp().seconds(), 10, 10, QLatin1Char(' '))
            .arg(frame.timeStamp().microSeconds() / 100, 4, 10, QLatin1Char('0'));


    uint8_t data[8] = {0};
    for(int i = 0; i<frame.payload().length(); i++){
        data[i] = frame.payload()[i]&0xFF;
    }

    if(frame.frameId() == 0x28){
        Odo_x = ((data[1]&0xFF)     << 8)   | (data[0]&0xFF);
        Odo_y = ((data[3]&0xFF)     << 8)   | (data[2]&0xFF);
        Odo_theta = ((data[5]&0xFF) << 8)   | (data[4]&0xFF);
        /*qDebug() << "Odo_x = " << Odo_x;s
        qDebug() << "Odo_y = " << Odo_y;
        qDebug() << "Odo_theta = " << Odo_x;*/
        QString string_x= QString::number(Odo_x),
                string_y= QString::number(Odo_y),
                string_theta= QString::number(Odo_theta/10.0);


        m_ui->textEdit->append(time + "    x = "+ string_x + " mm" + "      y = " + string_y  + " mm" + "      theta = " + string_theta + "°");
    }else if (frame.frameId() == INSTRUCTION_END_MOTEUR){
        m_ui->textEdit_2->append("Reçu INSTRUCTION_END_MOTEUR   " + QString::number(data[0]));
        FIN_MOUV_ALGO_GATEAU = data[0];
    }else if (frame.frameId() == ACKNOWLEDGE_MOTEUR){
        m_ui->textEdit_2->append("Reçu ACKNOWLEDGE_MOTEUR   " + QString::number(data[0]));
    }else if(frame.frameId() == BALISE_DANGER){
         m_ui->textEdit_2->append("Reçu BALISE_DANGER   " + QString::number(data[0]));
    }else if(frame.frameId() == BALISE_END_DANGER){
        m_ui->textEdit_2->append("Reçu BALISE_END_DANGER   " + QString::number(data[0]));
    }else if(frame.frameId() == IDCAN_POS_XY_OBJET){

    }
    else{
        m_ui->textEdit_2->append("Reçu Inconnu   ID: 0x" + QString::number(frame.frameId(), 16) + ",  data 0 : "+ QString::number(data[0]));
    }

    algo_gateau(frame.frameId(), data[0]);


}

static QByteArray dataFromHex(const QString &hex)
{
    QByteArray line = hex.toUtf8();
    line.replace(' ', QByteArray());
    return QByteArray::fromHex(line);
}

void MoteursWindow::sendMessageKp() const
{
    double Kdouble = m_ui->lineEdit_Kp->displayText().toDouble(nullptr);
    short K = Kdouble * 1000.0;
    qDebug() << "Kp*1000 = " << K;

    QString string_HEX= QString::number(K, 16);

    QString ZERO = "0";
    for(int i=1 ; i<8-(string_HEX.length()); i++){
        ZERO += "0";
    }

    QString string_K = ZERO + string_HEX;

    m_ui->textEdit->append("Sending Kp, ASSERVISSEMENT_CONFIG_KPP_Qt, Kp = " + QString::number(K, 'f', 3) + "      Id : 0x0F0 Hex : 0x" + string_K + "  ...");



    QByteArray writings = dataFromHex(string_K);

    qDebug() << "Kp Array= " << string_K[0];

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ASSERVISSEMENT_CONFIG_KPP_Qt; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);


}

void MoteursWindow::sendMessageKd() const
{
    double Kdouble = m_ui->lineEdit_Kd->displayText().toDouble(nullptr);
    int K = Kdouble * 1000.0;
    qDebug() << "Kp*1000 = " << K;

    QString string_HEX= QString::number(K, 16);

    QString ZERO = "0";
    for(int i=1 ; i<8-(string_HEX.length()); i++){
        ZERO += "0";
    }

    QString string_K = ZERO + string_HEX;

    m_ui->textEdit->append("Sending Kd, ASSERVISSEMENT_CONFIG_KPD_Qt, Kd = " + QString::number(K, 'f', 3) + "      Id : 0x0F1 Hex : 0x" + string_K + "  ...");



    QByteArray writings = dataFromHex(string_K);

    qDebug() << "string_K.length()= " << string_K.length();

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ASSERVISSEMENT_CONFIG_KPD_Qt; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);


}

void MoteursWindow::sendMessageKi() const
{
    double Kdouble = m_ui->lineEdit_Ki->displayText().toDouble(nullptr);
    int K = Kdouble * 1000.0;
    qDebug() << "Kp*1000 = " << K;

    QString string_HEX= QString::number(K, 16);

    QString ZERO = "0";
    for(int i=1 ; i<8-(string_HEX.length()); i++){
        ZERO += "0";
    }

    QString string_K = ZERO + string_HEX;

    m_ui->textEdit->append("Sending Ki, ASSERVISSEMENT_CONFIG_KPI_Qt, Ki = " + QString::number(K, 'f', 3) + "      Id : 0x0F2 Hex : 0x" + string_K + "  ...");



    QByteArray writings = dataFromHex(string_K);

    //qDebug() << "Kp Array= " << writings.toDouble(nullptr);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ASSERVISSEMENT_CONFIG_KPI_Qt; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);


}


void MoteursWindow::sendMessageLargeurRobot() const
{
    double Kdouble = m_ui->lineEdit_largeurRobot->displayText().toDouble(nullptr);
    int K = Kdouble * 100.000;
    qDebug() << "largeur robot*100 = " << K;

    QString string_HEX= QString::number(K, 16);

    QString ZERO = "0";
    for(int i=1 ; i<8-(string_HEX.length()); i++){
        ZERO += "0";
    }

    QString string_K = ZERO + string_HEX;

    m_ui->textEdit->append("Sending largeur robot, ASSERVISSEMENT_CONFIG_LARGEUR_ROBOT_Qt, largeur = " + QString::number(K, 'f', 3) + "      Id : 0x0F3 Hex : 0x" + string_K + "  ...");



    QByteArray writings = dataFromHex(string_K);

    //qDebug() << "Kp Array= " << writings.toDouble(nullptr);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ASSERVISSEMENT_CONFIG_LARGEUR_ROBOT_Qt; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);


}

void MoteursWindow::sendMessageResolutionRoueCodeuse() const
{
    double Kdouble = m_ui->lineEdit_resolutionRoueCodeuse->displayText().toDouble(nullptr);
    int K = Kdouble * 100.000;
    qDebug() << "resolution roue codeuse*100 = " << K;

    QString string_HEX= QString::number(K, 16);

    QString ZERO = "0";
    for(int i=1 ; i<8-(string_HEX.length()); i++){
        ZERO += "0";
    }

    QString string_K = ZERO + string_HEX;

    m_ui->textEdit->append("Sending resolution roue codeuse, ASSERVISSEMENT_CONFIG_PERIMETRE_ROUE_CODEUSE_Qt, resolution roue codeuse = " + QString::number(K, 'f', 3) + "      Id : 0x0F4 Hex : 0x" + string_K + "  ...");



    QByteArray writings = dataFromHex(string_K);

    //qDebug() << "Kp Array= " << writings.toDouble(nullptr);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ASSERVISSEMENT_CONFIG_PERIMETRE_ROUE_CODEUSE_Qt; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);


}


void MoteursWindow::on_sendButton_asservissement_activer_clicked()
{
    QString actif = "01";
    QByteArray writings = dataFromHex(actif);

    //qDebug() << "Kp Array= " << writings.toDouble(nullptr);
     m_ui->textEdit->append("Activation asservissement, ASSERVISSEMENT_ENABLE");
    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ASSERVISSEMENT_ENABLE; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);
}

void MoteursWindow::on_sendButton_asservissement_desactiver_clicked()
{
    QString actif = "00";
    QByteArray writings = dataFromHex(actif);

    //qDebug() << "Kp Array= " << writings.toDouble(nullptr);
    m_ui->textEdit->append("Desactivation asservissement, ASSERVISSEMENT_ENABLE");
    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ASSERVISSEMENT_ENABLE; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);
}


void MoteursWindow::sendMessageRotation()
{
    //double Kdouble = m_ui->lineEdit_rotation->displayText().toDouble(nullptr) * 10.0;
    //int K = Kdouble * 100.000;
    unsigned short K = m_ui->lineEdit_rotation->displayText().toShort(nullptr, 10);
    qDebug() << "rotation en deg = " << K;
    rotation(K);

}

void MoteursWindow::sendMessageTranslation() const
{
    //double Kdouble = m_ui->lineEdit_rotation->displayText().toDouble(nullptr) * 10.0;
    //int K = Kdouble * 100.000;
    unsigned short K = (m_ui->lineEdit_translation->displayText().toShort(nullptr, 10) & 0xFFFF);
    qDebug() << "translation en mm de deg = " << K;
/*
    QString string_HEX= QString::number(K, 16);

    QString ZERO = "0";
    for(int i=1 ; i<8-(string_HEX.length()); i++){
        ZERO += "0";
    }

    QString string_K = ZERO + string_HEX;
*/
    QString string_K;

        string_K= QString::number((K&0xFF), 16);
        if(string_K.length() < 2){string_K = "0" + string_K;}
    QString string_K_2;

        string_K_2= QString::number(((K>>8)&0xFF), 16);
        if(string_K_2.length() < 2){string_K_2 = "0" + string_K_2;}

    QString total = string_K + string_K_2;
    m_ui->textEdit->append("Sending translation request, ASSERVISSEMENT_RECALAGE, distance = " + QString::number(K, 10)
                           + ",     Id : 0x024,  Hex : 0x " + total
                           + "  ...");

    QByteArray writings = dataFromHex(total);

    //qDebug() << "Kp Array= " << writings.toDouble(nullptr);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ASSERVISSEMENT_RECALAGE; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);


}

void MoteursWindow::on_sendButton_vitesse_clicked()
{
    unsigned short vitesse = (m_ui->lineEdit_vitesse->displayText().toShort(nullptr, 10) & 0xFFFF);
    unsigned short accel = (m_ui->lineEdit_acceleration->displayText().toShort(nullptr, 10) & 0xFFFF);
    qDebug() << "vitesse max = " << vitesse;
//    if(vitesse<50)vitesse=50;
//    else if(vitesse>600)vitesse=600;

//    if(accel<500)accel=500;
//    else if(accel>6000)accel=6000;//pour plus tard

    QString string_K_1;
    QString string_K_2;

        string_K_1= QString::number((vitesse&0xFF), 16);
        if(string_K_1.length() < 2){string_K_1 = "0" + string_K_1;}
        string_K_2= QString::number(((vitesse>>8)&0xFF), 16);
        if(string_K_2.length() < 2){string_K_2 = "0" + string_K_2;}

    QString string_accel_1;
    QString string_accel_2;

        string_accel_1= QString::number((accel&0xFF), 16);
        if(string_accel_1.length() < 2){string_accel_1 = "0" + string_accel_1;}
        string_accel_2= QString::number(((accel>>8)&0xFF), 16);
        if(string_accel_2.length() < 2){string_accel_2 = "0" + string_accel_2;}


    QString total = string_K_1 + string_K_2 + string_accel_1 + string_accel_2 ;


    m_ui->textEdit->append("");
    m_ui->textEdit->append("Envoi vitesse et accel config, ASSERVISSEMENT_CONFIG, vitesse = " + QString::number(vitesse, 10)
                           + ",   accel = " + QString::number(accel, 10)
                           + "      Id : 0x022 Hex : 0x " + total
                           + "  ...");

    QByteArray writings = dataFromHex(total);

    //qDebug() << "Kp Array= " << writings.toDouble(nullptr);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ASSERVISSEMENT_CONFIG; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);



}


void MoteursWindow::sendMessageRecalage() const{
    //double Kdouble = m_ui->lineEdit_rotation->displayText().toDouble(nullptr) * 10.0;
    //int K = Kdouble * 100.000;
    unsigned short K = (m_ui->lineEdit_recalage_distance->displayText().toShort(nullptr, 10) & 0xFFFF);
    qDebug() << "translation en mm de deg = " << K;
    unsigned short largeurRobot = (m_ui->lineEdit_recalage_largeur_robot->displayText().toShort(nullptr, 10) & 0xFFFF);///2.0;

    QString selection = m_ui->comboBox_coordonnee->currentText();
    QString coordonnee = "01";
    if(selection == "y"){coordonnee = "02";}

    QString emplacement = m_ui->comboBox_recalage_emplacement->currentText();
    if(selection == "y"){
        if((emplacement == "En haut à droite") || (emplacement == "En bas à droite")){
            largeurRobot = 3000 - largeurRobot;
        }
    }else if(selection == "x"){
        if((emplacement == "En bas à gauche") || (emplacement == "En bas à droite")){
            largeurRobot = 2000 - largeurRobot;
        }
    }

/*
    QString string_HEX= QString::number(K, 16);

    QString ZERO = "0";
    for(int i=1 ; i<8-(string_HEX.length()); i++){
        ZERO += "0";
    }

    QString string_K = ZERO + string_HEX;
*/
    QString string_K_1;
    QString string_K_2;

        string_K_1= QString::number((K&0xFF), 16);
        if(string_K_1.length() < 2){string_K_1 = "0" + string_K_1;}
        string_K_2= QString::number(((K>>8)&0xFF), 16);
        if(string_K_2.length() < 2){string_K_2 = "0" + string_K_2;}

    QString string_largeurRobot_1;
    QString string_largeurRobot_2;

                string_largeurRobot_1= QString::number((largeurRobot&0xFF), 16);
                if(string_largeurRobot_1.length() < 2){string_largeurRobot_1 = "0" + string_largeurRobot_1;}

                string_largeurRobot_2= QString::number(((largeurRobot>>8)&0xFF), 16);
                if(string_largeurRobot_2.length() < 2){string_largeurRobot_2 = "0" + string_largeurRobot_2;}



    QString total = string_K_1 + string_K_2 + coordonnee + string_largeurRobot_1 + string_largeurRobot_2;
    m_ui->textEdit->append("");
    m_ui->textEdit->append("Sending recalage request, ASSERVISSEMENT_RECALAGE, distance = " + QString::number(K, 10)
                           + ",  val Recalage : " + QString::number(largeurRobot, 10)
                           + ",      Id : 0x024, Hex : 0x " + total
                           + "   ...");

    QByteArray writings = dataFromHex(total);

    //qDebug() << "Kp Array= " << writings.toDouble(nullptr);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ASSERVISSEMENT_RECALAGE; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);

}

void MoteursWindow::sendMessagePosition() const
{

    unsigned short X = m_ui->lineEdit_pos_X->displayText().toShort(nullptr, 10);
    unsigned short Y = m_ui->lineEdit_pos_Y->displayText().toShort(nullptr, 10);
    unsigned short theta = m_ui->lineEdit_pos_theta->displayText().toShort(nullptr, 10) * 10.0;
    unsigned short sens = m_ui->lineEdit_pos_sens->displayText().toShort(nullptr, 10);


    qDebug() << "Pos X = " << X;
    qDebug() << "Pos Y = " << Y;
    qDebug() << "theta = " << theta;
    qDebug() << "sens = " << sens;
/*
    QString string_HEX= QString::number(K, 16);

    QString ZERO = "0";
    for(int i=1 ; i<8-(string_HEX.length()); i++){
        ZERO += "0";
    }

    QString string_K = ZERO + string_HEX;
*/
    QString string_X;
    QString string_X_2;

    QString string_Y;
    QString string_Y_2;

    QString string_theta;
    QString string_theta_2;

    QString string_sens;

    QString total;


        string_X= QString::number((X&0xFF), 16);
    if(string_X.length()      < 2){string_X = "0" + string_X;}

    string_X_2= QString::number(((X>>8)&0xFF), 16);
    if(string_X_2.length()      < 2){string_X_2 = "0" + string_X_2;}



        string_Y= QString::number((Y&0xFF), 16);
    if(string_Y.length() < 2){string_Y = "0" + string_Y;}

    string_Y_2= QString::number(((Y>>8)&0xFF), 16);
    if(string_Y_2.length() < 2){string_Y_2 = "0" + string_Y_2;}



        string_theta= QString::number((theta&0xFF), 16);
    if(string_theta.length() < 2){string_theta = "0" + string_theta;}

    string_theta_2= QString::number(((theta>>8)&0xFF), 16);
    if(string_theta_2.length() < 2){string_theta_2 = "0" + string_theta_2;}



        string_sens= QString::number((sens&0xFF), 16);
    if(string_sens.length() < 2){string_sens = "0" + string_sens;}


    total = string_X + string_X_2 + string_Y + string_Y_2 + string_theta + string_theta_2 + string_sens;

    m_ui->textEdit->append("Sending position request, ASSERVISSEMENT_XYT, X = " + QString::number(X, 10) +
                           "  Y = " + QString::number(Y, 10) +
                           " theta en 1/10 de degré = " + QString::number(theta, 10) +
                           "      Id : 0x0F7 Hex : 0x " + total + "  ...");

    QByteArray writings = dataFromHex(total);

    //qDebug() << "Kp Array= " << writings.toDouble(nullptr);

    QCanBusFrame frame;
    writings.truncate(8);
    frame.setPayload(writings);
    qint32 id = ASSERVISSEMENT_XYT; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    //if (m_ui->remoteBox->isChecked())
        //frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    //else
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);


}

void MoteursWindow::sendMessageCourbure() const
{

    unsigned short rayon = m_ui->lineEdit_courbure_rayon->displayText().toShort(nullptr, 10);
    unsigned short theta = m_ui->lineEdit_courbure_theta->displayText().toShort(nullptr, 10) * 10.0;
    unsigned short sens = m_ui->lineEdit_courbure_sens->displayText().toShort(nullptr, 10);


    qDebug() << "rayon = " << rayon;
    qDebug() << "theta = " << theta;
    qDebug() << "sens = " << sens;
/*
    QString string_HEX= QString::number(K, 16);

    QString ZERO = "0";
    for(int i=1 ; i<8-(string_HEX.length()); i++){
        ZERO += "0";
    }

    QString string_K = ZERO + string_HEX;
*/
    QString string_rayon, string_rayon_2;
    QString string_theta, string_theta_2;
    QString string_sens;

    QString total;


    string_rayon= QString::number((rayon&0xFF), 16);
    if(string_rayon.length()      < 2){string_rayon = "0" + string_rayon;}

    string_rayon_2= QString::number(((rayon>>8)&0xFF), 16);
    if(string_rayon_2.length()      < 2){string_rayon_2 = "0" + string_rayon_2;}

    string_theta= QString::number((theta&0xFF), 16);
    if(string_theta.length() < 2){string_theta = "0" + string_theta;}

    string_theta_2= QString::number(((theta>>8)&0xFF), 16);
    if(string_theta_2.length() < 2){string_theta_2 = "0" + string_theta_2;}



        string_sens= QString::number((sens&0xFF), 16);
    if(string_sens.length() < 2){string_sens = "0" + string_sens;}

    total = string_rayon + string_rayon_2 + string_theta + string_theta_2 + string_sens;

    m_ui->textEdit->append("Sending courbure request, ASSERVISSEMENT_COURBURE, X = " + QString::number(rayon, 10)
                           +",  theta en 1/10 de degré = "     + QString::number(theta, 10)
                           +",      Id : 0x021,  Hex : 0x "     + total
                           + "  ...");

    QByteArray writings = dataFromHex(total);

    //qDebug() << "Kp Array= " << writings.toDouble(nullptr);

    QCanBusFrame frame;
    writings.truncate(8);
    frame.setPayload(writings);
    qint32 id = ASSERVISSEMENT_COURBURE; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    //if (m_ui->remoteBox->isChecked())
        //frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    //else
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);


}




void MoteursWindow::on_sendButton_esp32Restart_clicked()
{
    m_ui->textEdit->append("Sending reset request to esp32, ESP32_RESTART, ...");
    QCanBusFrame frame;
    qint32 id = ESP32_RESTART; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);
}



void MoteursWindow::on_sendButton_position_2_clicked()
{
    unsigned short X = m_ui->lineEdit_chgtpos_X->displayText().toShort(nullptr, 10);
    unsigned short Y = m_ui->lineEdit_chgtpos_Y->displayText().toShort(nullptr, 10);
    unsigned short theta = m_ui->lineEdit_chgtpos_theta->displayText().toShort(nullptr, 10) * 10.0;


    qDebug() << "Pos X = " << X;
    qDebug() << "Pos Y = " << Y;
    qDebug() << "theta = " << theta;
/*
    QString string_HEX= QString::number(K, 16);

    QString ZERO = "0";
    for(int i=1 ; i<8-(string_HEX.length()); i++){
        ZERO += "0";
    }

    QString string_K = ZERO + string_HEX;
*/
    QString string_X, string_X_2;
    QString string_Y, string_Y_2;
    QString string_theta, string_theta_2;

    QString total;


        string_X= QString::number((X&0xFF), 16);
    if(string_X.length()      < 2){string_X = "0" + string_X;}

    string_X_2= QString::number(((X>>8)&0xFF), 16);
    if(string_X_2.length()      < 2){string_X_2 = "0" + string_X_2;}


        string_Y= QString::number((Y&0xFF), 16);
    if(string_Y.length() < 2){string_Y = "0" + string_Y;}

    string_Y_2= QString::number(((Y>>8)&0xFF), 16);
    if(string_Y_2.length() < 2){string_Y_2 = "0" + string_Y_2;}



        string_theta= QString::number((theta&0xFF), 16);
    if(string_theta.length() < 2){string_theta = "0" + string_theta;}

    string_theta_2= QString::number(((theta>>8)&0xFF), 16);
    if(string_theta_2.length() < 2){string_theta_2 = "0" + string_theta_2;}



    total = string_X + string_X_2 + string_Y + string_Y_2 + string_theta + string_theta_2;

    m_ui->textEdit->append("Changement position, ODOMETRIE_SMALL_POSITION, X = " + QString::number(X, 10) +
                           "  Y = " + QString::number(Y, 10) +
                           " theta en 1/10 de degré = " + QString::number(theta, 10) +
                           "      Id : 0x0F7 Hex : 0x " + total + "  ...");

    QByteArray writings = dataFromHex(total);

    //qDebug() << "Kp Array= " << writings.toDouble(nullptr);

    QCanBusFrame frame;
    writings.truncate(8);
    frame.setPayload(writings);
    qint32 id = ODOMETRIE_SMALL_POSITION; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    //if (m_ui->remoteBox->isChecked())
        //frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    //else
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);

}



const int AVANCER =10, RECULER = 11, TOURNER_DROITE = 20, TOURNER_GAUCHE = 21, LACHER = 30, SERRER = 31,
                                STEPMOTOR_0 = 40, STEPMOTOR_1 = 41, STEPMOTOR_2 = 42, STEPMOTOR_3 = 43;

int action_algo_gateau[200] = {0};
char nb_Actions = 37;
const int action_creation_gateau_ordre[37]={   AVANCER, STEPMOTOR_0,   LACHER,     STEPMOTOR_1,SERRER,         RECULER, TOURNER_DROITE,
                                            AVANCER, LACHER,        SERRER,     RECULER,    TOURNER_DROITE,                         //STEPMOTOR_1
                                            AVANCER, LACHER,        STEPMOTOR_2,SERRER,     RECULER,        TOURNER_GAUCHE,
                                            AVANCER, LACHER,        SERRER,     RECULER,    TOURNER_GAUCHE,                         //STEPMOTOR_2
                                            AVANCER, LACHER,        STEPMOTOR_3,SERRER,     RECULER,        TOURNER_DROITE,
                                            AVANCER, LACHER,        SERRER,     RECULER,    TOURNER_DROITE,                         //STEPMOTOR_3
                                            AVANCER, LACHER,        RECULER};

const int action_creation_gateau_desordre[76]={   AVANCER, STEPMOTOR_0,   LACHER, STEPMOTOR_3, SERRER,        RECULER, TOURNER_DROITE,
                                                AVANCER, STEPMOTOR_0,   LACHER, STEPMOTOR_3, SERRER,        RECULER, TOURNER_DROITE,                        //STEPMOTOR_1
                                                AVANCER, STEPMOTOR_0,   LACHER, RECULER, TOURNER_GAUCHE, TOURNER_GAUCHE,
                                            AVANCER, SERRER,        STEPMOTOR_3,     RECULER,    TOURNER_DROITE,                         //STEPMOTOR_2
                                            AVANCER, LACHER,        STEPMOTOR_0,SERRER,     STEPMOTOR_3, RECULER,        TOURNER_DROITE,
                                            AVANCER, LACHER,        STEPMOTOR_0,     SERRER,    STEPMOTOR_3, TOURNER_GAUCHE, TOURNER_GAUCHE,

                                                                                            AVANCER, STEPMOTOR_0,   LACHER,     STEPMOTOR_1,SERRER,         RECULER, TOURNER_DROITE,
                                                                                            AVANCER, LACHER,        SERRER,     RECULER,    TOURNER_DROITE,                         //STEPMOTOR_1
                                                                                            AVANCER, LACHER,        STEPMOTOR_2,SERRER,     RECULER,        TOURNER_GAUCHE,
                                                                                            AVANCER, LACHER,        SERRER,     RECULER,    TOURNER_GAUCHE,                         //STEPMOTOR_2
                                                                                            AVANCER, LACHER,        STEPMOTOR_3,SERRER,     RECULER,        TOURNER_DROITE,
                                                                                            AVANCER, LACHER,        SERRER,     RECULER,    TOURNER_DROITE,                         //STEPMOTOR_3
                                                                                            AVANCER, LACHER,        RECULER};

int num_actions = 0, nbMsgCanBASE = 0;
void MoteursWindow::algo_gateau(int IDCAN, int response){

        int IDHerkulex = 103, serrer = 500, lacher = 100, constante = 140;
        /*herkulexControle(IDHerkulex, serrer);
        position_step_motor(75);*/

                switch (etat_algo_gateau)
                {
                case 0:
                {
                    if(ALGO_GATEAU){
                        ALGO_GATEAU = false;
                        etat_algo_gateau = 1;
                        for(int i = 0; i<nb_Actions; i++){
                            action_algo_gateau[i]=0;
                        }
                        nb_Actions = 37;
                        for(int i = 0; i<nb_Actions; i++){
                            action_algo_gateau[i]=action_creation_gateau_ordre[i];
                        }
                    }//*/
                    if(ALGO_GATEAU_DESORDRE){
                        ALGO_GATEAU_DESORDRE = false;
                        etat_algo_gateau = 1;
                        for(int i = 0; i<nb_Actions; i++){
                            action_algo_gateau[i]=0;
                        }
                        nb_Actions = 76;
                        for(int i = 0; i<nb_Actions; i++){
                            action_algo_gateau[i]=action_creation_gateau_desordre[i];
                        }
                    }
                }
                  break;

                case 1:
                {

                    switch (action_algo_gateau[num_actions])
                    {
                    case AVANCER:
                    {
                        etat_algo_gateau = BASE_AVANCER;
                    }
                      break;

                    case RECULER:
                    {
                        etat_algo_gateau = BASE_RECULER;
                    }
                      break;
                    case TOURNER_DROITE:
                    {
                        etat_algo_gateau = BASE_ROTATION_DROITE;
                    }
                      break;
                    case TOURNER_GAUCHE:
                    {
                        etat_algo_gateau = BASE_ROTATION_GAUCHE;

                    }
                      break;
                    case LACHER:
                    {
                        etat_algo_gateau = HERKULEX_LACHER;

                    }
                      break;
                    case SERRER:
                    {
                        etat_algo_gateau = HERKULEX_SERRER;

                    }
                      break;
                    case STEPMOTOR_0:
                    {
                        etat_algo_gateau = STEP_MOTOR_POSITION;
                        position_stepMotor = 0;
                    }
                      break;
                    case STEPMOTOR_1:
                    {
                        etat_algo_gateau = STEP_MOTOR_POSITION;
                        position_stepMotor = 19;
                    }
                      break;
                    case STEPMOTOR_2:
                    {
                        etat_algo_gateau = STEP_MOTOR_POSITION;
                        position_stepMotor = 40;
                    }
                      break;
                    case STEPMOTOR_3:
                    {
                        etat_algo_gateau = STEP_MOTOR_POSITION;
                        position_stepMotor = 62;
                    }
                      break;

                    default:
                      break;
                    }



                    if(num_actions> nb_Actions){etat_algo_gateau = 0; num_actions = 0;}
                    else{num_actions ++;}
                }
                  break;
                case BASE_AVANCER:
                {
                    translation(constante);
                    WAITING_FOR_BASE_TRANSLATION = true;
                    etat_algo_gateau = WAINTING_FOR_RESPONSE;
                }
                  break;
                case BASE_RECULER:
                {
                    translation(-constante);
                    WAITING_FOR_BASE_TRANSLATION = true;
                    etat_algo_gateau = WAINTING_FOR_RESPONSE;
                }
                  break;


                case BASE_ROTATION_DROITE:
                {
                    rotation(45);
                    WAITING_FOR_BASE_ROTATION = true;
                    etat_algo_gateau = WAINTING_FOR_RESPONSE;
                }
                  break;

                case BASE_ROTATION_GAUCHE:
                {
                    rotation(-45);
                    WAITING_FOR_BASE_ROTATION = true;
                    etat_algo_gateau = WAINTING_FOR_RESPONSE;
                }
                  break;


                case STEP_MOTOR_POSITION:
                {
                    position_step_motor(position_stepMotor);
                    WAITING_FOR_STEP_MOTOR = true;
                    etat_algo_gateau = WAINTING_FOR_RESPONSE;
                }
                  break;


                case HERKULEX_SERRER:
                {
                    herkulexControle(IDHerkulex, serrer);
                    WAITING_FOR_HERKULEX = true;
                    etat_algo_gateau = WAINTING_FOR_RESPONSE;
                }
                  break;
                case HERKULEX_LACHER:
                {
                    herkulexControle(IDHerkulex, lacher);
                    WAITING_FOR_HERKULEX = true;
                    etat_algo_gateau = WAINTING_FOR_RESPONSE;
                }
                  break;

                case WAINTING_FOR_RESPONSE:
                {
                    if(WAITING_FOR_HERKULEX){
                        if(IDCAN == INSTRUCTION_END_HERKULEX && response == ID_HERKULEX_POSITION){
                            //alors l'instruction a été faite
                            qDebug() << "INSTRUCTION_END_HERKULEX : " << response;
                            WAITING_FOR_HERKULEX = false;
                            etat_algo_gateau = 1;

                        }
                    }
                    if(WAITING_FOR_BASE_TRANSLATION){
                        if(IDCAN == INSTRUCTION_END_MOTEUR && response == ASSERVISSEMENT_RECALAGE){
                            //alors l'instruction a été faite
                                WAITING_FOR_BASE_TRANSLATION = false;
    //                            etat_algo_gateau = 0;
                                etat_algo_gateau = 1;

                        }
                    }
                    if(WAITING_FOR_BASE_ROTATION){
                        if(IDCAN == INSTRUCTION_END_MOTEUR && response == ASSERVISSEMENT_ROTATION){
                            //alors l'instruction a été faite
                            qDebug() << "WAITING_FOR_BASE_ROTATION, INSTRUCTION_END_MOTEUR : " << response;


                                WAITING_FOR_BASE_ROTATION = false;
    //                            etat_algo_gateau = 0;
                                etat_algo_gateau = 1;


                        }
                    }
                    if(WAITING_FOR_STEP_MOTOR){
                        if(IDCAN == INSTRUCTION_END_STEP_MOTEUR && response == ID_STEP_MOT_POS){
                            //alors l'instruction a été faite
                            qDebug() << "INSTRUCTION_END_STEP_MOTEUR : " << response;
                            WAITING_FOR_STEP_MOTOR = false;
                           // etat_algo_gateau = 0;
                            etat_algo_gateau = 1;
                        }
                    }
                }
                  break;

                default:
                  break;
                }

}
void MoteursWindow::on_sendButton_algo_gateau_clicked()
{
    ALGO_GATEAU = true;
}


void MoteursWindow::translation(unsigned short K)
{
    //double Kdouble = m_ui->lineEdit_rotation->displayText().toDouble(nullptr) * 10.0;
    //int K = Kdouble * 100.000;
    qDebug() << "translation en mm de deg = " << K;
    unsigned short x = (cos(Odo_theta/10.0))*K;//si theta ==
    unsigned short y = (sin(Odo_theta/10.0))*K;
    qDebug() << "x = " << x;
    qDebug() << "y = " << y;
/*
    QString string_HEX= QString::number(K, 16);

    QString ZERO = "0";
    for(int i=1 ; i<8-(string_HEX.length()); i++){
        ZERO += "0";
    }

    QString string_K = ZERO + string_HEX;
*/
    QString string_K;

        string_K= QString::number((K&0xFF), 16);
        if(string_K.length() < 2){string_K = "0" + string_K;}
    QString string_K_2;

        string_K_2= QString::number(((K>>8)&0xFF), 16);
        if(string_K_2.length() < 2){string_K_2 = "0" + string_K_2;}

    QString total = string_K + string_K_2;
    m_ui->textEdit->append("Sending translation request, ASSERVISSEMENT_RECALAGE, distance = " + QString::number(K, 10)
                           + ",     Id : 0x024,  Hex : 0x " + total
                           + "  ...");

    QByteArray writings = dataFromHex(total);

    //qDebug() << "Kp Array= " << writings.toDouble(nullptr);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ASSERVISSEMENT_RECALAGE; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);

}


void MoteursWindow::rotation(unsigned short K){
    //double Kdouble = m_ui->lineEdit_rotation->displayText().toDouble(nullptr) * 10.0;
    //int K = Kdouble * 100.000;
    K = K* 10;
    qDebug() << "rotation en dizieme de deg = " << K;
/*
    QString string_HEX= QString::number(K, 16);

    QString ZERO = "0";
    for(int i=1 ; i<8-(string_HEX.length()); i++){
        ZERO += "0";
    }

    QString string_K = ZERO + string_HEX;
*/
    QString string_K, string_K_2;
        string_K= QString::number((K&0xFF), 16);
         if(string_K.length() < 2){string_K = "0" + string_K;}

        string_K_2 = QString::number(((K>>8)&0xFF), 16);
        if(string_K_2.length() < 2){string_K_2 = "0" + string_K_2;}

    QString total = string_K + string_K_2;

    m_ui->textEdit->append("Sending rotation request, ASSERVISSEMENT_ROTATION, rotation = " + QString::number(K, 10) + "      Id : 0x0F5 Hex : 0x" + total + "  ...");


    QByteArray writings = dataFromHex(total);

    //qDebug() << "Kp Array= " << writings.toDouble(nullptr);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ASSERVISSEMENT_ROTATION; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);

}

void MoteursWindow::position_step_motor(int hauteur){
    unsigned int position = hauteur*3600/80.0;
    unsigned int pos1 = position&0xFF;
    unsigned int pos2 = (position>>8)&0xFF;
    unsigned int pos3 = (position>>16)&0xFF;
    unsigned int pos4 = (position>>24)&0xFF;

    qDebug() << "position= " << position;
    qDebug() << "position&0xFF = " << pos1;
    qDebug() << "(position>>8)&0xFF = " << pos2;


    QString string_pos1 = QString::number(pos1, 16);
    if(string_pos1.length() < 2){string_pos1 = "0" + string_pos1;}

    QString string_pos2 = QString::number(pos2, 16);
    if(string_pos2.length() < 2){string_pos2 = "0" + string_pos2;}

    QString string_pos3 = QString::number(pos3, 16);
    if(string_pos3.length() < 2){string_pos3 = "0" + string_pos3;}

    QString string_pos4 = QString::number(pos4, 16);
    if(string_pos4.length() < 2){string_pos4 = "0" + string_pos4;}

    QString total = string_pos1 + string_pos2 + string_pos3 + string_pos4;
    m_ui->textEdit->append("");
    m_ui->textEdit->append("StepMotor, Position Control" + total
                           + "  ...");

    QByteArray writings = dataFromHex(total);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ID_STEP_MOT_POS; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);


    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);



}



void MoteursWindow::herkulexControle(int ID, int position){
    // 0              1                2           3            4            5           6
   //Contenue DATA : [ID du Herkulex] ; [commande] ; [position] ; [position] ; [playtime] ; [setLed] ;
    int pos1 = position&0xFF;
    int pos2 = (position>>8)&0xFF;
    qDebug() << "ID = " << ID;
    qDebug() << "position= " << position;
    qDebug() << "position&0xFF = " << pos1;
    qDebug() << "(position>>8)&0xFF = " << pos2;


    QString string_HEX= QString::number(ID, 16);
    if(string_HEX.length() < 2){string_HEX = "0" + string_HEX;}

    QString string_pos1 = QString::number(pos1, 16);
    if(string_pos1.length() < 2){string_pos1 = "0" + string_pos1;}

    QString string_pos2 = QString::number(pos2, 16);
    if(string_pos2.length() < 2){string_pos2 = "0" + string_pos2;}

    QString color = "04";


    QString total = string_HEX + "00" + string_pos1 + string_pos2 + "3C" + color;
    m_ui->textEdit->append("");
    m_ui->textEdit->append("Position Control, ID Herkulex = 0x" + string_HEX
                           + "            HEX : 0x" + total
                           + "  ...");



    QByteArray writings = dataFromHex(total);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ID_HERKULEX_POSITION; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);


    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);
}



void MoteursWindow::on_sendButton_score_robot_clicked()
{
    uint16_t score = (m_ui->lineEdit_translation->displayText().toShort(nullptr, 10) & 0xFFFF);

    QString string_K_1;
    QString string_K_2;

        string_K_1= QString::number((score&0xFF), 16);
        if(string_K_1.length() < 2){string_K_1 = "0" + string_K_1;}
        string_K_2= QString::number(((score>>8)&0xFF), 16);
        if(string_K_2.length() < 2){string_K_2 = "0" + string_K_2;}

        QString total = string_K_1 + string_K_2;

        m_ui->textEdit->append("Sending score to robot, IDCAN_SET_SCORE, score = " + QString::number(score, 10) + "      Id : 0x097 Hex : 0x" + total + "  ...");


        QByteArray writings = dataFromHex(total);

        //qDebug() << "Kp Array= " << writings.toDouble(nullptr);

        QCanBusFrame frame;
        writings.truncate(8);

        frame.setPayload(writings);
        qint32 id = IDCAN_SET_SCORE; //m_ui->idEdit->displayText().toInt(nullptr, 16);
        //if (id > 2047) id = 2047;
        frame.setFrameId(id);
        frame.setExtendedFrameFormat(false);
        frame.setFlexibleDataRateFormat(false);
        frame.setBitrateSwitch(false);

        /*if (m_ui->remoteBox->isChecked())
            frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
        else*/
        frame.setFrameType(QCanBusFrame::DataFrame);

        m_manager->send(frame);
}


void MoteursWindow::on_sendButton_algo_gateau_desordre_clicked()
{
    ALGO_GATEAU_DESORDRE = true;
}

void MoteursWindow::on_sendButton_algo_gateau_reset_clicked()
{
    etat_algo_gateau = 0; num_actions = 0;
}



void MoteursWindow::on_pushButton_clicked()
{
    m_ui->textEdit->clear();
}




















void MoteursWindow::on_browse()
{
    QString fileName = QFileDialog::getOpenFileName(this,
        tr("Open cyacd"),
        "/home/yves/Documents/qt5/can/PSoC_Creator/CRAC/Moteurs.cydsn/CortexM3/ARM_GCC_541/Release/Moteurs.cyacd"
        , tr("Cypress Bootloadable Files (*.cyacd)"));
    if (!fileName.isNull()) m_ui->fileName->setText(fileName);
}

void MoteursWindow::showMessage(const char *txt)
{
    m_ui->status->setText(txt);
}

MoteursWindow::~MoteursWindow()
{
    delete m_ui;
}

int MoteursWindow::sendDatas(char *bytes, int size)
{
    if (size <= 8) {
        QByteArray data(bytes, size);
        m_manager->send(ID_BOOTLOAD_READ, data);
        return CYRET_SUCCESS;
    }
    QEventLoop loop;
    QTimer timer;
    timer.setSingleShot(true);
    QByteArray data = CanBusHelper::uint16ToFrame(size);
    connect(this, SIGNAL(rtrReceived()), &loop, SLOT(quit()));
    connect(&timer, SIGNAL(timeout()), &loop, SLOT(quit()));
    int retry = 1;
    while (1) {
        timer.start(1000);
        m_manager->send(ID_BOOTLOAD_READ_MULTI, data);
        loop.exec();
        if (!timer.isActive()) {
            retry--;
            if (retry==0) {
                closeCommunication();
                return CYRET_ERR_UNK;
            }
        } else {
            break;
        }
    }
    data.clear();
    data.append(bytes, size);
    while (data.size() > 0) {
        QByteArray sendData = data.leftJustified(8, '\0', true);
        retry = 2;
        while (1) {
            timer.start(1000);
            m_manager->send(ID_BOOTLOAD_READ_MULTI, sendData);
            loop.exec();
            if (!timer.isActive()) {
                retry--;
                if (retry==0) {
                    closeCommunication();
                    return CYRET_ERR_UNK;
                }
            } else {
                break;
            }
        }
        int n = data.size()-8;
        if (n<=0) data = ""; else data = data.right(n);
    }
    return CYRET_SUCCESS;
}

int MoteursWindow::receiveDatas(char *bytes, int size)
{
    QEventLoop loop;
    QTimer timer;
    timer.setSingleShot(true);
    connect(this, SIGNAL(datasReceived()), &loop, SLOT(quit()));
    connect(&timer, SIGNAL(timeout()), &loop, SLOT(quit()));
    if (!m_receiveDatas.size()) {
        timer.start(1000);
        loop.exec();
        if (!timer.isActive()) {
            closeCommunication();
            return CYRET_ERR_UNK;
        }
    }
    memcpy(bytes, m_receiveDatas.data(), m_receiveDatas.size());
    m_receiveDatas.clear();
    return CYRET_SUCCESS;
}

void MoteursWindow::framesReceived(const QCanBusFrame &frame)
{
    int id = frame.frameId();
    QString idStr = QString("0x%1").arg(id, 3, 16, QLatin1Char('0'));
    if (id == ID_BOOTLOAD_WRITE_MULTI) {
        int size = frame.payload().size();
        if (size == 2) {
            QByteArray data = frame.payload();
            m_size = CanBusHelper::fromFrameToUint16(data);
            m_manager->send(ID_BOOTLOAD_WRITE_MULTI); // rtr
        } else if (size == 8) {
            QByteArray data = frame.payload();
            if (data.size() > m_size) data.truncate(m_size);
            m_receiveDatas += data;
            m_size -= data.size();
            if (m_size == 0) emit datasReceived();
            m_manager->send(ID_BOOTLOAD_WRITE_MULTI); // rtr
        }
    } else if (id == ID_BOOTLOAD_READ_MULTI) {
        if (frame.frameType() == QCanBusFrame::RemoteRequestFrame) {
            emit rtrReceived();
        }
    } else if (id == ID_BOOTLOAD_WRITE) {
        m_receiveDatas = frame.payload();
        emit datasReceived();
        m_manager->send(ID_BOOTLOAD_WRITE);
    } else if (id == ID_BOOTLOAD_READ) {
        if (frame.frameType() == QCanBusFrame::RemoteRequestFrame) {
            emit rtrReceived();
        }
    }
}

int MoteursWindow::openCommunication()
{
    if (!m_manager->isConnected()) return CYRET_ERR_BTLDR;
    recordLink();
    return CYRET_SUCCESS;
}

int MoteursWindow::closeCommunication()
{
    removeLink();
    return CYRET_SUCCESS;
}

extern "C" {

static int openCommunication()
{
    return fenetre->openCommunication();
}

static int closeCommunication()
{
    return fenetre->closeCommunication();
}

static int writeData(unsigned char *bytes, int size)
{
    if (fenetre->sendDatas(reinterpret_cast<char *>(bytes), size)) return CYRET_ERR_UNK;
    return CYRET_SUCCESS;
}

static int readData(unsigned char *bytes, int size)
{
    if (fenetre->receiveDatas(reinterpret_cast<char *>(bytes), size)) return CYRET_ERR_UNK;
    return CYRET_SUCCESS;
}

static CyBtldr_CommunicationsData communication = {
    .OpenConnection = openCommunication,
    .CloseConnection = closeCommunication,
    .ReadData = readData,
    .WriteData = writeData,
    .MaxTransferSize = 64,
};

static void serial_progress_update(unsigned char arrayId, unsigned short rowNum)
{
    char str[100];
    sprintf(str, "Progress: array_id %d, row_num %d\n", arrayId, rowNum);
    fenetre->showMessage(str);
    fenetre->setProgress((100*rowNum)/1023);
}

}

void MoteursWindow::setProgress(int value)
{
    m_ui->progressBar->setValue(value);
}

void MoteursWindow::on_program()
{
    m_ui->progressBar->setValue(0);
    m_ui->progressBar->setVisible(true);
    showMessage("");
    m_manager->send(ID_MOTEURS_RESET, QByteArray()); // reset du PSOC
    QTimer::singleShot(500, this, SLOT(program()));
}

void MoteursWindow::program()
{
    int ret = CyBtldr_RunAction(PROGRAM, m_ui->fileName->text().toStdString().c_str(), NULL, 0, &communication, serial_progress_update);
    if (ret != CYRET_SUCCESS) {
        showMessage("Programming failed");
    } else {
        showMessage("Programming success");
    }
    m_ui->progressBar->setVisible(false);
}













void MoteursWindow::on_pushButton_released()
{
    if(!ENREGISTREMENT_BOUTON){ENREGISTREMENT_BOUTON = true;}
    else{ENREGISTREMENT_BOUTON = false;}
}















void MoteursWindow::on_sendButton_recalage_clicked()
{

}



