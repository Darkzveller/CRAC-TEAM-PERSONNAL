#include "herkulexconfig.h"
#include <QByteArray>

#include "ident_crac.h"
#include "ui_herkulexconfig.h"
#include <QFileDialog>
#include <QTimer>
#include <QDebug>

#include <QCanBus>
#include <QCanBusFrame>
#include <QCloseEvent>
#include <QDesktopServices>
#include <QtDebug>
#include <QTreeView>
#include <QProgressDialog>

static QByteArray dataFromHex(const QString &hex);

HerkulexWindow::HerkulexWindow(CanBusManager *manager, QWidget *parent)
{
    QMainWindow(parent),
    m_ui(new Ui::HerkulexWindow)
{
    m_ui->setupUi(this);
    m_ui->progressBar->hide();

    m_manager = manager;

    fenetre = this;

    connect(m_ui->browse, SIGNAL(clicked()), this, SLOT(on_browse()));
    connect(m_ui->program, SIGNAL(clicked()), this, SLOT(on_program()));

    setAttribute(Qt::WA_QuitOnClose, false);

    //connect(m_manager, &CanBusManager::framesReceived , this, &HerkulexWindow::checkMessages);
    //connect(m_ui->sendButton_Kp,                    &QPushButton::clicked, this, &HerkulexWindow::sendMessageKp);

}

}
