#include <QDataStream>
#include <QDebug>

#include "canbusmanager.h"
#include "canmultiframes.h"

CanBusManager::CanBusManager(QObject *parent) : QObject(parent)
{
    m_multiReader = new CanMultiFramesReader(this);
    m_multiWriter = new CanMultiFramesWriter(this);
}

CanBusManager::~CanBusManager() {
    delete m_multiReader;
    delete m_multiWriter;
    delete m_canDevice;
}

bool CanBusManager::connectDevice(const QString &plugin, const QString &interfaceName)
{
    m_canDevice = QCanBus::instance()->createDevice(plugin, interfaceName, &m_errorString);
    if (!m_canDevice) {
        m_statusString = tr("Error creating device '%1', reason: '%2'").arg(plugin).arg(m_errorString);
        return false;
    }
    connect(m_canDevice, &QCanBusDevice::errorOccurred, this, &CanBusManager::canBusError);
    connect(m_canDevice, &QCanBusDevice::framesReceived, this, &CanBusManager::receive);
    connect(m_canDevice, &QCanBusDevice::framesWritten, this, &CanBusManager::sendFrames);

    m_canDevice->setConfigurationParameter(QCanBusDevice::BitRateKey, m_bitrate);
    m_canDevice->setConfigurationParameter(QCanBusDevice::UserKey, m_serialBaud);

    if (!m_canDevice->connectDevice()) {
        m_errorString = m_canDevice->errorString();
        m_statusString = tr("Connection error: %1").arg(m_errorString);
        delete m_canDevice;
        m_canDevice = nullptr;
        return false;
    } else {
        QVariant bitRate = m_canDevice->configurationParameter(QCanBusDevice::BitRateKey);
        if (bitRate.isValid()) {
            m_statusString = tr("Backend: %1, connected to %2 at %3 kBit/s")
                             .arg(plugin).arg(interfaceName).arg(bitRate.toInt() / 1000);
        } else {
            m_statusString = tr("Backend: %1, connected to %2").arg(plugin).arg(interfaceName);
        }
    }
    return true;
}

void CanBusManager::disconnectDevice()
{
    if (!m_canDevice) return;
    m_canDevice->disconnectDevice();
    delete m_canDevice;
    m_canDevice = nullptr;
    m_statusString = tr("Disconnected");
}

void CanBusManager::writeFrame(const QCanBusFrame &frame)
{
    m_canDevice->writeFrame(frame);
//    int id = frame.frameId();
//    QString idStr = QString("0x%1").arg(id, 3, 16, QLatin1Char('0'));
//    qDebug() << " émis" << idStr << " " << frame.payload().size() << " " << frame.payload();
}

void CanBusManager::send(QCanBusFrame &frame)
{
    if (!m_canDevice) return;
    writeFrame(frame);
}

void CanBusManager::send(quint16 id, QByteArray data)
{
    if (!m_canDevice) return;
    QCanBusFrame frame;
    data.truncate(8);
    frame.setPayload(data);
    frame.setFrameId(id & 0x7FF);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);
    frame.setFrameType(QCanBusFrame::DataFrame);
    writeFrame(frame);
}

void CanBusManager::send(quint16 id, int len) // Remote Request
{
    if (!m_canDevice) return;
    QCanBusFrame frame;
    frame.setPayload(QByteArray(len, '\0'));
    frame.setFrameId(id & 0x7FF);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);
    frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    writeFrame(frame);
}

bool CanBusManager::sendMulti(quint16 id, QByteArray data, const QObject *obj, const char *method, const QByteArray &initData)
{
    if (!m_canDevice) return false;
    disconnect(m_extMultiWriterCnx);
    if ((obj) && (method)) {
        m_extMultiWriterCnx = connect(m_multiWriter, SIGNAL(writeFinished()), obj, method);
    }
    return m_multiWriter->send(id, data, initData);
}

bool CanBusManager::receiveMulti(quint16 id, const QObject *obj, const char *method, bool noLastRemoteRequest)
{
    if (!m_canDevice) return false;
    disconnect(m_extMultiReaderCnx);
    if ((obj) && (method)) {
        m_extMultiReaderCnx = connect(m_multiReader, SIGNAL(readFinished()), obj, method);
    }
    return m_multiReader->receive(id, noLastRemoteRequest);
}
void CanBusManager::canBusError(QCanBusDevice::CanBusError error)
{
    switch (error) {
    case QCanBusDevice::ReadError:
    case QCanBusDevice::WriteError:
    case QCanBusDevice::ConnectionError:
    case QCanBusDevice::ConfigurationError:
    case QCanBusDevice::UnknownError:
        m_errorString =  m_canDevice->errorString();
        break;
    default:
        m_errorString = "Unknown error";
        break;
    }
    emit errorOccurred();
}

void CanBusManager::receive()
{
    if (!m_canDevice) return;
    while (m_canDevice->framesAvailable()) {
        const QCanBusFrame frame = m_canDevice->readFrame();
        if (frame.frameType() == QCanBusFrame::ErrorFrame) {
            m_errorString = m_canDevice->interpretErrorFrame(frame);
        }
//        qDebug() << "Reçu " << frame.frameId() << " " << frame.payload();
        emit framesReceived(frame);
    }
}





