#include "serialbaudbox.h"

#include <QLineEdit>

SerialBaudBox::SerialBaudBox(QWidget *parent) :
    QComboBox(parent),
    m_customSpeedValidator(new QIntValidator(0, 1000000, this))
{
    fillBitRates();

    connect(this, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged),
            this, &SerialBaudBox::checkCustomSpeedPolicy);
}

SerialBaudBox::~SerialBaudBox()
{
    delete m_customSpeedValidator;
}

int SerialBaudBox::bitRate() const
{
    if (currentIndex() == (count() - 1))
        return currentText().toInt();

    return itemData(currentIndex()).toInt();
}

void SerialBaudBox::checkCustomSpeedPolicy(int idx)
{
    const bool isCustomSpeed = !itemData(idx).isValid();
    setEditable(isCustomSpeed);
    if (isCustomSpeed) {
        clearEditText();
        lineEdit()->setValidator(m_customSpeedValidator);
    }
}

void SerialBaudBox::fillBitRates()
{
    const QList<int> rates = {
        9600, 19200, 28800, 38400, 57600, 76800, 115200, 230400, 460800, 576000, 921600
    };

    clear();

    for (int rate : rates)
        addItem(QString::number(rate), rate);

    addItem(tr("Custom"));
    setCurrentIndex(10); // default is 1000000 bits/sec
}
