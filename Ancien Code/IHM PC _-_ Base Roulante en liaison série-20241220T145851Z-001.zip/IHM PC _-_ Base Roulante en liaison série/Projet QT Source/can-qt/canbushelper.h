#ifndef CANBUSHELPER_H
#define CANBUSHELPER_H

#include <QCanBus>
#include <QCanBusDevice>
#include <QVariant>
#include <QCanBusFrame>
#include <QDataStream>

enum CanBusStatus {
    CANBUS_STATUS_NO_ERROR = 0,
    CANBUS_STATUS_WAIT_REQUEST = 1,
    CANBUS_STATUS_PROCESS_REQUEST = 2,
    CANBUS_STATUS_TIMEOUT = 16,
    CANBUS_STATUS_CANCELLED = 32,
    CANBUS_STATUS_ERROR_READ = 64
};

class CanBusHelper
{
public:
    CanBusHelper();

    static QByteArray uint16ToFrame(quint16);
    static quint16 fromFrameToUint16(QByteArray &data);
    static QByteArray uint24ToFrame(quint32);
    static quint32 fromFrameToUint24(QByteArray &data);
    static QByteArray uint32ToFrame(quint32);
    static quint32 fromFrameToUint32(QByteArray &data);
    static QByteArray floatToFrame(float);
    static float fromFrameToFloat(QByteArray &data);
    static QByteArray doubleToFrame(double);
    static double fromFrameToDouble(QByteArray &data);
};

#endif // CANBUSHELPER_H
