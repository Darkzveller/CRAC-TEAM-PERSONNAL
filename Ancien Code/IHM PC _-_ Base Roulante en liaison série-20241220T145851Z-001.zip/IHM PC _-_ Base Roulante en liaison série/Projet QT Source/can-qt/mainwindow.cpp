/****************************************************************************
**
** Copyright (C) 2017 The Qt Company Ltd.
** Contact: http://www.qt.io/licensing/
**
** This file is part of the examples of the QtSerialBus module.
**
** $QT_BEGIN_LICENSE:BSD$
** You may use this file under the terms of the BSD license as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of The Qt Company Ltd nor the names of its
**     contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
** $QT_END_LICENSE$
**
****************************************************************************/

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "connectdialog.h"

#include <QCanBus>
#include <QCanBusFrame>
#include <QCloseEvent>
#include <QDesktopServices>
#include <QtDebug>
#include <QTimer>
#include <QTreeView>
#include <QProgressDialog>
#include "remoteFileSystem.h"
#include <QDebug>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    m_ui(new Ui::MainWindow)
{
    m_ui->setupUi(this);

    m_connectDialog = new ConnectDialog(this);

    m_manager = new CanBusManager;

    m_remoteFsUi = new RemoteFsUi(m_manager, this);
    m_remoteFsUi->hide();

    m_moteursUi = new MoteursWindow(m_manager, this);
    m_moteursUi->hide();

    m_herkulexUi = new herkulex(m_manager, this);
    m_herkulexUi->hide();

    m_strategieUi = new Strategie(m_manager, this);
    m_strategieUi->hide();

    m_lidarUi = new Lidar(m_manager, this);
    m_lidarUi->hide();

    m_btConfigUI = new BtConfig(m_manager);
    m_btConfigUI->hide();

    m_status = new QLabel;
    m_ui->statusBar->addWidget(m_status);

    m_ui->sendMessagesBox->setEnabled(false);

    initActionsConnections();
}

MainWindow::~MainWindow()
{
    delete m_manager;
    delete m_connectDialog;
    delete m_moteursUi;
    delete m_remoteFsUi;
    delete m_btConfigUI;
    delete m_herkulexUi;
    delete m_strategieUi;
    delete m_lidarUi;
    delete m_ui;
}

void MainWindow::showStatusMessage(const QString &message)
{
    m_status->setText(message);
}

void MainWindow::initActionsConnections()
{
    m_ui->actionConnect->setEnabled(true);
    m_ui->actionDisconnect->setEnabled(false);
    m_ui->actionQuit->setEnabled(true);

    connect(m_ui->actionConnect, &QAction::triggered, m_connectDialog, &ConnectDialog::show);
    connect(m_connectDialog, &QDialog::accepted, this, &MainWindow::connectDevice);
    connect(m_ui->actionDisconnect, &QAction::triggered, this, &MainWindow::disconnectDevice);
    connect(m_ui->actionQuit, &QAction::triggered, this, &QWidget::close);
    connect(m_ui->actionAboutQt, &QAction::triggered, qApp, &QApplication::aboutQt);
    connect(m_ui->actionClearLog, &QAction::triggered, m_ui->receivedMessagesEdit, &QTextEdit::clear);
    connect(m_ui->actionPluginDocumentation, &QAction::triggered, this, []() {
        QDesktopServices::openUrl(QUrl("http://doc.qt.io/qt-5/qtcanbus-backends.html#can-bus-plugins"));
    });

    connect(m_manager, &CanBusManager::errorOccurred, this, &MainWindow::receiveError);
    connect(m_manager, &CanBusManager::framesReceived, this, &MainWindow::checkMessages);
    connect(m_manager, &CanBusManager::framesWritten, this, &MainWindow::framesWritten);
    QTimer::singleShot(50, m_connectDialog, &ConnectDialog::exec);
    connect(m_ui->sendButton, &QPushButton::clicked, this, &MainWindow::sendMessage);
}

void MainWindow::receiveError() const
{
    qWarning() << m_manager->getErrorString();
}

void MainWindow::connectDevice()
{
    nombreTramesRecues = 0;
    m_ui->nombre->setText(QString::number(nombreTramesRecues));
    const ConnectDialog::Settings p = m_connectDialog->settings();

    for (const ConnectDialog::ConfigurationItem &item : p.configurations) {
        if (item.first == QCanBusDevice::BitRateKey) m_manager->setBitrate(item.second.toInt());
        if (item.first == QCanBusDevice::UserKey) m_manager->setSerialBaud(item.second.toInt());
    }

    bool connect = m_manager->connectDevice(p.backendName, p.deviceInterfaceName);
    if (connect) {
        m_ui->actionConnect->setEnabled(false);
        m_ui->actionDisconnect->setEnabled(true);
        m_ui->sendMessagesBox->setEnabled(true);

    }
    showStatusMessage(m_manager->getStatusString());
}

void MainWindow::disconnectDevice()
{
    m_manager->disconnectDevice();
    m_ui->actionConnect->setEnabled(true);
    m_ui->actionDisconnect->setEnabled(false);
    m_ui->sendMessagesBox->setEnabled(false);
    showStatusMessage(m_manager->getStatusString());
}

void MainWindow::framesWritten(qint64 count)
{
    Q_UNUSED(count)
//    qDebug() << "Number of frames written:" << count;
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    m_connectDialog->close();
    event->accept();
}

static QString frameFlags(const QCanBusFrame &frame)
{
    if (frame.hasBitrateSwitch() && frame.hasErrorStateIndicator())
        return QStringLiteral(" B E ");
    if (frame.hasBitrateSwitch())
        return QStringLiteral(" B - ");
    if (frame.hasErrorStateIndicator())
        return QStringLiteral(" - E ");
    return QStringLiteral(" - - ");
}

void MainWindow::checkMessages(const QCanBusFrame &frame)
{
    QString view;
    if (frame.frameType() == QCanBusFrame::ErrorFrame) {
        view = m_manager->getErrorString();
    } else {
        view = frame.toString();
    }
    const QString time = QString::fromLatin1("%1.%2  ")
            .arg(frame.timeStamp().seconds(), 10, 10, QLatin1Char(' '))
            .arg(frame.timeStamp().microSeconds() / 100, 4, 10, QLatin1Char('0'));

    const QString flags = frameFlags(frame);


    m_ui->receivedMessagesEdit->append(time + flags + view);




    nombreTramesRecues++;
    m_ui->nombre->setText(QString::number(nombreTramesRecues));
}

static QByteArray dataFromHex(const QString &hex)
{
    QByteArray line = hex.toLatin1();
    line.replace(' ', QByteArray());
    return QByteArray::fromHex(line);
}

void MainWindow::sendMessage() const
{
    QByteArray writings = dataFromHex(m_ui->lineEdit->displayText());

    QCanBusFrame frame;
    writings.truncate(8);
    frame.setPayload(writings);
    qint32 id = m_ui->idEdit->displayText().toInt(nullptr, 16);
    if (id > 2047) id = 2047;

    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else
        frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);
}

void MainWindow::on_actionRemoteSDCard_triggered()
{
    m_remoteFsUi->show();
    m_remoteFsUi->activateWindow();
}

void MainWindow::on_actionMotorsControl_triggered()
{
    m_moteursUi->show();
    m_moteursUi->activateWindow();
}

void MainWindow::on_actionConfig_Bluetooth_triggered()
{
    m_btConfigUI->show();
    m_btConfigUI->activateWindow();
}

void MainWindow::on_actionHerkulexConfig_triggered()
{
    m_herkulexUi->show();
    m_herkulexUi->activateWindow();
}

void MainWindow::on_actionStrategie_triggered()
{
    m_strategieUi->show();
    m_strategieUi->activateWindow();
}


void MainWindow::on_actionPosition_triggered()
{
    m_positionXYTConfigUI->show();
    m_positionXYTConfigUI->activateWindow();
}


void MainWindow::on_actionLidar_triggered()
{
    m_lidarUi->show();
    m_lidarUi->activateWindow();
}


void MainWindow::on_sendButton_clicked()
{

}


