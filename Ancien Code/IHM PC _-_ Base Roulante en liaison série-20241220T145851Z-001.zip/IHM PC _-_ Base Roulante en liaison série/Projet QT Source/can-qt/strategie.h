#ifndef STRATEGIE_H
#define STRATEGIE_H

#include <QMainWindow>
#include "canbusmanager.h"

#include <QFileDialog>
#include <QTimer>
#include <QDebug>

#include <QCanBus>
#include <QCanBusFrame>
#include <QCloseEvent>
#include <QDesktopServices>
#include <QtDebug>
#include <QTreeView>
#include <QProgressDialog>
#include <QGraphicsScene>
#include <QGraphicsView>

#include <QTimer>

#include <QGraphicsPixmapItem>
#include <QSGRendererInterface>
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include <QPixmap>
#include <QTransform>
#include <QWidget>
#include <QPointF>
#include <cmath>

#include <QCursor>

#include "QGraphicsProxyWidget"
namespace Ui {
class Strategie;
}

class Strategie : public QMainWindow
{
    Q_OBJECT

public:
    explicit Strategie(CanBusManager *manager, QWidget *parent = nullptr);
    ~Strategie();
    void showMessage(const char *txt);
    int sendDatas(char *bytes, int size);
    int receiveDatas(char *bytes, int size);
    int openCommunication();
    int closeCommunication();
    void setProgress(int value);

private:
    Ui::Strategie *m_ui;
    CanBusManager *m_manager;
    int m_size;
    short Odo_x;
    short Odo_y;
    short Odo_theta;
    QGraphicsView* my_graphics_view;
    QGraphicsPixmapItem* my_pixmap;
    QGraphicsScene *scene;
    QGraphicsProxyWidget *w;
    QPoint cursor_position;
    Qt::MouseButtons cursor_buttons;
    QTimer *timer;

    QMetaObject::Connection m_connect;
    QByteArray m_receiveDatas;
    void recordLink() {
        disconnect(m_connect);
        m_connect = connect(m_manager, SIGNAL(framesReceived(const QCanBusFrame &)), this, SLOT(framesReceived(const QCanBusFrame &)));
    }
    void removeLink() { disconnect(m_connect); }
    static const int ID_BOOTLOAD_WRITE_MULTI, ID_BOOTLOAD_READ_MULTI, ID_BOOTLOAD_WRITE, ID_BOOTLOAD_READ, ID_MOTEURS_RESET;

private slots:
    void on_browse();
    void on_program();
    void framesReceived(const QCanBusFrame &frame);
    void program();
    void followXYcursor();
    void checkMessages(const QCanBusFrame &frame);
    void positionRobot(short x, short y, short theta);
    void monTimer();
    void courbeBezier(int x1, int y1, int x2, int y2);


    //void sendMessageCoupleActiver() const;

    void on_case0_clicked();

    void on_case3_3_clicked();

    void on_case3_2_clicked();

    void on_case3_clicked();

    void on_case1_clicked();

    void on_case2_clicked();

    void on_case4_clicked();

    void on_case5_clicked();

    void on_case6_clicked();

    void on_case7_clicked();

    void on_case8_clicked();

    void on_case9_clicked();

signals:
    void rtrReceived();
    void datasReceived();
};

#endif // Strategie_H
