#ifndef CANMULTIFRAMES_H
#define CANMULTIFRAMES_H

#include <QObject>
#include <QTimer>
#include <QCanBusFrame>

#include "canbushelper.h"


class CanBusManager;

class CanMultiFramesWriter : public QObject
{
    Q_OBJECT
public:
    explicit CanMultiFramesWriter(CanBusManager *manager);
    int status() { return m_status; }
    bool send(quint16 id, const QByteArray &data, const QByteArray &initData = QByteArray());
private:
    CanBusManager *m_manager;
    int m_status = CanBusStatus::CANBUS_STATUS_WAIT_REQUEST;
    quint16 m_id;
    QByteArray m_data;
    QTimer *m_timer;
    int m_dataSize;
    void endStatus(CanBusStatus status = CanBusStatus::CANBUS_STATUS_NO_ERROR);
private slots:
    void framesReceived(const QCanBusFrame &frame);
    void timeout();
signals:
    void writeFinished();
    void progressValue(int);
};

class CanMultiFramesReader : public QObject
{
    Q_OBJECT
public:
    explicit CanMultiFramesReader(CanBusManager *manager);
    int status() { return m_status; }
    bool receive(quint16 id, bool noLastRemoteRequest = false);
    QByteArray &getReply() { return m_data; }
    int getExtraError() { return m_error; }
    int getExtraTotalSize() { return m_totalSize; }
private:
    CanBusManager *m_manager;
    int m_status = CanBusStatus::CANBUS_STATUS_WAIT_REQUEST;
    quint16 m_id;
    QByteArray m_data;
    QTimer *m_timer;
    int m_dataSize;
    int m_totalSize;
    int m_error = 0;
    bool m_noLastRemoteRequest;
    void endStatus(CanBusStatus status = CanBusStatus::CANBUS_STATUS_NO_ERROR);
private slots:
    void framesReceived(const QCanBusFrame &frame);
    void timeout();
signals:
    void readFinished();
    void progressValue(int);
};

#endif // CANMULTIFRAMES_H
