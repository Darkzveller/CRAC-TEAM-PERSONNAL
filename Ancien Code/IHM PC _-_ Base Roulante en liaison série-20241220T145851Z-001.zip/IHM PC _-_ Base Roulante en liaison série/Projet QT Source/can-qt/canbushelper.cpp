#include "canbushelper.h"

CanBusHelper::CanBusHelper()
{

}

QByteArray CanBusHelper::uint16ToFrame(quint16 i)
{
    QByteArray data;
    QDataStream stream(&data, QIODeviceBase::Append);
    stream.setByteOrder(QDataStream::LittleEndian);
    stream << i;
    return data;
}

quint16 CanBusHelper::fromFrameToUint16(QByteArray &data)
{
    quint16 i;
    QDataStream stream(data);
    stream.setByteOrder(QDataStream::LittleEndian);
    stream >> i;
    data.remove(0,2);
    return i;
}

QByteArray CanBusHelper::uint24ToFrame(quint32 i)
{
    QByteArray data;
    QDataStream stream(&data, QIODeviceBase::Append);
    stream.setByteOrder(QDataStream::LittleEndian);
    stream << i;
    data.truncate(3);
    return data;
}

quint32 CanBusHelper::fromFrameToUint24(QByteArray &data)
{
    quint32 i;
    data.insert(3, '\0');
    QDataStream stream(data);
    stream.setByteOrder(QDataStream::LittleEndian);
    stream >> i;
    data.remove(0,4);
    return i;
}

QByteArray CanBusHelper::uint32ToFrame(quint32 i)
{
    QByteArray data;
    QDataStream stream(&data, QIODeviceBase::Append);
    stream.setByteOrder(QDataStream::LittleEndian);
    stream << i;
    return data;
}

quint32 CanBusHelper::fromFrameToUint32(QByteArray &data)
{
    quint32 i;
    QDataStream stream(data);
    stream.setByteOrder(QDataStream::LittleEndian);
    stream >> i;
    data.remove(0,4);
    return i;
}

QByteArray CanBusHelper::floatToFrame(float i)
{
    QByteArray data;
    QDataStream stream(&data, QIODeviceBase::Append);
    stream.setByteOrder(QDataStream::LittleEndian);
    stream.setFloatingPointPrecision(QDataStream::SinglePrecision);
    stream << i;
    return data;
}

float CanBusHelper::fromFrameToFloat(QByteArray &data)
{
    float i;
    QDataStream stream(data);
    stream.setByteOrder(QDataStream::LittleEndian);
    stream.setFloatingPointPrecision(QDataStream::SinglePrecision);
    stream >> i;
    data.remove(0,4);
    return i;
}

QByteArray CanBusHelper::doubleToFrame(double i)
{
    QByteArray data;
    QDataStream stream(&data, QIODeviceBase::Append);
    stream.setByteOrder(QDataStream::LittleEndian);
    stream.setFloatingPointPrecision(QDataStream::DoublePrecision);
    stream << i;
    return data;
}

double CanBusHelper::fromFrameToDouble(QByteArray &data)
{
    double i;
    QDataStream stream(data);
    stream.setByteOrder(QDataStream::LittleEndian);
    stream.setFloatingPointPrecision(QDataStream::DoublePrecision);
    stream >> i;
    data.remove(0,8);
    return i;
}

