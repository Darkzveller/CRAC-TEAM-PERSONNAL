#include "position.h"
#include "ui_position.h"

position::position(CanBusManager *manager, QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::position)
{
    ui->setupUi(this);
}

position::~position()
{
    delete ui;
}
