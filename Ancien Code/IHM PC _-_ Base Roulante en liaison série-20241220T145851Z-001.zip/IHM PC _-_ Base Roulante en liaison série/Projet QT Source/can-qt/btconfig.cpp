#include "btconfig.h"
#include <QQmlContext>
#include <QMessageBox>
#include <QQmlApplicationEngine>
#include <QQmlComponent>
#include <QByteArray>

BtConfig::BtConfig(CanBusManager *manager) : m_manager(manager)
{
    rootContext()->setContextProperty("btConfig", this);
    setSource(QUrl("qrc:///btConfig.qml"));
    setWindowTitle("Bluetooth configuration");
    setAttribute(Qt::WA_QuitOnClose, false);
}

void BtConfig::envoyer(QString dataStart, QString dataEnd, QString cstInclu)
{
    bool ok;
    int32_t dStart, dStartMSB, dStartLSB;
    int32_t dEnd, dEndMSB, dEndLSB;
    quint16 intID2;
    /*qDebug() << dataStart.toInt(&ok,16);
    qDebug() << ok;
    qDebug() << dataEnd.toInt(&ok,16);
    qDebug() << ok;
    qDebug() << cstID.toInt(&ok,16);
    qDebug() << ok;*/
    QMessageBox::information(this,dataStart, dataEnd, cstInclu, "Message envoyé");

    dStart=dataStart.toInt(&ok, 16);    // conversion en int
    dStartMSB=dStart / 256;  // récupération du MSB de la donnée de début
    dStartLSB= dStart & 0xFF;  // récupération du LSB de la donnée de début

    dEnd=dataEnd.toInt(&ok, 16);    // conversion en int
    dEndMSB=dEnd / 256;  // récupération du MSB de la donnée de fin
    dEndLSB= dEnd & 0xFF;  // récupération du LSB de la donnée de fin

    intID2=cstInclu.toInt(&ok, 16); // donnée d'instruction 0x00, 0x01 ...



    QByteArray data;
    data.append(intID2);  // construction de la trame de donnée
    data.append(dStartLSB);
    data.append(dStartMSB);
    data.append(dEndLSB);
    data.append(dEndMSB);

    // conversion du l'id en char

    qDebug() << data;
    qDebug() << intID2;

    // pour envoyer une trame can, utiliser la ligne ci-dessous avec l'id et data qui est QByteArray
  m_manager->send(/*id config*/ 0x7E4, /*data*/ data);

}
