#ifndef REMOTEFILESYSTEM_H
#define REMOTEFILESYSTEM_H

#include <QString>
#include <QVector>
#include <QAbstractItemModel>
#include <QFile>

#include "canbusmanager.h"
#include "fichiers.h"

class TreeModel : public QAbstractItemModel
{
    Q_OBJECT

public:
    explicit TreeModel(CanBusManager *manager, QObject *parent = nullptr);
    ~TreeModel();

    virtual QVariant data(const QModelIndex &index, int role) const override;
    virtual bool setData(const QModelIndex &index, const QVariant &value, int role = Qt::EditRole) override;
    virtual Qt::ItemFlags flags(const QModelIndex &index) const override;
    virtual QVariant headerData(int section, Qt::Orientation orientation,
                        int role = Qt::DisplayRole) const override;
    virtual QModelIndex index(int row, int column,
                             const QModelIndex &parent = QModelIndex()) const override;
    virtual QModelIndex parent(const QModelIndex &index) const override;
    virtual int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    virtual int columnCount(const QModelIndex &parent = QModelIndex()) const override;
    int insertDir(const QModelIndex &parent = QModelIndex());
    int insertFile(const QModelIndex &parent = QModelIndex());
    bool remove(const QModelIndex &index);
    bool upload(const QString &sourceFilename, QString &destFilename, bool forceIfExist, QString &altNameIfExist);
    bool copy(const QString &sourceFilename, QString &destFilename, bool forceIfExist, QString &altNameIfExist);
    bool download(const QString &source, const QString &filename);
    Dossier *root() { return m_rootItem; }
    QModelIndex getPathModelIndex(const QString &path);
    virtual QStringList mimeTypes() const override;
    virtual QMimeData *mimeData(const QModelIndexList &indexes) const override;
    virtual bool dropMimeData(const QMimeData *data, Qt::DropAction action, int row, int column, const QModelIndex &parent) override;
    virtual bool canDropMimeData(const QMimeData *data, Qt::DropAction action, int row, int column, const QModelIndex &parent) const override;
public slots:
    void updateModel();
    void updateModel(Dossier *d);
private slots:
    void updateModelContinue();
    void mkdirGetReply();
    void mkfileGetReply();
    void renameGetReply();
    void removeGetReply();
    void uploadDatas();
    void uploadGetReply();
    void downloadDatas();
    void copyGetReply();
private:
    enum SD_CMD {
                 CMD_LS=1,
                 CMD_CDROOT=2,
                 CMD_CD_NUM=4,
                 CMD_MKDIR=6,
                 CMD_DEL_NAME=7,
                 CMD_RENAME=8,
                 CMD_MKFILE=9,
                 CMD_UPLOAD_EXIST=10,
                 CMD_UPLOAD_CREATE=11,
                 CMD_DOWNLOAD=12,
                 CMD_COPY_EXIST=13,
                 CMD_COPY_CREATE=14
    };
    const quint16 CAN_SD_CMD = 0x3F0;
    const uint32_t PACKET_SIZE = 1024;

    Dossier *m_rootItem;
    Fichier *m_currentItem;
    CanBusManager *m_manager;
    QVector<int> m_listeChemin;
    QFile m_uploadFile, m_downloadFile;
    qint64 m_sizeFile;
    qint64 m_transferred;
    Dossier *findUnFilled(Dossier *d);
    void startRemoteMkdir(const QString &chemin);
    void startRemoteMkfile(const QString &chemin);
    void startRemoteRename(const QString &src, const QString &dest);
    void startRemoteRemove(const QString &chemin);
    void startRemoteUploadExistFile(const QString &filename, const QString &dest);
    void startRemoteUploadCreateFile(const QString &filename, const QString &dest);
    void startRemoteCopyExistFile(const QString &filename, const QString &dest);
    void startRemoteCopyCreateFile(const QString &filename, const QString &dest);
    void sort(int column, Qt::SortOrder order = Qt::AscendingOrder) override;

signals:
    void modelUpdated(bool);
    void progressValue(int);
    void uploadFinished(bool);
    void downloadFinished(bool);
    void selectUploadName(const QModelIndex & parent, const QString &filename);
    void selectCopyName(const QModelIndex & parent, const QString &filename);
};

#endif // REMOTEFILESYSTEM_H
