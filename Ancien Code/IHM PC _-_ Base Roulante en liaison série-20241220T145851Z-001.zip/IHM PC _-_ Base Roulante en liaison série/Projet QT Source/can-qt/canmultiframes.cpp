#include <QDataStream>
#include <QDebug>

#include "canmultiframes.h"
#include "canbusmanager.h"

CanMultiFramesWriter::CanMultiFramesWriter(CanBusManager *manager) : m_manager(manager)
{
    m_timer = new QTimer(this);
    m_timer->setSingleShot(true);
    connect(m_timer, &QTimer::timeout, this, &CanMultiFramesWriter::timeout);
}

bool CanMultiFramesWriter::send(quint16 id, const QByteArray &data, const QByteArray &initData)
{
    if (!(m_status & CanBusStatus::CANBUS_STATUS_WAIT_REQUEST)) return false;
    m_status = CanBusStatus::CANBUS_STATUS_PROCESS_REQUEST;
    m_data = data;
    m_id = id;
    m_dataSize = m_data.size();
    connect(m_manager, &CanBusManager::framesReceived, this, &CanMultiFramesWriter::framesReceived);
    m_manager->send(m_id, CanBusHelper::uint32ToFrame(m_dataSize) + initData);
    m_timer->start(1000);
    if (m_dataSize == 0) m_dataSize = 1;
    emit progressValue(0);
    return true;
}

void CanMultiFramesWriter::framesReceived(const QCanBusFrame &frame)
{
    if (!(m_status & CanBusStatus::CANBUS_STATUS_PROCESS_REQUEST)) return;
    if (frame.frameId() != m_id) return;
    m_timer->start(1000);
    if (frame.frameType() == QCanBusFrame::RemoteRequestFrame) {
        if (m_data.size()>0) {
            if (m_data.size()<8) m_manager->send(m_id, m_data.leftJustified(8,0));
            else m_manager->send(m_id, m_data.left(8));
            m_data.remove(0, 8);
            emit progressValue((100*m_data.size())/m_dataSize);
        } else {
            endStatus();
        }
    } else {
        endStatus(CanBusStatus::CANBUS_STATUS_CANCELLED);
    }
}

void CanMultiFramesWriter::timeout()
{
    endStatus(CanBusStatus::CANBUS_STATUS_TIMEOUT);
}

void CanMultiFramesWriter::endStatus(CanBusStatus status)
{
    disconnect(m_manager, &CanBusManager::framesReceived, this, &CanMultiFramesWriter::framesReceived);
    m_timer->stop();
    m_status = CanBusStatus::CANBUS_STATUS_WAIT_REQUEST | status;
    emit progressValue(100);
    emit writeFinished();
}

CanMultiFramesReader::CanMultiFramesReader(CanBusManager *manager) : m_manager(manager)
{
    m_timer = new QTimer(this);
    m_timer->setSingleShot(true);
    connect(m_timer, &QTimer::timeout, this, &CanMultiFramesReader::timeout);
}

bool CanMultiFramesReader::receive(quint16 id, bool noLastRemoteRequest)
{
    if (!(m_status & CanBusStatus::CANBUS_STATUS_WAIT_REQUEST)) return false;
    m_status = CanBusStatus::CANBUS_STATUS_PROCESS_REQUEST;
    m_data.clear();
    m_id = id;
    m_dataSize = 0;
    connect(m_manager, &CanBusManager::framesReceived, this, &CanMultiFramesReader::framesReceived);
    m_timer->start(1000);
    m_noLastRemoteRequest = noLastRemoteRequest;
    emit progressValue(0);
    return true;
}

void CanMultiFramesReader::framesReceived(const QCanBusFrame &frame)
{
    if (!(m_status & CanBusStatus::CANBUS_STATUS_PROCESS_REQUEST)) return;
    if (frame.frameId() != m_id) return;
    m_timer->start(1000);
    if (frame.frameType() == QCanBusFrame::DataFrame) {
        if (m_dataSize == 0) {
            int size = frame.payload().size();
            if ((size == 4)||(size==6)) {
                QByteArray data = frame.payload();
                m_dataSize = CanBusHelper::fromFrameToUint32(data);
                m_error = (size==6) ? CanBusHelper::fromFrameToUint16(data) : 0;
                m_manager->send(m_id);
            } else if (size==7) {
                QByteArray data = frame.payload();
                m_dataSize = CanBusHelper::fromFrameToUint32(data);
                m_totalSize = CanBusHelper::fromFrameToUint24(data);
                m_error = 0;
                m_manager->send(m_id);
            } else {
                endStatus(CanBusStatus::CANBUS_STATUS_ERROR_READ);
                return;
            }
        } else {
            m_data += frame.payload();
            m_data.truncate(m_dataSize);
            if ((!m_noLastRemoteRequest)||(m_data.size() != m_dataSize)) {
                m_manager->send(m_id);
            }
            emit progressValue((100*m_data.size())/m_dataSize);
        }
        if (m_data.size() == m_dataSize) {
            endStatus();
        }
    } else {
        endStatus(CanBusStatus::CANBUS_STATUS_CANCELLED);
    }
}

void CanMultiFramesReader::timeout()
{
    endStatus(CanBusStatus::CANBUS_STATUS_TIMEOUT);
}

void CanMultiFramesReader::endStatus(CanBusStatus status)
{
    disconnect(m_manager, &CanBusManager::framesReceived, this, &CanMultiFramesReader::framesReceived);
    m_timer->stop();
    m_status = CanBusStatus::CANBUS_STATUS_WAIT_REQUEST | status;
    emit progressValue(100);
    emit readFinished();
}
