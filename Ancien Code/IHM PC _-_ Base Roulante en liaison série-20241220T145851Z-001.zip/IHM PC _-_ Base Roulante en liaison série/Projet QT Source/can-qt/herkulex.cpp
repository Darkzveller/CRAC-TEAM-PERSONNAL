#include "herkulex.h"
#include "ui_herkulex.h"

#include "ident_crac.h"


extern "C" {
#include "cybootloaderutils/cybtldr_api.h"
#include "cybootloaderutils/cybtldr_api2.h"
}


static herkulex *fenetre = nullptr;

const int herkulex::ID_BOOTLOAD_WRITE_MULTI = 0x400;
const int herkulex::ID_BOOTLOAD_READ_MULTI = 0x401;
const int herkulex::ID_BOOTLOAD_WRITE = 0x402;
const int herkulex::ID_BOOTLOAD_READ = 0x403;
const int herkulex::ID_MOTEURS_RESET = 0x780;

bool WAIT_ACK_HERKULEX_POSITION = false;
bool WAIT_ACK_HERKULEX_CHANGE_ID = false;
bool WAIT_ACK_HERKULEX_STAT = false;
bool WAIT_ACK_HERKULEX_SERIAL_BAUDRATE = false;


static QByteArray dataFromHex(const QString &hex);

herkulex::herkulex(CanBusManager *manager, QWidget *parent) :
    QMainWindow(parent),
    m_ui(new Ui::herkulex)
{
    m_ui->setupUi(this);

    m_manager = manager;

    fenetre = this;

    connect(m_manager, &CanBusManager::framesReceived , this, &herkulex::checkMessages);

    connect(m_ui->sendButton_couple_activer, &QPushButton::clicked, this, &herkulex::sendMessageCoupleActiver);
    connect(m_ui->sendButton_couple_desactiver, &QPushButton::clicked, this, &herkulex::sendMessageCoupleDesactiver);

    connect(m_ui->sendButton_clear, &QPushButton::clicked, this, &herkulex::sendMessageClear);

    connect(m_ui->sendButton_controle, &QPushButton::clicked, this, &herkulex::sendMessagePosition);
    connect(m_ui->sendButton_controle_simultane, &QPushButton::clicked, this, &herkulex::sendMessageSimultane);
    connect(m_ui->sendButton_requete_id, &QPushButton::clicked, this, &herkulex::sendMessageRequete);
    connect(m_ui->sendButton_change_id, &QPushButton::clicked, this, &herkulex::sendMessageChangeID);
    connect(m_ui->sendButton_STAT, &QPushButton::clicked, this, &herkulex::sendMessageSTAT);
    connect(m_ui->sendButton_baudrate, &QPushButton::clicked, this, &herkulex::sendMessageSerialBaudRate);
    connect(m_ui->sendButton_baudrate_herkulex, &QPushButton::clicked, this, &herkulex::sendMessageHerkulexBaudRate);

    connect(m_ui->sendButton_pince_attraper, &QPushButton::clicked, this, &herkulex::sendMessagePinceAttraper);
    connect(m_ui->sendButton_pince_lacher, &QPushButton::clicked, this, &herkulex::sendMessagePinceLacher);
    connect(m_ui->sendButton_pince_idHerkulex, &QPushButton::clicked, this, &herkulex::sendMessagePinceIdHerkulex);

    connect(m_ui->sendButton_stepMotor_pos, &QPushButton::clicked, this, &herkulex::sendMessageStepMotorPosition);
    connect(m_ui->sendButton_stepMotor_mode, &QPushButton::clicked, this, &herkulex::sendMessageStepMotorMode);

    setAttribute(Qt::WA_QuitOnClose, false);


}

herkulex::~herkulex()
{
    delete m_ui;
}

static QByteArray dataFromHex(const QString &hex)
{
    QByteArray line = hex.toUtf8();
    line.replace(' ', QByteArray());
    return QByteArray::fromHex(line);
}

void herkulex::checkMessages(const QCanBusFrame &frame)
{
    QString view;
    if (frame.frameType() == QCanBusFrame::ErrorFrame) {
        view = m_manager->getErrorString();
    } else {
        view = frame.toString();
    }
    QCanBusFrame copyFrame = frame;
/*
    const QString time = QString::fromLatin1("%1.%2  ")
            .arg(frame.timeStamp().seconds(), 10, 10, QLatin1Char(' '))
            .arg(frame.timeStamp().microSeconds() / 100, 4, 10, QLatin1Char('0'));//*/

    uint8_t data[8] = {0};
    for(int i = 0; i<frame.payload().length(); i++){
        data[i] = frame.payload()[i]&0xFF;
    }

    switch (frame.frameId())
    {
    case ID_HERKULEX_ANSWER:
    {
        if(WAIT_ACK_HERKULEX_POSITION){
            WAIT_ACK_HERKULEX_POSITION = false;
            m_ui->textEdit->append(" ACK Received");
            char ID = data[0];
            short position = (data[3]<< 8)   | data[2];
            QString string_ID= QString::number(ID);
            QString string_pos= QString::number(position);
            QString string_lenght= QString::number(frame.payload().length());
            m_ui->textEdit_requete_pos->append("ID   :   " + string_ID + "   position   =   "+ string_pos + "    len data : " + string_lenght);
        }
        else if(WAIT_ACK_HERKULEX_CHANGE_ID){
            WAIT_ACK_HERKULEX_CHANGE_ID = false;
            m_ui->textEdit->append(" ACK Received");
            char newID = data[0];
            char status = data[1];
            QString string_ID= QString::number(newID);
            QString string_status= QString::number(status);
            if(status == 1){
                m_ui->textEdit->append("new ID   :   " + string_ID + "   Changement ID herkulex : OK   =   "+ status);
            }else if(status == -1){
                m_ui->textEdit->append("This Herkulex doesn't exist  "+ status);
            }else if(status == 0){
                m_ui->textEdit->append("new ID   :   " + string_ID + "   le changement d'ID ne s'est pas fait   =   "+ status);
            }//*/
        }else if(WAIT_ACK_HERKULEX_STAT){
            WAIT_ACK_HERKULEX_STAT = false;
            char IDdetected = data[0];
            if  (IDdetected == -1){m_ui->textEdit->append("Il faut connecter un herkulex à la fois pour la commande STAT et pour recupérer l'ID du HErkulex branché");}
            else{m_ui->textEdit->append("Un Herkulex a été detecté! Son ID :" + QString::number(IDdetected, 10));}

        }else if(WAIT_ACK_HERKULEX_SERIAL_BAUDRATE){
            WAIT_ACK_HERKULEX_SERIAL_BAUDRATE = false;
            m_ui->textEdit->append("Changement serial baudrate effectuer");
        }
        break;
    }

    case 0x00:
    {

        break;
    }


    default:
      break;
    }


}

void herkulex::sendMessageRequete() const
{
    int ID = m_ui->lineEdit_requete_id->displayText().toInt(nullptr, 10);
    qDebug() << "ID = " << ID;
    QString string_HEX= QString::number(ID, 16);
    if(string_HEX.length() < 2){string_HEX = "0" + string_HEX;}

    QByteArray writings = dataFromHex(string_HEX);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ID_HERKULEX_GET_POS; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);


    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);
    WAIT_ACK_HERKULEX_POSITION = true;
}

void herkulex::sendMessageChangeID() const{
    int ID = m_ui->lineEdit_change_id->displayText().toInt(nullptr, 10);
    qDebug() << "ID = " << ID;
    int newID = m_ui->lineEdit_change_is_newId->displayText().toInt(nullptr, 10);
    qDebug() << "new ID = " << newID;

    QString string_HEX_ID= QString::number(ID, 16);
    if(string_HEX_ID.length() < 2){string_HEX_ID = "0" + string_HEX_ID;}

    QString string_HEX_newID= QString::number(newID, 16);
    if(string_HEX_newID.length() < 2){string_HEX_newID = "0" + string_HEX_newID;}


    m_ui->textEdit->append("");
    m_ui->textEdit->append("Changing ID Herkulex, ID Herkulex = 0x" + string_HEX_ID + "new ID :" + string_HEX_newID + "  ...");

    QString string_K = string_HEX_ID + string_HEX_newID;
    QByteArray writings = dataFromHex(string_K);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = IDCAN_HERKULEX_CHANGE_ID; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);

    WAIT_ACK_HERKULEX_CHANGE_ID = true;
}

void herkulex::sendMessageSTAT() const{
    //QByteArray writings = dataFromHex(string_K);
    m_ui->textEdit->append("");
    m_ui->textEdit->append("Sending STAT request ... ");

    QCanBusFrame frame;
    //writings.truncate(8);

    //frame.setPayload(writings);
    qint32 id = ID_HERKULEX_STAT; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);
    WAIT_ACK_HERKULEX_STAT = true;
}

void herkulex::sendMessageSerialBaudRate() const{
    char baudrate = 0;
//#define BAUDRATE_57600 0x22
//#define BAUDRATE_115200 0x10
//#define BAUDRATE_200000 0x09
//#define BAUDRATE_250000 0x07
//#define BAUDRATE_400000 0x04
//#define BAUDRATE_500000 0x03
//#define BAUDRATE_666666 0x02
    QString BaudRate = m_ui->comboBox_baudrate->currentText();
    if(BaudRate == "115200"){
        baudrate = BAUDRATE_115200;
    }else if(BaudRate == "57600"){
        baudrate = BAUDRATE_57600;
    }else if(BaudRate == "200000"){
        baudrate = BAUDRATE_200000;
    }else if(BaudRate == "250000"){
        baudrate = BAUDRATE_250000;
    }else if(BaudRate == "400000"){
        baudrate = BAUDRATE_400000;
    }else if(BaudRate == "500000"){
        baudrate = BAUDRATE_500000;
    }else if(BaudRate == "666666"){
        baudrate = BAUDRATE_666666;
    }else{
        baudrate = 0;
    }
    QString string_baudrate = QString::number(baudrate, 16);

    m_ui->textEdit->append("");
    m_ui->textEdit->append("Envoi requete changement serial baudrate, baudrate :  "
                           + BaudRate
                           +"   ...");



    QByteArray writings = dataFromHex(string_baudrate);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = IDCAN_HERKULEX_SERIAL_BAUDRATE; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);


    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);
    WAIT_ACK_HERKULEX_SERIAL_BAUDRATE = true;
}

void herkulex::sendMessageHerkulexBaudRate()  const{
    int ID = m_ui->lineEdit_baudrate_herkulex_id->displayText().toInt(nullptr, 10);
    qDebug() << "ID = " << ID;
    char baudrate = 0;

    QString string_HEX= QString::number(ID, 16);
    if(string_HEX.length() < 2){string_HEX = "0" + string_HEX;}

    QString BaudRate = m_ui->comboBox_baudrate_herkulex->currentText();
    if(BaudRate == "115200"){
        baudrate = BAUDRATE_115200;
    }else if(BaudRate == "57600"){
        baudrate = BAUDRATE_57600;
    }else if(BaudRate == "200000"){
        baudrate = BAUDRATE_200000;
    }else if(BaudRate == "250000"){
        baudrate = BAUDRATE_250000;
    }else if(BaudRate == "400000"){
        baudrate = BAUDRATE_400000;
    }else if(BaudRate == "500000"){
        baudrate = BAUDRATE_500000;
    }else if(BaudRate == "666666"){
        baudrate = BAUDRATE_666666;
    }else{
        baudrate = 0;
    }
    QString string_baudrate = QString::number(baudrate, 16);

    m_ui->textEdit->append("");
    m_ui->textEdit->append("Envoi requete changement serial baudrate, baudrate :  "
                           + BaudRate
                           +"   ...");

    QString total = string_HEX + string_baudrate;
    m_ui->textEdit->append("            HEX : 0x" + total
                           + "  ...");



    QByteArray writings = dataFromHex(total);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = IDCAN_HERKULEX_BAUDRATE_OF_HERKULEX; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);


    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);
}

void herkulex::sendMessageCoupleActiver() const
{
    int ID = m_ui->lineEdit_couple->displayText().toInt(nullptr, 10);
    qDebug() << "ID = " << ID;

    QString string_HEX= QString::number(ID, 16);
    if(string_HEX.length() < 2){string_HEX = "0" + string_HEX;}
    m_ui->textEdit->append("");
    m_ui->textEdit->append("Setting Torque on, ID Herkulex = 0x" + string_HEX + "  ...");


    QString string_K = string_HEX + "60";
    QByteArray writings = dataFromHex(string_K);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ID_HERKULEX_TORQUE; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);
}


void herkulex::sendMessageCoupleDesactiver() const
{
    int ID = m_ui->lineEdit_couple->displayText().toInt(nullptr, 10);
    qDebug() << "ID = " << ID;

    QString string_HEX= QString::number(ID, 16);
    if(string_HEX.length() < 2){string_HEX = "0" + string_HEX;}
    m_ui->textEdit->append("");
    m_ui->textEdit->append("Setting Torque off, ID Herkulex = 0x" + string_HEX + "  ...");


    QString string_K = string_HEX + "00";
    QByteArray writings = dataFromHex(string_K);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ID_HERKULEX_TORQUE; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);
}


void herkulex::sendMessageClear() const
{
    int ID = m_ui->lineEdit_clear->displayText().toInt(nullptr, 10);
    qDebug() << "ID = " << ID;

    QString string_HEX= QString::number(ID, 16);
    if(string_HEX.length() < 2){string_HEX = "0" + string_HEX;}
    m_ui->textEdit->append("");
    m_ui->textEdit->append("Clearing Herkulex, ID Herkulex = 0x" + string_HEX + "  ...");


    QString string_K = string_HEX;
    QByteArray writings = dataFromHex(string_K);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ID_HERKULEX_CLEAR; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);

    /*if (m_ui->remoteBox->isChecked())
        frame.setFrameType(QCanBusFrame::RemoteRequestFrame);
    else*/
    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);
}

void herkulex::sendMessagePosition() const
{
    // 0              1                2           3            4            5           6
   //Contenue DATA : [ID du Herkulex] ; [commande] ; [position] ; [position] ; [playtime] ; [setLed] ;
    int ID = m_ui->lineEdit_controle_id->displayText().toInt(nullptr, 10);
    int position = m_ui->lineEdit_controle_pos->displayText().toInt(nullptr, 10);
    int pos1 = position&0xFF;
    int pos2 = (position>>8)&0xFF;
    qDebug() << "ID = " << ID;
    qDebug() << "position= " << position;
    qDebug() << "position&0xFF = " << pos1;
    qDebug() << "(position>>8)&0xFF = " << pos2;


    QString string_HEX= QString::number(ID, 16);
    if(string_HEX.length() < 2){string_HEX = "0" + string_HEX;}

    QString string_pos1 = QString::number(pos1, 16);
    if(string_pos1.length() < 2){string_pos1 = "0" + string_pos1;}

    QString string_pos2 = QString::number(pos2, 16);
    if(string_pos2.length() < 2){string_pos2 = "0" + string_pos2;}

    QString Couleur = m_ui->comboBox_controle_couleur->currentText();
    QString color;
    if(Couleur == "Vert"){
        color = "04";
    }else if(Couleur == "Rouge"){
        color = "10";
    }else if(Couleur == "Bleu"){
        color = "08";
    }else{

    }

    QString total = string_HEX + "00" + string_pos1 + string_pos2 + "3C" + color;
    m_ui->textEdit->append("");
    m_ui->textEdit->append("Position Control, ID Herkulex = 0x" + string_HEX
                           + ", Color = " + Couleur
                           + "            HEX : 0x" + total
                           + "  ...");



    QByteArray writings = dataFromHex(total);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ID_HERKULEX_POSITION; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);


    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);
}


void herkulex::on_sendButton_rotation_continu_clicked()
{
    int ID = m_ui->lineEdit_rotation_continu_ID->displayText().toInt(nullptr, 10);
    unsigned short vitesse = m_ui->lineEdit_rotation_continu_vitesse->displayText().toInt(nullptr, 10);
    unsigned char vit1 = vitesse&0xFF;
    unsigned char vit2 = (vitesse>>8)&0xFF;

    QString string_HEX= QString::number(ID, 16);
    if(string_HEX.length() < 2){string_HEX = "0" + string_HEX;}

    QString string_pos1 = QString::number(vit1, 16);
    if(string_pos1.length() < 2){string_pos1 = "0" + string_pos1;}

    QString string_pos2 = QString::number(vit2, 16);
    if(string_pos2.length() < 2){string_pos2 = "0" + string_pos2;}

    QString total = string_HEX + string_pos1 + string_pos2 + "04";

    m_ui->textEdit->append("");
    m_ui->textEdit->append("Rotation Continue, ID Herkulex = 0x" + string_HEX
                           + "            HEX : 0x" + total
                           + "  ...");



    QByteArray writings = dataFromHex(total);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ID_HERKULEX_VITESSE; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);


    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);

}







void herkulex::sendMessageSimultane()         const{
// Longueur : 8 octet
// Contenue DATA : [ID1 du Herkulex] ; [commande] ; [position] ; [position] ; [ID2 du Herkulex] ; [position2] ; [position2] ; [playtime of both]
    int ID1 = m_ui->lineEdit_controle_simultane_id1->displayText().toInt(nullptr, 10);
    int ID2 = m_ui->lineEdit_controle_simultane_id2->displayText().toInt(nullptr, 10);

    int position = m_ui->lineEdit_controle_simultane_pos_1->displayText().toInt(nullptr, 10);
    int pos1 = position&0xFF;
    int pos2 = (position>>8)&0xFF;

    int position2 = m_ui->lineEdit_controle_simultane_pos_2->displayText().toInt(nullptr, 10);
    int pos2_1 = position2&0xFF;
    int pos2_2 = (position2>>8)&0xFF;


    QString string_ID1= QString::number(ID1, 16);
    if(string_ID1.length() < 2){string_ID1 = "0" + string_ID1;}
    QString string_ID2= QString::number(ID2, 16);
    if(string_ID2.length() < 2){string_ID2 = "0" + string_ID2;}

    QString string_pos1 = QString::number(pos1, 16);
    if(string_pos1.length() < 2){string_pos1 = "0" + string_pos1;}
    QString string_pos2 = QString::number(pos2, 16);
    if(string_pos2.length() < 2){string_pos2 = "0" + string_pos2;}

    QString string_pos2_1 = QString::number(pos2_1, 16);
    if(string_pos2_1.length() < 2){string_pos2_1 = "0" + string_pos2_1;}
    QString string_pos2_2 = QString::number(pos2_2, 16);
    if(string_pos2_2.length() < 2){string_pos2_2 = "0" + string_pos2_2;}


//[ID1 du Herkulex] ; [commande] ; [position] ; [position] ; [ID2 du Herkulex] ; [position2] ; [position2] ; [playtime of both]
    QString total = string_ID1 + "01" + string_pos1 + string_pos2 + string_ID2 + string_pos2_1 + string_pos2_2 + "3C";
    m_ui->textEdit->append("");
    m_ui->textEdit->append("Position Control, 2 Herkulex simulaténement, ID1 Herkulex = 0x" + string_ID1
                           + "   ID2 Herkulex = 0x" + string_ID2
                           + "            HEX : 0x" + total
                           + "  ...");



    QByteArray writings = dataFromHex(total);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ID_HERKULEX_POSITION; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);


    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);
}

void herkulex::sendMessagePinceAttraper() const//[nb etages];[etat(serrer/lacher);[sens]]
{
    QString selection = m_ui->comboBox_pince_etage->currentText();
    QString etage;
    if(selection == "Etage 0"){
        etage = "00";
    }else if(selection == "Etage 1"){
        etage = "01";
    }else if(selection == "Etage 2"){
        etage = "02";
    }else if(selection == "Etage 3"){
        etage = "03";
    }else if(selection == "Etage 4"){
        etage = "04";
    }
    QString total = etage + "01" + "FF";
    m_ui->textEdit->append("");
    m_ui->textEdit->append("Pince : Attraper la part de gâteau, soit serrer et monter la pince, Hex : 0x " + total);



    QByteArray writings = dataFromHex(total);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ID_HERKULEX_PINCE; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);


    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);

}


void herkulex::sendMessagePinceLacher() const//[nb etages];[etat(serrer/lacher);[sens]]
{
    QString selection = m_ui->comboBox_pince_etage->currentText();
    QString etage;
    if(selection == "Etage 0"){
        etage = "00";
    }else if(selection == "Etage 1"){
        etage = "01";
    }else if(selection == "Etage 2"){
        etage = "02";
    }else if(selection == "Etage 3"){
        etage = "03";
    }else if(selection == "Etage 4"){
        etage = "04";
    }
    QString total = etage + "00" + "FF";
    m_ui->textEdit->append("");
    m_ui->textEdit->append("Pince : Lâcher la part de gâteau, soit lâcher et descendre");



    QByteArray writings = dataFromHex(total);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ID_HERKULEX_PINCE; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);


    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);

}


void herkulex::sendMessagePinceIdHerkulex() const
{
    int ID = m_ui->lineEdit_pince_idHerkulex->displayText().toInt(nullptr, 10);

    QString total= QString::number(ID, 16);
    if(total.length() < 2){total = "0" + total;}
    m_ui->textEdit->append("");
    m_ui->textEdit->append("Changement ID de l'Herkulex de la pince : 0x" + total);



    QByteArray writings = dataFromHex(total);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ID_HERKULEX_PINCE_CHANGEID; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);


    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);

}


void herkulex::sendMessageStepMotorPosition() const
{
    unsigned int position = (m_ui->lineEdit_stepMotor_pos->displayText().toInt(nullptr, 10))*3600/80.0;
    unsigned int pos1 = position&0xFF;
    unsigned int pos2 = (position>>8)&0xFF;
    unsigned int pos3 = (position>>16)&0xFF;
    unsigned int pos4 = (position>>24)&0xFF;

    qDebug() << "position= " << position;
    qDebug() << "position&0xFF = " << pos1;
    qDebug() << "(position>>8)&0xFF = " << pos2;


    QString string_pos1 = QString::number(pos1, 16);
    if(string_pos1.length() < 2){string_pos1 = "0" + string_pos1;}

    QString string_pos2 = QString::number(pos2, 16);
    if(string_pos2.length() < 2){string_pos2 = "0" + string_pos2;}

    QString string_pos3 = QString::number(pos3, 16);
    if(string_pos3.length() < 2){string_pos3 = "0" + string_pos3;}

    QString string_pos4 = QString::number(pos4, 16);
    if(string_pos4.length() < 2){string_pos4 = "0" + string_pos4;}

    QString total = string_pos1 + string_pos2 + string_pos3 + string_pos4;
    m_ui->textEdit->append("");
    m_ui->textEdit->append("StepMotor, Position Control" + total
                           + "  ...");

    QByteArray writings = dataFromHex(total);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ID_STEP_MOT_POS; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);


    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);
}


void herkulex::sendMessageStepMotorMode() const
{
    QString selection = m_ui->comboBox__stepMotor_mode->currentText();
    QString mode = "0";
    if(selection == "1"){
        mode = "100000";
    }else if(selection == "2"){
        mode = "000100";
    }else if(selection == "3"){
        mode = "010100";
    }else if(selection == "4"){
        mode = "000001";
    }else if(selection == "5"){
        mode = "010001";
    }else if(selection == "6"){
        mode = "000101";
    }else if(selection == "7"){
        mode = "010101";
    }
    m_ui->textEdit->append("");
    m_ui->textEdit->append("StepMotor, Change Mode, mode :" + selection
                           +"HEX : 0x" + mode
                           + "  ...");

    QByteArray writings = dataFromHex(mode);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ID_STEP_MOT_MODE; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);


    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);
}










void herkulex::on_sendButton_STAT_clicked()
{
    QCanBusFrame frame;
    //writings.truncate(8);

    //frame.setPayload(writings);
    qint32 id = ID_HERKULEX_STAT; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);


    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);
    WAIT_ACK_HERKULEX_POSITION = true;

}




void herkulex::position_step_motor(int hauteur){
    unsigned int position = hauteur*3600/80.0;
    unsigned int pos1 = position&0xFF;
    unsigned int pos2 = (position>>8)&0xFF;
    unsigned int pos3 = (position>>16)&0xFF;
    unsigned int pos4 = (position>>24)&0xFF;

    qDebug() << "position= " << position;
    qDebug() << "position&0xFF = " << pos1;
    qDebug() << "(position>>8)&0xFF = " << pos2;


    QString string_pos1 = QString::number(pos1, 16);
    if(string_pos1.length() < 2){string_pos1 = "0" + string_pos1;}

    QString string_pos2 = QString::number(pos2, 16);
    if(string_pos2.length() < 2){string_pos2 = "0" + string_pos2;}

    QString string_pos3 = QString::number(pos3, 16);
    if(string_pos3.length() < 2){string_pos3 = "0" + string_pos3;}

    QString string_pos4 = QString::number(pos4, 16);
    if(string_pos4.length() < 2){string_pos4 = "0" + string_pos4;}

    QString total = string_pos1 + string_pos2 + string_pos3 + string_pos4;
    m_ui->textEdit->append("");
    m_ui->textEdit->append("StepMotor, Position Control" + total
                           + "  ...");

    QByteArray writings = dataFromHex(total);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ID_STEP_MOT_POS; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);


    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);



}



void herkulex::herkulexControle(int ID, int position){
    // 0              1                2           3            4            5           6
   //Contenue DATA : [ID du Herkulex] ; [commande] ; [position] ; [position] ; [playtime] ; [setLed] ;
    int pos1 = position&0xFF;
    int pos2 = (position>>8)&0xFF;
    qDebug() << "ID = " << ID;
    qDebug() << "position= " << position;
    qDebug() << "position&0xFF = " << pos1;
    qDebug() << "(position>>8)&0xFF = " << pos2;


    QString string_HEX= QString::number(ID, 16);
    if(string_HEX.length() < 2){string_HEX = "0" + string_HEX;}

    QString string_pos1 = QString::number(pos1, 16);
    if(string_pos1.length() < 2){string_pos1 = "0" + string_pos1;}

    QString string_pos2 = QString::number(pos2, 16);
    if(string_pos2.length() < 2){string_pos2 = "0" + string_pos2;}

    QString Couleur = m_ui->comboBox_controle_couleur->currentText();
    QString color;
    if(Couleur == "Vert"){
        color = "04";
    }else if(Couleur == "Rouge"){
        color = "10";
    }else if(Couleur == "Bleu"){
        color = "08";
    }else{

    }

    QString total = string_HEX + "00" + string_pos1 + string_pos2 + "3C" + color;
    m_ui->textEdit->append("");
    m_ui->textEdit->append("Position Control, ID Herkulex = 0x" + string_HEX
                           + ", Color = " + Couleur
                           + "            HEX : 0x" + total
                           + "  ...");



    QByteArray writings = dataFromHex(total);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ID_HERKULEX_POSITION; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);


    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);
}


void herkulex::on_sendButton_pose_cerise_clicked()
{
    QString selection = m_ui->comboBox_verif_gateau->currentText();
    QString verif = "00";
    if(selection == "Prendre en compte"){
        verif = "01";
    }

    m_ui->textEdit->append("");
    m_ui->textEdit->append("Pose cerise, IDCAN_POSE_CERISE, 0x" + verif
                           + "  ...");



    QByteArray writings = dataFromHex(verif);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = IDCAN_POSE_CERISE; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);


    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);

}

void herkulex::on_sendButton_tourner_clicked()
{
    int ID = m_ui->lineEdit_tourner_id->displayText().toInt(nullptr, 10);
    unsigned short vitesse = m_ui->lineEdit_tourner_vitesse->displayText().toInt(nullptr, 10);
    unsigned char vit1 = vitesse&0xFF;
    unsigned char vit2 = (vitesse>>8)&0xFF;
    uint8_t nbTours = m_ui->lineEdit_tourner_nb_tour->displayText().toInt(nullptr, 10);

    QString string_HEX= QString::number(ID, 16);
    if(string_HEX.length() < 2){string_HEX = "0" + string_HEX;}

    QString string_pos1 = QString::number(vit1, 16);
    if(string_pos1.length() < 2){string_pos1 = "0" + string_pos1;}

    QString string_pos2 = QString::number(vit2, 16);
    if(string_pos2.length() < 2){string_pos2 = "0" + string_pos2;}

    QString Tours = QString::number(nbTours, 16);
    if(Tours.length() < 2){Tours = "0" + Tours;}

    QString total = string_HEX + string_pos1 + string_pos2 + Tours;

    m_ui->textEdit->append("");
    m_ui->textEdit->append("Tourner nb Tours, IDCAN_PINCE_ARRIERE = 0x75           HEX : 0x" + total
                           + "  ...");



    QByteArray writings = dataFromHex(total);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = ID_HERKULEX_TOURNER_NB_TOUR; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);


    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);
}


void herkulex::on_sendButton_pince_arriere_fermer_clicked()
{
    QString etatHerkulex = "00", poseCerise = "00", gateauInAccount = "00";

    QString total = etatHerkulex + poseCerise + gateauInAccount;

    m_ui->textEdit->append("");
    m_ui->textEdit->append("Tourner nb Tours, IDCAN_PINCE_ARRIERE = 0x75           HEX : 0x" + total
                           + "  ...");



    QByteArray writings = dataFromHex(total);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = IDCAN_PINCE_ARRIERE; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);


    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);

}



void herkulex::on_sendButton_pince_arriere_gateau_clicked()
{
    QString etatHerkulex = "01", poseCerise = "01", gateauInAccount = "01";

    QString total = etatHerkulex + poseCerise + gateauInAccount;

    m_ui->textEdit->append("");
    m_ui->textEdit->append("Tourner nb Tours, IDCAN_PINCE_ARRIERE = 0x75           HEX : 0x" + total
                           + "  ...");



    QByteArray writings = dataFromHex(total);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = IDCAN_PINCE_ARRIERE; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);


    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);
}



void herkulex::on_sendButton_pince_arriere_ouvert_clicked()
{
    QString etatHerkulex = "02", poseCerise = "00", gateauInAccount = "00";

    QString total = etatHerkulex + poseCerise + gateauInAccount;

    m_ui->textEdit->append("");
    m_ui->textEdit->append("Tourner nb Tours, IDCAN_PINCE_ARRIERE = 0x75           HEX : 0x" + total
                           + "  ...");



    QByteArray writings = dataFromHex(total);

    QCanBusFrame frame;
    writings.truncate(8);

    frame.setPayload(writings);
    qint32 id = IDCAN_PINCE_ARRIERE; //m_ui->idEdit->displayText().toInt(nullptr, 16);
    //if (id > 2047) id = 2047;
    frame.setFrameId(id);
    frame.setExtendedFrameFormat(false);
    frame.setFlexibleDataRateFormat(false);
    frame.setBitrateSwitch(false);


    frame.setFrameType(QCanBusFrame::DataFrame);

    m_manager->send(frame);
}





















void herkulex::on_browse()
{
    QString fileName = QFileDialog::getOpenFileName(this,
        tr("Open cyacd"),
        "/home/yves/Documents/qt5/can/PSoC_Creator/CRAC/Moteurs.cydsn/CortexM3/ARM_GCC_541/Release/Moteurs.cyacd"
        , tr("Cypress Bootloadable Files (*.cyacd)"));
    //if (!fileName.isNull()) m_ui->fileName->setText(fileName);
}

void herkulex::showMessage(const char *txt)
{
    //m_ui->status->setText(txt);
}


int herkulex::sendDatas(char *bytes, int size)
{
    if (size <= 8) {
        QByteArray data(bytes, size);
        m_manager->send(ID_BOOTLOAD_READ, data);
        return CYRET_SUCCESS;
    }
    QEventLoop loop;
    QTimer timer;
    timer.setSingleShot(true);
    QByteArray data = CanBusHelper::uint16ToFrame(size);
    connect(this, SIGNAL(rtrReceived()), &loop, SLOT(quit()));
    connect(&timer, SIGNAL(timeout()), &loop, SLOT(quit()));
    int retry = 1;
    while (1) {
        timer.start(1000);
        m_manager->send(ID_BOOTLOAD_READ_MULTI, data);
        loop.exec();
        if (!timer.isActive()) {
            retry--;
            if (retry==0) {
                closeCommunication();
                return CYRET_ERR_UNK;
            }
        } else {
            break;
        }
    }
    data.clear();
    data.append(bytes, size);
    while (data.size() > 0) {
        QByteArray sendData = data.leftJustified(8, '\0', true);
        retry = 2;
        while (1) {
            timer.start(1000);
            m_manager->send(ID_BOOTLOAD_READ_MULTI, sendData);
            loop.exec();
            if (!timer.isActive()) {
                retry--;
                if (retry==0) {
                    closeCommunication();
                    return CYRET_ERR_UNK;
                }
            } else {
                break;
            }
        }
        int n = data.size()-8;
        if (n<=0) data = ""; else data = data.right(n);
    }
    return CYRET_SUCCESS;
}

int herkulex::receiveDatas(char *bytes, int size)
{
    QEventLoop loop;
    QTimer timer;
    timer.setSingleShot(true);
    connect(this, SIGNAL(datasReceived()), &loop, SLOT(quit()));
    connect(&timer, SIGNAL(timeout()), &loop, SLOT(quit()));
    if (!m_receiveDatas.size()) {
        timer.start(1000);
        loop.exec();
        if (!timer.isActive()) {
            closeCommunication();
            return CYRET_ERR_UNK;
        }
    }
    memcpy(bytes, m_receiveDatas.data(), m_receiveDatas.size());
    m_receiveDatas.clear();
    return CYRET_SUCCESS;
}

void herkulex::framesReceived(const QCanBusFrame &frame)
{
    int id = frame.frameId();
    QString idStr = QString("0x%1").arg(id, 3, 16, QLatin1Char('0'));
    if (id == ID_BOOTLOAD_WRITE_MULTI) {
        int size = frame.payload().size();
        if (size == 2) {
            QByteArray data = frame.payload();
            m_size = CanBusHelper::fromFrameToUint16(data);
            m_manager->send(ID_BOOTLOAD_WRITE_MULTI); // rtr
        } else if (size == 8) {
            QByteArray data = frame.payload();
            if (data.size() > m_size) data.truncate(m_size);
            m_receiveDatas += data;
            m_size -= data.size();
            if (m_size == 0) emit datasReceived();
            m_manager->send(ID_BOOTLOAD_WRITE_MULTI); // rtr
        }
    } else if (id == ID_BOOTLOAD_READ_MULTI) {
        if (frame.frameType() == QCanBusFrame::RemoteRequestFrame) {
            emit rtrReceived();
        }
    } else if (id == ID_BOOTLOAD_WRITE) {
        m_receiveDatas = frame.payload();
        emit datasReceived();
        m_manager->send(ID_BOOTLOAD_WRITE);
    } else if (id == ID_BOOTLOAD_READ) {
        if (frame.frameType() == QCanBusFrame::RemoteRequestFrame) {
            emit rtrReceived();
        }
    }
}

int herkulex::openCommunication()
{
    if (!m_manager->isConnected()) return CYRET_ERR_BTLDR;
    recordLink();
    return CYRET_SUCCESS;
}

int herkulex::closeCommunication()
{
    removeLink();
    return CYRET_SUCCESS;
}

extern "C" {

static int openCommunication()
{
    return fenetre->openCommunication();
}

static int closeCommunication()
{
    return fenetre->closeCommunication();
}

static int writeData(unsigned char *bytes, int size)
{
    if (fenetre->sendDatas(reinterpret_cast<char *>(bytes), size)) return CYRET_ERR_UNK;
    return CYRET_SUCCESS;
}

static int readData(unsigned char *bytes, int size)
{
    if (fenetre->receiveDatas(reinterpret_cast<char *>(bytes), size)) return CYRET_ERR_UNK;
    return CYRET_SUCCESS;
}

static CyBtldr_CommunicationsData communication = {
    .OpenConnection = openCommunication,
    .CloseConnection = closeCommunication,
    .ReadData = readData,
    .WriteData = writeData,
    .MaxTransferSize = 64,
};

static void serial_progress_update(unsigned char arrayId, unsigned short rowNum)
{
    char str[100];
    sprintf(str, "Progress: array_id %d, row_num %d\n", arrayId, rowNum);
    fenetre->showMessage(str);
    fenetre->setProgress((100*rowNum)/1023);
}

}

void herkulex::setProgress(int value)
{
    //m_ui->progressBar->setValue(value);
}

void herkulex::on_program()
{
    //m_ui->progressBar->setValue(0);
    //m_ui->progressBar->setVisible(true);
    showMessage("");
    m_manager->send(ID_MOTEURS_RESET, QByteArray()); // reset du PSOC
    QTimer::singleShot(500, this, SLOT(program()));
}

void herkulex::program()
{
    int ret;// = CyBtldr_RunAction(PROGRAM, m_ui->fileName->text().toStdString().c_str(), NULL, 0, &communication, serial_progress_update);
    if (ret != CYRET_SUCCESS) {
        showMessage("Programming failed");
    } else {
        showMessage("Programming success");
    }
    //m_ui->progressBar->setVisible(false);
}




















