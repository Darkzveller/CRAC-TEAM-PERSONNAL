#ifndef MOTEURSWINDOW_H
#define MOTEURSWINDOW_H

#include <QMainWindow>
#include "canbusmanager.h"

#include <QFileDialog>
#include <QTimer>
#include <QDebug>

#include <QCanBus>
#include <QCanBusFrame>
#include <QCloseEvent>
#include <QDesktopServices>
#include <QtDebug>
#include <QTreeView>
#include <QProgressDialog>


namespace Ui {
class MoteursWindow;
}

class MoteursWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MoteursWindow(CanBusManager *manager, QWidget *parent = nullptr);
    ~MoteursWindow();
    void showMessage(const char *txt);
    int sendDatas(char *bytes, int size);
    int receiveDatas(char *bytes, int size);
    int openCommunication();
    int closeCommunication();
    void setProgress(int value);

private:
    Ui::MoteursWindow *m_ui;
    CanBusManager *m_manager;
    int m_size;
    short Odo_x;
    short Odo_y;
    short Odo_theta;
    QMetaObject::Connection m_connect;
    QByteArray m_receiveDatas;
    void recordLink() {
        disconnect(m_connect);
        m_connect = connect(m_manager, SIGNAL(framesReceived(const QCanBusFrame &)), this, SLOT(framesReceived(const QCanBusFrame &)));
    }
    void removeLink() { disconnect(m_connect); }
    static const int ID_BOOTLOAD_WRITE_MULTI, ID_BOOTLOAD_READ_MULTI, ID_BOOTLOAD_WRITE, ID_BOOTLOAD_READ, ID_MOTEURS_RESET;

    static const int BASE_AVANCER = 50, BASE_RECULER = 51, BASE_ROTATION_GAUCHE = 52, BASE_ROTATION_DROITE = 53,  HERKULEX_SERRER = 60, HERKULEX_LACHER = 61, STEP_MOTOR_POSITION = 70, WAINTING_FOR_RESPONSE = 100;

private slots:
    void on_browse();
    void on_program();
    void framesReceived(const QCanBusFrame &frame);
    void program();
    void checkMessages(const QCanBusFrame &frame);
    void sendMessageKp() const;
    void sendMessageKd() const;
    void sendMessageKi() const;
    void sendMessageLargeurRobot() const;
    void sendMessageResolutionRoueCodeuse() const;
    void sendMessageRotation();
    void sendMessageTranslation() const;
    void sendMessagePosition() const;
    void sendMessageCourbure() const;
    void sendMessageRecalage() const;

    void on_sendButton_esp32Restart_clicked();

    void on_sendButton_asservissement_activer_clicked();

    void on_sendButton_asservissement_desactiver_clicked();

    void on_sendButton_position_2_clicked();

    void on_pushButton_released();

    void on_sendButton_algo_gateau_clicked();

    void translation(unsigned short K);

    void rotation           (unsigned short K);
    void algo_gateau        (int IDCAN, int response);
    void herkulexControle   (int ID, int position);
    void position_step_motor(int hauteur);

    void on_sendButton_algo_gateau_desordre_clicked();

    void on_sendButton_algo_gateau_reset_clicked();

    void on_sendButton_vitesse_clicked();


    void on_pushButton_clicked();

    void on_sendButton_recalage_clicked();

    void on_sendButton_score_robot_clicked();

signals:
    void rtrReceived();
    void datasReceived();
};

#endif // MOTEURSWINDOW_H
