#include "positionxyt.h"
#include "ui_positionxyt.h"

PositionXYT::PositionXYT(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::PositionXYT)
{
    ui->setupUi(this);
}

PositionXYT::~PositionXYT()
{
    delete ui;
}
