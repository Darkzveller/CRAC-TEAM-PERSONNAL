#ifndef DIALOGUPLOAD_H
#define DIALOGUPLOAD_H

#include <QDialog>
#include <QAbstractItemModel>
#include "remoteFileSystem.h"
#include "fichiers.h"

namespace Ui {
class DialogUpload;
}

class DialogUpload : public QDialog
{
    Q_OBJECT

public:
    explicit DialogUpload(TreeModel *model, QWidget *parent = nullptr);
    ~DialogUpload();
    void set(const QString &source, const QString &dest, const QString &alt, bool showSrc = true);
    bool get(QString &dest);
private:
    Ui::DialogUpload *ui;
    bool m_erase;
    void showSource(bool ok = true);
    void add(Dossier *d);
    TreeModel *m_model;
    QString m_dest, m_alt;
private slots:
    void eraseClicked();
    void altClicked();
};

#endif // DIALOGUPLOAD_H
