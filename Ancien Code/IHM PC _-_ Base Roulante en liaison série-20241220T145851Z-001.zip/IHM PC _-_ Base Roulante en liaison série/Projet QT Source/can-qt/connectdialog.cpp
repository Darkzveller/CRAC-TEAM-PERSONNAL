/****************************************************************************
**
** Copyright (C) 2017 The Qt Company Ltd.
** Contact: http://www.qt.io/licensing/
**
** This file is part of the examples of the QtSerialBus module.
**
** $QT_BEGIN_LICENSE:BSD$
** You may use this file under the terms of the BSD license as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of The Qt Company Ltd nor the names of its
**     contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
** $QT_END_LICENSE$
**
****************************************************************************/

#include "connectdialog.h"
#include "ui_connectdialog.h"

#include <QCanBus>

ConnectDialog::ConnectDialog(QWidget *parent) :
    QDialog(parent),
    m_ui(new Ui::ConnectDialog)
{
    m_ui->setupUi(this);

    connect(m_ui->okButton, &QPushButton::clicked, this, &ConnectDialog::ok);
    connect(m_ui->cancelButton, &QPushButton::clicked, this, &ConnectDialog::cancel);
    connect(m_ui->backendListBox, &QComboBox::currentTextChanged,
            this, &ConnectDialog::backendChanged);
    connect(m_ui->interfaceListBox, &QComboBox::currentTextChanged,
            this, &ConnectDialog::interfaceChanged);

    m_ui->backendListBox->addItems(QCanBus::instance()->plugins());
    m_ui->backendListBox->setCurrentText("serialcan");
    updateSettings();
}

ConnectDialog::~ConnectDialog()
{
    delete m_ui;
}

ConnectDialog::Settings ConnectDialog::settings() const
{
    return m_currentSettings;
}

void ConnectDialog::backendChanged(const QString &backend)
{
    m_ui->interfaceListBox->clear();
    m_interfaces = QCanBus::instance()->availableDevices(backend);
    for (const QCanBusDeviceInfo &info : qAsConst(m_interfaces)) m_ui->interfaceListBox->addItem(info.name());
    bool serial = (backend == "serialcan");
    m_ui->serialBaudLabel->setVisible(serial);
    m_ui->serialBaudBox->setVisible(serial);
}

void ConnectDialog::interfaceChanged(const QString &ifc)
{
    m_ui->isVirtual->setChecked(false);
    for (const QCanBusDeviceInfo &info : qAsConst(m_interfaces)) {
        if (info.name() == ifc) {
            m_ui->isVirtual->setChecked(info.isVirtual());
            break;
        }
    }
}

void ConnectDialog::ok()
{
    updateSettings();
    accept();
}

void ConnectDialog::cancel()
{
    revertSettings();
    reject();
}

QString ConnectDialog::configurationValue(QCanBusDevice::ConfigurationKey key)
{
    QVariant result;

    for (const ConfigurationItem &item : qAsConst(m_currentSettings.configurations)) {
        if (item.first == key) {
            result = item.second;
            break;
        }
    }

    return result.toString();
}

void ConnectDialog::revertSettings()
{
    m_ui->backendListBox->setCurrentText(m_currentSettings.backendName);
    m_ui->interfaceListBox->setCurrentText(m_currentSettings.deviceInterfaceName);

    QString value = configurationValue(QCanBusDevice::BitRateKey);
    m_ui->bitrateBox->setCurrentText(value);
    value = configurationValue(QCanBusDevice::UserKey);
    m_ui->serialBaudBox->setCurrentText(value);
}

void ConnectDialog::updateSettings()
{
    m_currentSettings.backendName = m_ui->backendListBox->currentText();
    m_currentSettings.deviceInterfaceName = m_ui->interfaceListBox->currentText();

    m_currentSettings.configurations.clear();
    // process bitrate
    const int bitrate = m_ui->bitrateBox->bitRate();
    if (bitrate > 0) {
        const ConfigurationItem item(QCanBusDevice::BitRateKey, QVariant(bitrate));
        m_currentSettings.configurations.append(item);
    }
    // process serial baudrate
    const int baudrate = m_ui->serialBaudBox->bitRate();
    if (baudrate > 0) {
        const ConfigurationItem item(QCanBusDevice::UserKey, QVariant(baudrate));
        m_currentSettings.configurations.append(item);
    }
}
