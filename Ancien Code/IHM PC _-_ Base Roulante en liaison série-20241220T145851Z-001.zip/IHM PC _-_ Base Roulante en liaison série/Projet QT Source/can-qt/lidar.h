#ifndef LIDAR_H
#define LIDAR_H

#include <QMainWindow>
#include "canbusmanager.h"

#include <QFileDialog>
#include <QTimer>
#include <QDebug>

#include <QCanBus>
#include <QCanBusFrame>
#include <QCloseEvent>
#include <QDesktopServices>
#include <QtDebug>
#include <QTreeView>
#include <QProgressDialog>
#include <QGraphicsScene>
#include <QGraphicsView>

#include <QTimer>

#include <QGraphicsPixmapItem>
#include <QSGRendererInterface>
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include <QPixmap>
#include <QTransform>
#include <QWidget>
#include <QPointF>
#include <cmath>

#include <QCursor>

#include "QGraphicsProxyWidget"

#include "Instruction.h"


namespace Ui {
class Lidar;
}

class Lidar : public QMainWindow
{
    Q_OBJECT


public:
    explicit Lidar(CanBusManager *manager, QWidget *parent = nullptr);
    ~Lidar();
    void showMessage(const char *txt);
    int sendDatas(char *bytes, int size);
    int receiveDatas(char *bytes, int size);
    int openCommunication();
    int closeCommunication();
    void setProgress(int value);
    QMetaObject::Connection m_connect;
    QByteArray m_receiveDatas;
    void recordLink() {
        disconnect(m_connect);
        m_connect = connect(m_manager, SIGNAL(framesReceived(const QCanBusFrame &)), this, SLOT(framesReceived(const QCanBusFrame &)));
    }
    void removeLink() { disconnect(m_connect); }
    static const int ID_BOOTLOAD_WRITE_MULTI, ID_BOOTLOAD_READ_MULTI, ID_BOOTLOAD_WRITE, ID_BOOTLOAD_READ, ID_MOTEURS_RESET;

private:
    Ui::Lidar *m_ui;
    CanBusManager *m_manager;
    int m_size;
    QGraphicsScene *scene;
    QGraphicsProxyWidget *w;
    QGraphicsProxyWidget *obj1;
    QGraphicsProxyWidget *obj2;
    QGraphicsProxyWidget *obj3;
    QGraphicsProxyWidget *point;
    QGraphicsProxyWidget *DROITE;
    QGraphicsProxyWidget *GAUCHE;
    short Odo_x;
    short Odo_y;
    short Odo_theta;
    QPoint cursorPosition;
    Qt::MouseButtons cursorButtons;
    QTimer *MyTimer;
private slots:
    void on_browse();
    void on_program();
    void framesReceived(const QCanBusFrame &frame);
    void program();

    void checkMessages(const QCanBusFrame &frame);
    void positionRobot(short x, short y, short theta);
    void on_graphicsView_rubberBandChanged(const QRect &viewportRect, const QPointF &fromScenePoint, const QPointF &toScenePoint);
    void positionObstacle1(short x, short y);
    void positionObstacle2(short x, short y);
    void positionObstacle3(short x, short y);
    void followXYcursor();
    void monTimer();
    void SendMessageCan(qint32 id, QString hex);
    void rotation_droite();
    void rotation_gauche();
    void on_button_pos_debut_clicked();

    void on_button_creation_txt_clicked();

    void on_button_recallage_clicked();

    void on_button_capture_clicked();

    void on_button_depose_clicked();

    void on_button_panier_clicked();

    void on_button_arrive_clicked();

    void on_button_assiette_bleu_carre_clicked();
    void on_button_assiette_bleu_rondeHC_clicked();
    void on_button_assiette_bleu_rondeBC_clicked();
    void on_button_assiette_bleu_rondeDH_clicked();
    void on_button_assiette_bleu_rondeDB_clicked();

    void on_button_assiette_verte_carre_clicked();
    void on_button_assiette_verte_rondeHC_clicked();
    void on_button_assiette_verte_rondeBC_clicked();
    void on_button_assiette_verte_rondeDH_clicked();
    void on_button_assiette_verte_rondeDB_clicked();

    void on_button_roseHG_clicked();
    void on_button_roseBG_clicked();
    void on_button_roseHD_clicked();
    void on_button_roseBD_clicked();

    void on_button_jauneHG_clicked();
    void on_button_jauneBG_clicked();
    void on_button_jauneHD_clicked();
    void on_button_jauneBD_clicked();

    void on_button_brunHG_clicked();
    void on_button_brunBG_clicked();
    void on_button_brunHD_clicked();
    void on_button_brunBD_clicked();

    void on_button_reset_clicked();

    void on_button_port_cerises_G_clicked();
    void on_button_port_cerises_H_clicked();
    void on_button_port_cerises_B_clicked();
    void on_button_port_cerises_D_clicked();

    void on_button_cote_table_G_clicked();
    void on_button_cote_table_H_clicked();
    void on_button_cote_table_B_clicked();
    void on_button_cote_table_D_clicked();

    void on_button_pile_gateau_RJM_clicked();
    void on_button_pile_gateau_MJR_clicked();
    void on_button_pile_gateau_RJ_clicked();
    void on_button_pile_gateau_JR_clicked();
    void on_button_pile_gateau_M_clicked();


    void dessineLigne(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2);

    struct S_Instruction pince(uint8_t etage, uint8_t etatHerkulex, uint8_t sens);
    struct S_Instruction XYT(short x, short y, short theta, enum E_InstructionDirection direction);
    struct S_Instruction toutDroit(int distance);
    struct S_Instruction Recalage(int val_recalage, enum E_InstructionDirection direction, enum E_InstructionPrecisionOuRecalage    axe);
    struct S_Instruction poseCerise();
    struct S_Instruction pinceArriere(uint8_t position, bool cerise);
    struct S_Instruction Aspirateur(bool activation);
    void remplirStruct_capture_gateau(QString gateau);
    void remplirStrut_depot_gateau(short posbasx, short posbasy, short posbastheta, bool inverse);
    void remplirStruct_capture_cerise(QString port_cerises);

    void on_button_ctrlZ_clicked();

signals:
    void rtrReceived();
    void datasReceived();
};

#endif // LIDAR_H
