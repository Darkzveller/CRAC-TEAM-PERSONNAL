#ifndef HERKULEX_H
#define HERKULEX_H

#include <QMainWindow>
#include "canbusmanager.h"

#include <QFileDialog>
#include <QTimer>
#include <QDebug>

#include <QCanBus>
#include <QCanBusFrame>
#include <QCloseEvent>
#include <QDesktopServices>
#include <QtDebug>
#include <QTreeView>
#include <QProgressDialog>


namespace Ui {
class herkulex;
}

class herkulex : public QMainWindow
{
    Q_OBJECT

public:
    explicit herkulex(CanBusManager *manager, QWidget *parent = nullptr);
    ~herkulex();
    void showMessage          (const char *txt);
    int sendDatas       (char *bytes, int size);
    int receiveDatas    (char *bytes, int size);
    int openCommunication                    ();
    int closeCommunication                   ();
    void setProgress                (int value);
    void position_step_motor      (int hauteur);
    void herkulexControle(int ID, int position);

private:
    Ui::herkulex *m_ui;
    CanBusManager *m_manager;
    int m_size;
    short Odo_x;
    short Odo_y;
    short Odo_theta;
    QMetaObject::Connection m_connect;
    QByteArray m_receiveDatas;
    void recordLink() {
        disconnect(m_connect);
        m_connect = connect(m_manager, SIGNAL(framesReceived(const QCanBusFrame &)), this, SLOT(framesReceived(const QCanBusFrame &)));
    }
    void removeLink() { disconnect(m_connect); }
    static const int ID_BOOTLOAD_WRITE_MULTI, ID_BOOTLOAD_READ_MULTI, ID_BOOTLOAD_WRITE, ID_BOOTLOAD_READ, ID_MOTEURS_RESET;

private slots:
    void on_browse();
    void on_program();
    void framesReceived(const QCanBusFrame &frame);
    void program();
    void checkMessages(const QCanBusFrame &frame);

    void sendMessageCoupleActiver()     const;
    void sendMessageCoupleDesactiver()  const;
    void sendMessageClear()             const;
    void sendMessagePosition()          const;
    void sendMessagePinceAttraper()     const;
    void sendMessagePinceLacher()       const;
    void sendMessagePinceIdHerkulex()   const;
    void sendMessageStepMotorPosition() const;
    void sendMessageStepMotorMode()     const;
    void sendMessageRequete()           const;
    void sendMessageChangeID()          const;
    void sendMessageSTAT()              const;
    void sendMessageSerialBaudRate()    const;
    void sendMessageHerkulexBaudRate()  const;
    void sendMessageSimultane()         const;


    void on_sendButton_STAT_clicked();

    void on_sendButton_rotation_continu_clicked();

    void on_sendButton_pose_cerise_clicked();

    void on_sendButton_tourner_clicked();

    void on_sendButton_pince_arriere_fermer_clicked();

    void on_sendButton_pince_arriere_gateau_clicked();

    void on_sendButton_pince_arriere_ouvert_clicked();

signals:
    void rtrReceived();
    void datasReceived();
};

#endif // HERKULEX_H
