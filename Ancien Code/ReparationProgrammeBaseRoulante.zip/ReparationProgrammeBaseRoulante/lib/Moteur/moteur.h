#include <Arduino.h>


//Fonctions Moteurs :
void Moteur_Init();
void setupPWM(int PWMpin, int PWMChannel);
