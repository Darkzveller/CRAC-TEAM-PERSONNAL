/****************************************************************************************/
/*                                   IDENT_CRAC.H                                     */
/****************************************************************************************/

/****************************************************************************************/
/*                          Securite contre les multi-inclusions                        */
/****************************************************************************************/
#ifndef IDENTITER_BY_YOUSSEFH
#define IDENTITER_BY_YOUSSEFH

/****************************************************************************************/
/*                              Identiants pour le bus CAN                              */
/****************************************************************************************/
#define GLOBAL_GAME_END 0x004  // Stop fin du match
#define GLOBAL_START 0x002  // Start
#define GLOBAL_END_INIT_POSITION 0x005  // Fin positionnement robot avant depart
#define GLOBAL_FUNNY_ACTION 0x007  // Funny action start  (0: start, 1: stop)

    
// #define BALISE_STOP 0x003  // Trame stop  (angle en °, Type du robot : 1=>gros robot, 2=> petit)
// #define BALISE_DANGER 0xA  // Trame danger  (angle en °, Type du robot : 1=>gros robot, 2=> petit)
// #define BALISE_END_DANGER 0xB  // Trame fin de danger


#define ASSERVISSEMENT_STOP 0x001  // Stop moteur
#define ASSERVISSEMENT_SPEED_DANGER 0x006  // Vitesse de danger
#define ASSERVISSEMENT_XYT 0x020  // Asservissement (x,y,theta)  (0 : au choix 1 : avant -1 : arrière)
#define ASSERVISSEMENT_COURBURE 0x021  // Asservissement rayon de courbure  (+ gauche, - droite , sens : 1avt , -1arr; enchainement => 1 oui, 0 => non, 2=>derniére instruction de l'enchainement)
#define ASSERVISSEMENT_CONFIG 0x022  // Asservissement paramètre  (définir les valeurs de vitesse max et d'eccélération max)
#define ASSERVISSEMENT_ROTATION 0x023  // Asservissement rotation
#define ASSERVISSEMENT_RECALAGE 0x024  // Moteur tout droit  (recalage : 0 mouvement seul, 1 x, 2y valeur : coordonnée à laquelle est recalé x/y; enchainement => 1 oui, 0 => non)
#define ASSERVISSEMENT_DECEL 0x019 



    
#define ODOMETRIE_BIG_POSITION 0x026  // Odométrie position robot  (Position actuel du robot)
#define ODOMETRIE_BIG_VITESSE 0x027  // Odométrie vitesse  (Indication sur l'état actuel)
#define ODOMETRIE_SMALL_POSITION 0x028  // Odométrie position robot  (Position actuel du robot)
#define ODOMETRIE_SMALL_VITESSE 0x029  // Odométrie vitesse  (Indication sur l'état actuel)

#define ASSERVISSEMENT_INFO_CONSIGNE 0x1F0  // Info Consigne et Commande moteur
#define ASSERVISSEMENT_CONFIG_KPP_DROITE 0x1F1  // Config coef KPP_Droit
#define ASSERVISSEMENT_CONFIG_KPI_DROITE 0x1F2  // Config coef KPI_Droit
#define ASSERVISSEMENT_CONFIG_KPD_DROITE 0x1F3  // Config coef KPD_Droit
#define ASSERVISSEMENT_CONFIG_KPP_GAUCHE 0x1F4  // Config coef KPP_Gauche
#define ASSERVISSEMENT_CONFIG_KPI_GAUCHE 0x1F5  // Config coef KPI_Gauche
#define ASSERVISSEMENT_CONFIG_KPD_GAUCHE 0x1F6  // Config coef KPD_Gauche
#define ASSERVISSEMENT_CONFIG_PERIMETRE_ROUE_CODEUSE 0x1FC
#define ASSERVISSEMENT_CONFIG_LARGEUR_ROBOT 0x1FD
#define ASSERVISSEMENT_CONFIG_KPP 0x1F8  // Config coef KPP
#define ASSERVISSEMENT_CONFIG_KPI 0x1F9  // Config coef KPI
#define ASSERVISSEMENT_CONFIG_KPD 0x1FA  // Config coef KPD
#define ASSERVISSEMENT_ENABLE 0x1F7  // Activation asservissement  (0 : désactivation, 1 : activation)
#define ASSERVISSEMENT_REQUETE_PID 0x1FB
/***********************FAIRE ATTENTION A NE PAS LES OUBLIER***********************/
#define ALIVE_MOTEUR 0x071  // Alive moteur
#define ERREUR_TEMP_CALCUL 0x5A0
#define ID_DBUG_ETAT 0x5A1
#define ID_DBUG_ETAT_DPL 0x5A2
#define DBUG_ETAT 0x5A3 // Permet d'activer ou de désactiver le mode debug
#define INSTRUCTION_END_MOTEUR 0x111  // Fin instruction moteur  (Indique que l'instruction est terminée)
/*Quentin*/
#define INSTRUCTION_END 0x100  // Fin instruction position (Indique que l'instruction est terminée)
// --- 
#define ACKNOWLEDGE_MOTEUR 0x101  // Acknowledge moteur
#define ID_TEST_VITESSE 0x5C5
#define ID_DIST_TIC_GENE 0x5A6  


#define ASSERVISSEMENT_CONFIG_KPP_Qt 0x0F0  // Config coef KPP
#define ASSERVISSEMENT_CONFIG_KPI_Qt 0x0F1  // Config coef KPI
#define ASSERVISSEMENT_CONFIG_KPD_Qt 0x0F2  // Config coef KPD
#define ASSERVISSEMENT_CONFIG_LARGEUR_ROBOT_Qt 0x0F3  
#define ASSERVISSEMENT_CONFIG_PERIMETRE_ROUE_CODEUSE_Qt 0x0F4 
#define ASSERVISSEMENT_ROTATION_Qt   0x0F5  // Asservissement rotation
#define ASSERVISSEMENT_RECALAGE_Qt   0x0F6
#define ASSERVISSEMENT_XYT_Qt        0x0F7
#define ASSERVISSEMENT_COURBURE_Qt   0x0F8 


    
#define ASSERVISSEMENT_DECEL 0x019 
#define ASSERVISSEMENT_BEZIER 0x02A

#define RESET_MOTEUR 0x031  // Reset moteur
#define ESP32_RESTART 0x34


#define RESET_STRAT 0x3A  // Reset stratégie

#define CHECK_MOTEUR 0x061  // Check moteur
#define ECRAN_CHOICE_COLOR 0x602  // Couleur  (0->Purple;1->green)
#define DEBUG_MS_COUNT 0x055   
/*****************************************************************************************/

/****************************************************************************************/
/*                              Identiants de l'alimentation                        */
/****************************************************************************************/

#define REQUETE_TENSION 0x200
#define REQUETE_COURANT 0x201
#define REQUETE_SWITCH 0x202
#define RESPONSE_TENSION 0x203
#define RESPONSE_COURANT 0x204
#define RESPONSE_SWITCH 0x205
#define ORDRE_SWITCH 0x206

/*****************************************************************************************/

/****************************************************************************************/
/*                              Identiants des Bras Herkulex/Ascenseur                        */
/****************************************************************************************/

#define BRAS_HERKULEX_DEVANT 0x516
#define BRAS_HERKULEX_ARRIERE 0x517

#define HERKULEX_ASCENSEUR_AVANT 0x518
#define HERKULEX_ASCENSEUR_ARRIERE 0x519
#define MOTEUR_PAS_PAS 0x520

#define HERKULEX_PANNEAU_SOLAIRE 0x521




/*****************************************************************************************/

/****************************************************************************************/
/*                              Identiants des PAMI                  */
/****************************************************************************************/


#define PAMI_ONE 0x5B0
#define PAMI_TWO 0x5B1
#define PAMI_THREE 0x5B2   
#define PAMI_FOUR 0x5B3
#define PAMI_FIVE 0x5B4

/*****************************************************************************************/


#define ASSERVISSEMENT_ERREUR 0x025    
    
#define ID_FIN_CLOTHO 0x501

/****************************************************************************************/

/****************************************************************************************/
/*                              Identiants pour le bus CAN Lidar                        */
/****************************************************************************************/

#define IDCAN_POS_XY_OBJET 0x82
// #define ERREUR_TEMP_CALCUL_LIDAR 0x86
    
#endif
